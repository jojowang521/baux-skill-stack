# 随包渲染资源

此 Skill 包含可离线运行的本地资源，不在运行时寻找其他 Skill。

- `scripts/render_layout.py` 与基础报告资源来自本机已有 `html-visual-report`；报告模板沿用已验证的蓝白报告样板和移动端修订。
- `assets/journey-template.html` 与地图数据契约来自已有 `research-to-journey-map` v0.3 工作流。此副本将中性表情改为平嘴；未改变已安装的独立地图 Skill。
- `assets/echarts.min.js` 保留原有 Apache 软件许可声明；生成的页面内嵌该脚本。
- `scripts/build_report.py`、运行时目录与地图容器、本报告契约、校验器和流程说明属于本次封装。

更新基础资源后，应重新验证嵌入地图、来源弹窗、打印、表格、移动端及离线行为。不要将版本号未知的副本描述成已经验证的上游最新版。
