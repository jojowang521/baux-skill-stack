# 完整体验地图接入

仅在创建或修改地图时读取。本 Skill 内置 v0.3 地图契约和渲染模板；地图仍可单独交给 `research-to-journey-map` 使用。

## 文件与角色

`content.journeys[]` 指向材料目录内的地图 JSON。地图 `map_id` 等于该记录 `id`，`task.map_state` 与报告一致。地图来源ID要在报告 `content.sources` 中登记，路径解析到同一个文件。

参考 `examples/publishing-journey-1.json` 了解单角色完整字段，参考 `examples/support-journey-1.json` 和 `support-journey-2.json` 了解同一报告的角色拆分。以 `data/journey-map.schema.json` 为字段契约，不照搬示例内容。

地图顶层包括：

- `provenance`：材料类型、内容性质与研究验证状态。
- `overview`、`summary`：地图标题、角色目标、核心问题和改善假设。
- `task`：主角色、场景、起终点、目的、现状/未来/假设状态及假设。
- `sources`：来源文件及定位方式。
- `stages`：按 `order` 排序，记录目标、行为、接触点、情绪、痛点与机会。
- `branches`：条件、起点与终点阶段、返回路径说明及来源。
- `presentation`：行、强调阶段和情绪轴；与研究事实分开。
- `missing_information`：来源、覆盖和情绪等缺失。

## 归纳方法

按用户的任务目标变化划分阶段，而非机械按菜单分页。一个阶段可有多个行为和接触点；异常、回退、重试不强行画成一直向前。不同角色或不同状态的旅程分开；跨角色关联可在来源及备注说明。

保留相互矛盾的观察，标出涉及角色、情境与来源。没有记录的痛点写空数组，不推断该阶段“体验良好”。机会点属于设计假设，不能自动认为一条机会必然解决一条痛点。

证据标签举例：

| 内容 | 常用标记 |
| --- | --- |
| 模拟材料中的行为 | `evidence_status: simulated_observation` |
| 根据模拟材料归纳的痛点 | `analysis_from_simulated_material` |
| 真正观察到的行为 | `observed`，须有真实来源 |
| 用户报告 | `reported`，须有真实来源 |
| 改善建议 | `design_hypothesis` |
| 图中引用文案 | `caption_kind: map_caption_not_verified_participant_quote` |
| 没有情绪记录 | `caption: null`，`caption_kind: not_recorded`，`score: null`，`visual_interpretation: {label: null, status: not_recorded}` |

不要把图中带引号的句子直接标成 `participant_quote`。只有来源能证明是参与者原话时才使用该标记。曲线坐标是视觉布局，不能反推情绪评分。

## 与问题台账保持一致

每个地图痛点的ID等于报告问题ID。`finding_links` 为 `(stage_id, finding_id, relation)`：

- `experienced` 对应这个角色阶段中的痛点；必须与地图痛点集合一致。
- `contextual` 用于背景检查，不绘制为这个角色的主观痛点。例如独立权限检查不能变成申请人的负面情绪。

生成器会从问题台账同步地图痛点标题、当前状态和角色名称。阶段目标、行为、接触点、情绪与机会的正文仍应由作者依据材料维护；脚本不推断这些内容。报告与地图都保留来源，因此不能只改图上文案却不更新依据。

## 展示与独立使用

每张图默认完整嵌入，可适应宽度、原尺寸滚动、全屏或单独打开。阶段数量不写死，多地图各自控制缩放。`presentation.journey_view` 控制初始阅读模式、全屏按钮和来源弹窗。默认保留来源查看。

报告中的“单独打开”生成离线 Blob 页面，地图自身可下载地图JSON；报告下载按钮同时导出所有地图与报告主数据。地图单独使用时仍应携带对应来源材料。
