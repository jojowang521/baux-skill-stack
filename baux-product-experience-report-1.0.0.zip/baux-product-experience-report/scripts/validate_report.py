#!/usr/bin/env python3
"""Validate this report contract (stdlib; not a general JSON Schema engine)."""
import argparse, json, math
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def check_schema(value, schema, root=None, path='$'):
    root=root or schema; errors=[]
    if '$ref' in schema:
        node=root
        for part in schema['$ref'].removeprefix('#/').split('/'):node=node[part]
        return check_schema(value,node,root,path)
    if 'anyOf' in schema:
        if not any(not check_schema(value,option,root,path) for option in schema['anyOf']):errors.append(path+': 不符合允许的类型')
        return errors
    kinds={'object':lambda v:isinstance(v,dict),'array':lambda v:isinstance(v,list),'string':lambda v:isinstance(v,str),'integer':lambda v:isinstance(v,int) and not isinstance(v,bool),'number':lambda v:isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v),'boolean':lambda v:isinstance(v,bool),'null':lambda v:v is None}
    kind=schema.get('type');allowed=kind if isinstance(kind,list) else [kind]
    if kind and not any(kinds[k](value) for k in allowed):return [path+': 类型错误']
    if 'enum' in schema and value not in schema['enum']:errors.append(path+': 不在允许值中')
    if 'const' in schema and value!=schema['const']:errors.append(path+': 固定契约值不匹配')
    if isinstance(value,dict):
        for k in schema.get('required',[]):
            if k not in value:errors.append(path+'.'+k+': 缺少字段')
        props=schema.get('properties',{})
        for k,v in value.items():
            if k in props:errors+=check_schema(v,props[k],root,path+'.'+k)
            elif schema.get('additionalProperties') is False:errors.append(path+'.'+k+': 未定义字段')
    if isinstance(value,list):
        if len(value)<schema.get('minItems',0):errors.append(path+': 数组过短')
        for i,v in enumerate(value):errors+=check_schema(v,schema.get('items',{}),root,f'{path}[{i}]')
    if isinstance(value,str) and len(value)<schema.get('minLength',0):errors.append(path+': 字符串过短')
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        if 'minimum' in schema and value<schema['minimum']:errors.append(path+': 小于最小值')
        if 'maximum' in schema and value>schema['maximum']:errors.append(path+': 超过最大值')
    return errors

def safe_file(base, relative):
    if not relative or Path(relative).is_absolute():raise ValueError('须为材料目录内的相对路径')
    path=(base/relative).resolve()
    if not path.is_relative_to(base.resolve()):raise ValueError('路径超出报告材料目录')
    return path

def validate(data, base, check_sources=False):
    schema=json.loads((ROOT/'data/report.schema.json').read_text())
    errors=check_schema(data,schema);warnings=[]
    if errors:return {'valid':False,'errors':errors,'warnings':warnings,'counts':None}
    content=data['content'];rules=data['rules'];indices={}
    themes=json.loads((ROOT/'assets/themes/registry.json').read_text())
    if data['presentation']['theme'] not in themes:errors.append('presentation.theme: 未支持的主题；可选 '+', '.join(themes))
    from datetime import date, datetime
    for field in ['authored_on','revised_on']:
        value=data['metadata'][field]
        if value is not None:
            try:date.fromisoformat(value)
            except ValueError:errors.append('metadata.'+field+': 应为ISO日期')
    def check_dates(v,path='$'):
        if isinstance(v,dict):
            for k,val in v.items():
                if k in ['recorded_at','observed_at','executed_at','source_date','target_date'] and val is not None:
                    try:datetime.fromisoformat(val.replace('Z','+00:00'))
                    except (ValueError,AttributeError):errors.append(path+'.'+k+': 日期或时间格式无效')
                check_dates(val,path+'.'+k)
        elif isinstance(v,list):
            for i,val in enumerate(v):check_dates(val,f'{path}[{i}]')
    check_dates(data)
    if data['metadata']['content_nature']=='real' and any(e['nature']=='simulated' for e in content['evidence']):errors.append('metadata: 含模拟证据的数据不能整体标为真实')
    def index(name,items):
        result={}
        for item in items:
            if item['id'] in result:errors.append(name+': ID重复 '+item['id'])
            result[item['id']]=item
        indices[name]=result;return result
    for key in ['roles','modules','sources','evidence','requirements','cases','findings','recommendations','journeys','assessments','missing_information']:index(key,content[key])
    for key in ['categories','dimensions','severities','statuses']:index(key,rules[key])
    index('gates',rules['acceptance']['gates'])
    index('groups',data['presentation']['groups'])
    index('views',[m for g in data['presentation']['groups'] for m in g['modules']])
    index('risk_acceptances',content['decision']['risk_acceptances'])
    def refs(values,collection,where):
        for value in values:
            if value is not None and value not in indices[collection]:errors.append(where+': 引用不存在的'+collection+' '+value)
        if len(values)!=len(set(values)):errors.append(where+': 重复引用')
    def source_refs(values,where):
        for r in values:refs([r['source_id']],'sources',where)
    def validate_statement(s,where):
        refs(s['evidence_ids'],'evidence',where)
        if s['basis'] in ['observed','reported']:
            if not s['evidence_ids']:errors.append(where+': 真实观察/报告必须有证据')
            for eid in s['evidence_ids']:
                ev=indices['evidence'].get(eid)
                if ev and ev['nature']!='real':errors.append(where+': 非真实证据不能标为观察/真实报告')
        if not s['evidence_ids'] and s['basis']=='analyst_inference':warnings.append(where+': 推断没有证据，应说明假设依据或缺失信息')
    for s in content['sources']:
        if s['path'] is None:warnings.append(s['id']+': 原件未提供')
        else:
            try:
                f=safe_file(base,s['path'])
                if check_sources and not f.is_file():errors.append(s['id']+': 来源文件不存在')
            except ValueError as e:errors.append(s['id']+': '+str(e))
    for ev in content['evidence']:
        source_refs(ev['source_refs'],ev['id'])
        if not ev['source_refs']:errors.append(ev['id']+': 证据缺少来源定位')
        if ev['nature']=='real':
            for sr in ev['source_refs']:
                src=indices['sources'].get(sr['source_id'])
                if src and src['nature']!='real':errors.append(ev['id']+': 非真实来源不能成为真实证据')
    for r in content['roles']:refs(r['evidence_ids'],'evidence',r['id'])
    for m in content['modules']:
        refs([m['parent_id']],'modules',m['id']);seen={m['id']};pid=m['parent_id']
        while pid and pid in indices['modules']:
            if pid in seen:errors.append(m['id']+': 模块父子关系成环');break
            seen.add(pid);pid=indices['modules'][pid]['parent_id']
    for r in content['requirements']:
        refs(r['module_ids'],'modules',r['id']);refs(r['evidence_ids'],'evidence',r['id'])
    for case in content['cases']:
        for field,target in [('role_ids','roles'),('requirement_ids','requirements'),('evidence_ids','evidence')]:refs(case[field],target,case['id'])
        if case['detail_level']=='reproducible' and (not case['preconditions'] or not case['steps'] or not case['expected']):errors.append(case['id']+': 可复现用例缺少前置条件、步骤或预期')
        if case['result'] in ['passed','failed'] and not case['evidence_ids']:errors.append(case['id']+': 已执行结果缺少证据')
    for f in content['findings']:
        for field,target in [('role_ids','roles'),('dimension_ids','dimensions'),('case_ids','cases'),('requirement_ids','requirements'),('status_evidence_ids','evidence')]:refs(f[field],target,f['id'])
        for field,target in [('module_id','modules'),('primary_category_id','categories'),('severity_id','severities'),('status_id','statuses')]:refs([f[field]],target,f['id'])
        validate_statement(f['phenomenon'],f['id']+'.phenomenon');validate_statement(f['impact'],f['id']+'.impact')
        if indices['statuses'].get(f['status_id'],{}).get('is_closed') and not any(indices['evidence'].get(e,{}).get('kind') in ['retest','test_result'] for e in f['status_evidence_ids']):errors.append(f['id']+': 关闭状态必须有复验或测试结果依据')
        if f['primary_category_id'] is None:warnings.append(f['id']+': 主分类待定，计入未分类而不丢弃')
    for r in content['recommendations']:
        refs(r['finding_ids'],'findings',r['id']);validate_statement(r['proposal'],r['id'])
        if r['proposal']['basis'] not in ['design_hypothesis','reference_transcription']:errors.append(r['id']+': 改善方案须标为设计假设或原稿转录')
    for a in content['assessments']:
        refs([a['dimension_id']],'dimensions',a['id']);refs(a['finding_ids'],'findings',a['id']);validate_statement(a['summary'],a['id'])
    for g in rules['acceptance']['gates']:
        refs(g['requirement_ids'],'requirements',g['id']);refs(g['evidence_ids'],'evidence',g['id'])
    dec=content['decision'];validate_statement(dec['rationale'],'decision')
    evaluated=[]
    for g in dec['gate_evaluations']:
        refs([g['gate_id']],'gates','decision');refs(g['evidence_ids'],'evidence','decision');evaluated.append(g['gate_id'])
    if len(set(evaluated))!=len(evaluated):errors.append('decision: 门槛结果重复')
    for r in dec['risk_acceptances']:
        refs(r['finding_ids'],'findings',r['id']);refs(r['evidence_ids'],'evidence',r['id'])
        if r['approval_status']=='approved' and (not r['approved_by'] or not r['evidence_ids']):errors.append(r['id']+': 已批准风险缺少批准人或依据')
    if dec['kind']=='not_assessed' and dec['result'] not in ['undetermined','not_applicable']:errors.append('decision: 未评估不能作出通过或失败判断')
    if not rules['acceptance']['applicable'] and dec['result'] not in ['undetermined','not_applicable']:errors.append('decision: 未启用验收规则却输出验收结论')
    blockers=[f for f in content['findings'] if indices['severities'].get(f['severity_id'],{}).get('release_blocker') and not indices['statuses'].get(f['status_id'],{}).get('is_closed')]
    if dec['result'] in ['passed','conditional']:
        gates=rules['acceptance']['gates'];results={g['gate_id']:g['result'] for g in dec['gate_evaluations']}
        if not gates:errors.append('decision: 没有验收标准不能判定通过')
        if blockers:errors.append('decision: 配置中阻断发布的问题仍未关闭')
        if any(g['mandatory'] and results.get(g['id'])!='satisfied' for g in gates):errors.append('decision: 必须门槛未全部满足')
    if dec['kind']=='actual' and dec['result'] in ['passed','conditional','failed']:
        evs=dec['rationale']['evidence_ids']+[e for g in dec['gate_evaluations'] for e in g['evidence_ids']]
        if not evs or any(indices['evidence'].get(e,{}).get('nature')!='real' for e in evs):errors.append('decision: 真实验收判断缺少真实依据或混入模拟依据')
        if data['metadata']['content_nature'] in ['simulated','hypothesis','unverified']:errors.append('decision: 当前材料性质不能输出真实验收判断')
        if any(g['basis']!='confirmed' for g in rules['acceptance']['gates']):errors.append('decision: 真实验收门槛尚未确认')
        if dec['result'] in ['passed','conditional'] and any(x['blocks_acceptance'] for x in content['missing_information']):errors.append('decision: 阻碍验收的材料缺失尚未解决')
    all_map_refs=[]
    for j in content['journeys']:
        refs([j['role_id']],'roles',j['id'])
        try:
            mp=safe_file(base,j['map_file']);m=json.loads(mp.read_text());map_schema=json.loads((ROOT/'data/journey-map.schema.json').read_text())
            map_errors=check_schema(m,map_schema,path=j['id']+'.map')
            errors+=map_errors
            if map_errors:continue
        except (OSError,ValueError) as e:errors.append(j['id']+': 地图读取失败 '+str(e));continue
        if m.get('map_id')!=j['id']:errors.append(j['id']+': 地图ID不匹配')
        if m.get('task',{}).get('map_state')!=j['map_state']:errors.append(j['id']+': 地图状态不匹配')
        stages=m.get('stages',[]);stage_ids=[s['id'] for s in stages];orders=[s['order'] for s in stages]
        if len(set(stage_ids))!=len(stage_ids) or len(set(orders))!=len(orders):errors.append(j['id']+': 阶段ID或顺序重复')
        if not stages:errors.append(j['id']+': 地图没有阶段，应从journeys中省略并记录缺失')
        msrc={s['id']:s for s in m.get('sources',[])}
        for sid,src in msrc.items():
            refs([sid],'sources',j['id'])
            try:
                mpath=safe_file(mp.parent,src['path'])
                rs=indices['sources'].get(sid)
                if rs and rs['path'] and mpath!=safe_file(base,rs['path']):errors.append(j['id']+': 地图与报告来源文件不一致 '+sid)
            except ValueError as e:errors.append(j['id']+': '+str(e))
        experienced=set();seen_links=set()
        for link in j['finding_links']:
            refs([link['finding_id']],'findings',j['id'])
            if link['stage_id'] not in stage_ids:errors.append(j['id']+': 地图关联阶段不存在')
            pair=(link['stage_id'],link['finding_id'])
            if pair in seen_links:errors.append(j['id']+': 同阶段问题关联重复')
            seen_links.add(pair)
            if link['relation']=='experienced':experienced.add(pair)
        actual_pains={(s['id'],p['id']) for s in stages for p in s.get('pain_points',[])}
        if experienced!=actual_pains:errors.append(j['id']+': 主旅程关联与地图痛点不一致（背景问题不得混入）')
        for s in stages:
            emotion=s.get('emotion',{});score=emotion.get('score');scale=m.get('presentation',{}).get('emotion_axis',{}).get('numeric_scale')
            if score is not None and (not scale or not scale['min']<=score<=scale['max'] or not emotion.get('source_refs')):errors.append(j['id']+': 情绪评分缺少量表/来源或超出范围')
        for b in m.get('branches',[]):
            if b['from_stage_id'] not in stage_ids or b['to_stage_id'] not in stage_ids:errors.append(j['id']+': 返回路径端点不存在')
        def walk_map(v):
            if isinstance(v,dict):
                if v.get('evidence_status') in ['observed','reported'] or v.get('caption_kind')=='participant_quote':
                    evrefs=v.get('source_refs',[])
                    if not evrefs or any(indices['sources'].get(r['source_id'],{}).get('nature')!='real' for r in evrefs):errors.append(j['id']+': 地图不能将模拟/未知来源标为真实观察或原话')
                for sr in v.get('source_refs',[]):
                    if sr['source_id'] not in msrc:errors.append(j['id']+': 地图引用未知来源')
                    all_map_refs.append((sr,j['id']))
                for child in v.values():walk_map(child)
            elif isinstance(v,list):
                for child in v:walk_map(child)
        walk_map(m)
    if check_sources:
        cached={}
        def verify_excerpt(sr,where):
            src=indices['sources'].get(sr['source_id']);excerpt=sr.get('excerpt')
            if not src or not src['path'] or not excerpt:return
            try:
                path=safe_file(base,src['path'])
                if path.suffix.lower() not in ['.json','.txt','.md','.csv']:
                    warnings.append(where+': 此类型来源需人工核验摘录');return
                if path not in cached:cached[path]=path.read_text()
                text=cached[path]
                if path.suffix=='.json':
                    payload=json.loads(text)
                    if sr['locator'].startswith('/'):
                        for key in sr['locator'][1:].split('/'):
                            key=key.replace('~1','/').replace('~0','~');payload=payload[int(key)] if isinstance(payload,list) else payload[key]
                        text=payload if isinstance(payload,str) else json.dumps(payload,ensure_ascii=False)
                    else:text=json.dumps(payload,ensure_ascii=False)
                if excerpt not in text:errors.append(where+': 摘录与指定来源不符')
            except (OSError,ValueError,KeyError,IndexError,TypeError) as e:errors.append(where+': 来源核验失败 '+str(e))
        for ev in content['evidence']:
            for sr in ev['source_refs']:verify_excerpt(sr,ev['id'])
        for sr,where in all_map_refs:verify_excerpt(sr,where)
    if not content['journeys']:warnings.append('完整体验地图未提供：输出时标记待补充，不编造阶段')
    if any(c['detail_level']=='summary' for c in content['cases']):warnings.append('用例为概要，不能当作完整测试脚本或覆盖率证明')
    if any(g['basis']!='confirmed' for g in rules['acceptance']['gates']):warnings.append('验收规则尚未确认，保留来源边界')
    if any(x['recorded_at'] is None for x in [data['metadata']['assessment_snapshot'],data['metadata']['status_snapshot']]):warnings.append('观察或状态快照时间未知，不能用生成日期填补')
    warnings.extend(x['id']+': '+x['description'] for x in content['missing_information'])
    counts={'findings':len(content['findings']),'primary_category':dict(Counter(f['primary_category_id'] or 'unclassified' for f in content['findings'])),'severity':dict(Counter(f['severity_id'] or 'unclassified' for f in content['findings'])),'status':dict(Counter(f['status_id'] for f in content['findings'])),'closed':sum(bool(indices['statuses'].get(f['status_id'],{}).get('is_closed')) for f in content['findings']),'unclosed_blockers':len(blockers),'cases':len(content['cases']),'case_results':dict(Counter(c['result'] for c in content['cases'])),'journeys':len(content['journeys'])}
    return {'valid':not errors,'errors':list(dict.fromkeys(errors)),'warnings':list(dict.fromkeys(warnings)),'counts':counts,'note':'仅校验结构、关联和明确的数据规则；不证明研究结论、完整测试覆盖或真实验收质量。'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('report',type=Path);p.add_argument('--check-sources',action='store_true');p.add_argument('--output',type=Path);args=p.parse_args()
    try:r=validate(json.loads(args.report.read_text()),args.report.resolve().parent,args.check_sources)
    except (OSError,ValueError) as e:r={'valid':False,'errors':[str(e)],'warnings':[],'counts':None}
    text=json.dumps(r,ensure_ascii=False,indent=2)+'\n'
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text)
    print(text,end='');raise SystemExit(0 if r['valid'] else 2)
