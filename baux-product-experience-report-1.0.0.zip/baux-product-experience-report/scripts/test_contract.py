#!/usr/bin/env python3
"""Behavioral checks of data invariants, without rendering or modifying source reports."""
import copy, json, tempfile, shutil
from pathlib import Path
from validate_report import validate
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'examples';original=json.loads((BASE/'procurement.report.json').read_text());brief=json.loads((BASE/'brief-only.report.json').read_text())
results=[]
def check(name,mutate,expected=False,start=None,map_mutate=None,assertion=None):
    d=copy.deepcopy(original if start is None else start)
    with tempfile.TemporaryDirectory() as tmp:
        base=Path(tmp)/'examples';shutil.copytree(BASE,base)
        mutate(d)
        if map_mutate:
            mp=base/'procurement.journey.json';m=json.loads(mp.read_text());map_mutate(m);mp.write_text(json.dumps(m,ensure_ascii=False))
        r=validate(d,base,True)
        okay=r['valid']==expected and (assertion(r) if assertion else True)
        results.append({'name':name,'passed':okay,'validation_errors':r['errors'] if not okay else []})

check('采购迁移保持问题和用例统计',lambda d:None,True,assertion=lambda r:r['counts']['findings']==12 and r['counts']['cases']==12 and r['counts']['closed']==1 and r['counts']['unclosed_blockers']==4)
check('缺少研究材料可表达而不生成通过结论',lambda d:None,True,start=brief,assertion=lambda r:r['counts']['findings']==0 and bool(r['warnings']))
check('拒绝重复问题ID',lambda d:d['content']['findings'].append(copy.deepcopy(d['content']['findings'][0])))
check('拒绝不存在的业务模块',lambda d:d['content']['findings'][0].update(module_id='not-a-module'))
check('拒绝不存在的来源',lambda d:d['content']['evidence'][0]['source_refs'][0].update(source_id='not-a-source'))
check('拒绝证据摘录被篡改',lambda d:d['content']['evidence'][0]['source_refs'][0].update(excerpt='原文件完全没有此句'))
check('拒绝模拟证据冒充真实观察',lambda d:d['content']['findings'][0]['phenomenon'].update(basis='observed'))
check('拒绝真实证据引用模拟来源',lambda d:d['content']['evidence'][0].update(nature='real'))
check('拒绝模拟验收冒充实际验收',lambda d:d['content']['decision'].update(kind='actual'))
check('拒绝空数据自动判定通过',lambda d:d['content']['decision'].update(result='passed'),start=brief)
check('拒绝阻断问题未关闭时判定通过',lambda d:d['content']['decision'].update(result='passed'))
check('拒绝关闭问题缺少复验依据',lambda d:d['content']['findings'][-1].update(status_evidence_ids=[]))
check('允许未分类并保留统计',lambda d:d['content']['findings'][0].update(primary_category_id=None),True,assertion=lambda r:r['counts']['primary_category']['unclassified']==1 and sum(r['counts']['primary_category'].values())==12)
check('拒绝把多个主分类塞进单分类字段',lambda d:d['content']['findings'][0].update(primary_category_id=['experience','functional']))
check('多维标签不增加问题总数',lambda d:d['content']['findings'][0]['dimension_ids'].append('mobile'),True,assertion=lambda r:r['counts']['findings']==12)
check('拒绝模块层级循环',lambda d:d['content']['modules'][0].update(parent_id=d['content']['modules'][0]['id']))
check('拒绝未批准风险伪装批准',lambda d:d['content']['decision']['risk_acceptances'].append({'id':'RISK-01','finding_ids':['UX-01'],'reason':'示例','approval_status':'approved','approved_by':None,'evidence_ids':[]}))
check('拒绝概要用例伪装可复现脚本',lambda d:d['content']['cases'][0].update(detail_level='reproducible'))
check('拒绝越出材料目录的来源路径',lambda d:d['content']['sources'][0].update(path='../../outside.json'))
check('拒绝缺失的地图文件',lambda d:d['content']['journeys'][0].update(map_file='missing.json'))
check('拒绝背景权限问题混入主观痛点',lambda d:next(x for x in d['content']['journeys'][0]['finding_links'] if x['finding_id']=='UX-06').update(relation='experienced'))
check('拒绝返回路径不存在的阶段',lambda d:None,map_mutate=lambda m:m['branches'][0].update(to_stage_id='missing-stage'))
check('拒绝无量表情绪评分',lambda d:None,map_mutate=lambda m:m['stages'][0]['emotion'].update(score=88))
check('拒绝地图模拟行为改为真实观察',lambda d:None,map_mutate=lambda m:m['stages'][0]['activities'][0].update(evidence_status='observed'))
check('损坏地图字段返回错误而非崩溃',lambda d:None,map_mutate=lambda m:m['stages'][0].pop('id'))
check('显示隐藏地图不删除研究数据',lambda d:d['presentation']['groups'][0]['modules'][-1].update(visibility='hide'),True,assertion=lambda r:r['counts']['journeys']==1)
check('目录分组可以重命名和重排',lambda d:d['presentation']['groups'].reverse(),True)
check('拒绝日期占位符',lambda d:d['metadata'].update(authored_on='昨天'))
summary={'passed':sum(r['passed'] for r in results),'total':len(results),'results':results}
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/contract-tests.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':summary['passed'],'total':summary['total'],'failures':[r for r in results if not r['passed']]},ensure_ascii=False,indent=2))
raise SystemExit(0 if summary['passed']==summary['total'] else 1)
