#!/usr/bin/env python3
"""Build a single-file HTML visual report from an agent-authored report model."""

from __future__ import annotations

import argparse
import base64
import html
import json
import mimetypes
import re
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ASSET_DIR = ROOT / "assets"
DEFAULT_TEMPLATE = DEFAULT_ASSET_DIR / "report-template.html"
COLORED_BADGE_TONES = {"high", "mid"}
ALLOWED_BADGE_TONES = {"info", "high", "mid"}
CALLOUT_COLOR_CLASSES = {
    "blue": "",
    "gray": " is-gray",
    "grey": " is-gray",
    "red": " is-red",
}
WARNING_BADGE_KEYWORDS = (
    "预警",
    "告警",
    "警告",
    "异常",
    "严重偏离",
    "中度偏离",
    "高风险",
    "中风险",
    "超限",
    "超标",
)


RUNTIME_JS = r"""
const palette = ['#4F83F1', '#4BC7D3', '#8B6BD6', '#FFC94A', '#6B6EA6', '#4ECD82', '#2D7ACB', '#FFA174', '#FF5A5F'];
const baseText = '#333333';
const mutedText = '#666666';
const axisText = '#1F2937';

function isPieOption(option) {
  return Array.isArray(option.series) && option.series.some((item) => item && item.type === 'pie');
}

function isRadarOption(option) {
  return !!option.radar || (Array.isArray(option.series) && option.series.some((item) => item && item.type === 'radar'));
}

function normalizeAxis(axis) {
  const normalizeOne = (item = {}) => {
    const userAxisLabel = item.axisLabel || {};
    const userNameTextStyle = item.nameTextStyle || {};
    return ({
    ...item,
    axisLine: { ...(item.axisLine || {}), show: false },
    axisTick: { ...(item.axisTick || {}), show: false },
    splitLine: { ...(item.splitLine || {}), show: false },
    axisLabel: { ...userAxisLabel, color: axisText, fontSize: userAxisLabel.fontSize ?? 12 },
    nameTextStyle: { ...userNameTextStyle, color: axisText, fontSize: userNameTextStyle.fontSize ?? 12 }
  });
  };
  return Array.isArray(axis) ? axis.map(normalizeOne) : normalizeOne(axis);
}

function legendItemCount(option) {
  if (option.legend && Array.isArray(option.legend.data)) return option.legend.data.length;
  if (!Array.isArray(option.series)) return 0;
  return option.series.reduce((count, series) => {
    if (series && Array.isArray(series.data)) return Math.max(count, series.data.length);
    return count;
  }, 0);
}

function getLegendOption(option) {
  const count = legendItemCount(option);
  const singleLineScroll = count >= 5;
  const userLegend = option.legend || {};
  return {
    ...userLegend,
    type: singleLineScroll ? 'scroll' : (userLegend.type || 'plain'),
    bottom: userLegend.bottom ?? 4,
    left: userLegend.left ?? 'center',
    orient: userLegend.orient ?? 'horizontal',
    icon: 'path://M0,0 L10,0 L10,10 L0,10 Z',
    itemWidth: 10,
    itemHeight: 10,
    itemGap: userLegend.itemGap ?? 14,
    width: userLegend.width ?? (singleLineScroll ? '78%' : '92%'),
    pageButtonPosition: userLegend.pageButtonPosition || 'end',
    pageIconSize: userLegend.pageIconSize || 10,
    pageIconColor: userLegend.pageIconColor || '#64748b',
    pageIconInactiveColor: userLegend.pageIconInactiveColor || '#cbd5e1',
    pageTextStyle: { color: mutedText, fontSize: 12, ...(userLegend.pageTextStyle || {}) },
    textStyle: {
      color: mutedText,
      fontSize: 12,
      width: 120,
      overflow: 'truncate',
      ...(userLegend.textStyle || {})
    }
  };
}

function mergeTheme(option) {
  const merged = {
    color: palette,
    animation: true,
    animationDuration: 900,
    animationDurationUpdate: 700,
    animationEasing: 'cubicOut',
    animationEasingUpdate: 'cubicOut',
    textStyle: { color: baseText, fontFamily: '-apple-system, BlinkMacSystemFont, Segoe UI, PingFang SC, Microsoft YaHei, Arial, sans-serif', fontSize: 12 },
    grid: { left: 44, right: 24, top: 46, bottom: 42, containLabel: true },
    tooltip: { trigger: 'axis', backgroundColor: 'rgba(255,255,255,.96)', borderColor: '#E2E8F0', textStyle: { color: baseText, fontSize: 12 } },
    legend: getLegendOption(option),
    xAxis: { axisLine: { show: false }, axisTick: { show: false }, axisLabel: { color: axisText, fontSize: 12 }, nameTextStyle: { color: axisText, fontSize: 12 }, splitLine: { show: false } },
    yAxis: { axisLine: { show: false }, axisTick: { show: false }, axisLabel: { color: axisText, fontSize: 12 }, nameTextStyle: { color: axisText, fontSize: 12 }, splitLine: { show: false } },
    ...option
  };
  merged.legend = getLegendOption(option);
  if (Array.isArray(merged.series)) {
    merged.series = merged.series.map((series) => {
      if (!series || typeof series !== 'object') return series;
      const animatedSeries = { ...series };
      if (animatedSeries.type === 'bar') {
        animatedSeries.animationDuration = animatedSeries.animationDuration ?? 900;
        animatedSeries.animationEasing = animatedSeries.animationEasing ?? 'cubicOut';
        animatedSeries.animationDelay = animatedSeries.animationDelay ?? ((index) => index * 70);
        animatedSeries.itemStyle = {
          ...(animatedSeries.itemStyle || {}),
          borderRadius: 0
        };
      }
      if (animatedSeries.type === 'pie') {
        animatedSeries.animationType = animatedSeries.animationType ?? 'scale';
        animatedSeries.animationDuration = animatedSeries.animationDuration ?? 900;
        animatedSeries.animationEasing = animatedSeries.animationEasing ?? 'cubicOut';
        animatedSeries.center = ['50%', '38%'];
        animatedSeries.radius = ['42%', '60%'];
        animatedSeries.label = {
          color: baseText,
          fontSize: 12,
          width: 112,
          overflow: 'truncate',
          ...(animatedSeries.label || {})
        };
        animatedSeries.labelLine = {
          length: 10,
          length2: 14,
          ...(animatedSeries.labelLine || {})
        };
      }
      return animatedSeries;
    });
  }
  if (isPieOption(option) || isRadarOption(option)) {
    delete merged.grid;
    delete merged.xAxis;
    delete merged.yAxis;
    if (isRadarOption(option) && merged.radar) {
      merged.radar = {
        ...merged.radar,
        center: merged.radar.center || ['50%', '40%'],
        radius: merged.radar.radius || '56%'
      };
    }
  } else {
    merged.grid = { ...(merged.grid || {}), bottom: Math.max(Number(merged.grid?.bottom) || 0, 54) };
    merged.xAxis = normalizeAxis(merged.xAxis);
    merged.yAxis = normalizeAxis(merged.yAxis);
  }
  return merged;
}

const charts = new Map();
function initChart(el) {
  const id = el.dataset.chartId;
  if (!id || charts.has(id) || !chartOptions[id] || !window.echarts) return;
  const chart = echarts.init(el, null, { renderer: 'canvas' });
  chart.setOption(mergeTheme(chartOptions[id]));
  charts.set(id, chart);
}

function createFloatingScrollbar(target, options = {}) {
  const scrollTarget = options.documentLevel ? (document.scrollingElement || document.documentElement) : target;
  const axis = options.axis || 'y';
  const bar = document.createElement('div');
  const thumb = document.createElement('div');
  let active = false;
  let pointerInside = false;

  bar.className = `report-floating-scrollbar is-${axis === 'x' ? 'horizontal' : 'vertical'}`;
  thumb.className = 'report-floating-scrollbar__thumb';
  bar.appendChild(thumb);
  document.body.appendChild(bar);

  function hasScrollableContent() {
    if (axis === 'x') {
      return scrollTarget.clientWidth > 0 && scrollTarget.scrollWidth > scrollTarget.clientWidth + 1;
    }
    return scrollTarget.clientHeight > 0 && scrollTarget.scrollHeight > scrollTarget.clientHeight + 1;
  }

  function getTrackRect() {
    if (options.documentLevel) {
      return { top: 8, left: window.innerWidth - 10, height: Math.max(0, window.innerHeight - 16) };
    }
    const rect = target.getBoundingClientRect();
    if (axis === 'x') {
      const left = Math.max(8, rect.left + 4);
      const right = Math.min(window.innerWidth - 8, rect.right - 4);
      const top = Math.min(window.innerHeight - 10, Math.max(8, rect.bottom - 10));
      return { top, left, width: Math.max(0, right - left) };
    }
    const top = Math.max(8, rect.top + 4);
    const bottom = Math.min(window.innerHeight - 8, rect.bottom - 4);
    return { top, left: rect.right - 10, height: Math.max(0, bottom - top) };
  }

  function update() {
    if (!hasScrollableContent()) {
      bar.classList.remove('is-visible');
      return;
    }
    const track = getTrackRect();
    const trackSize = axis === 'x' ? track.width : track.height;
    if (trackSize <= 0) {
      bar.classList.remove('is-visible');
      return;
    }

    bar.style.top = `${track.top}px`;
    bar.style.left = `${track.left}px`;

    if (axis === 'x') {
      const thumbWidth = Math.max(36, (scrollTarget.clientWidth / scrollTarget.scrollWidth) * track.width);
      const maxThumbLeft = Math.max(0, track.width - thumbWidth);
      const maxScrollLeft = Math.max(1, scrollTarget.scrollWidth - scrollTarget.clientWidth);
      const thumbLeft = Math.min(maxThumbLeft, Math.max(0, (scrollTarget.scrollLeft / maxScrollLeft) * maxThumbLeft));

      bar.style.width = `${track.width}px`;
      bar.style.height = '6px';
      thumb.style.width = `${thumbWidth}px`;
      thumb.style.transform = `translateX(${thumbLeft}px)`;
      return;
    }

    const thumbHeight = Math.max(36, (scrollTarget.clientHeight / scrollTarget.scrollHeight) * track.height);
    const maxThumbTop = Math.max(0, track.height - thumbHeight);
    const maxScrollTop = Math.max(1, scrollTarget.scrollHeight - scrollTarget.clientHeight);
    const thumbTop = Math.min(maxThumbTop, Math.max(0, (scrollTarget.scrollTop / maxScrollTop) * maxThumbTop));

    bar.style.width = '6px';
    bar.style.height = `${track.height}px`;
    thumb.style.height = `${thumbHeight}px`;
    thumb.style.transform = `translateY(${thumbTop}px)`;
  }

  function show() {
    update();
    if (hasScrollableContent()) bar.classList.add('is-visible');
  }

  function hide() {
    if (active) return;
    bar.classList.remove('is-visible');
  }

  if (options.documentLevel) {
    document.addEventListener('mousemove', (event) => {
      if (event.target.closest && event.target.closest('.table-wrap')) {
        if (!active) hide();
        return;
      }
      show();
    }, { passive: true });
    document.addEventListener('mouseleave', hide);
  } else {
    target.addEventListener('mouseenter', () => {
      pointerInside = true;
      show();
    });
    target.addEventListener('mouseleave', () => {
      pointerInside = false;
      hide();
    });
  }

  scrollTarget.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);
  window.addEventListener('scroll', update, { passive: true });

  const resizeObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(update) : null;
  resizeObserver?.observe(scrollTarget);
  if (!options.documentLevel && target.firstElementChild) resizeObserver?.observe(target.firstElementChild);

  thumb.addEventListener('pointerdown', (event) => {
    const track = getTrackRect();
    const thumbRect = thumb.getBoundingClientRect();
    const maxThumbOffset = axis === 'x'
      ? Math.max(1, track.width - thumbRect.width)
      : Math.max(1, track.height - thumbRect.height);
    const maxScrollOffset = axis === 'x'
      ? Math.max(1, scrollTarget.scrollWidth - scrollTarget.clientWidth)
      : Math.max(1, scrollTarget.scrollHeight - scrollTarget.clientHeight);
    const startPointer = axis === 'x' ? event.clientX : event.clientY;
    const startScroll = axis === 'x' ? scrollTarget.scrollLeft : scrollTarget.scrollTop;

    event.preventDefault();
    thumb.setPointerCapture(event.pointerId);
    active = true;
    show();

    const handlePointerMove = (moveEvent) => {
      const currentPointer = axis === 'x' ? moveEvent.clientX : moveEvent.clientY;
      const delta = currentPointer - startPointer;
      const nextScroll = startScroll + (delta / maxThumbOffset) * maxScrollOffset;
      if (axis === 'x') {
        scrollTarget.scrollLeft = nextScroll;
      } else {
        scrollTarget.scrollTop = nextScroll;
      }
    };

    const handlePointerUp = () => {
      active = false;
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
      if (!options.documentLevel && !pointerInside) hide();
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);
  });

  update();
}

createFloatingScrollbar(document.documentElement, { documentLevel: true });
document.querySelectorAll('.table-wrap').forEach((wrap) => {
  createFloatingScrollbar(wrap, { axis: 'y' });
  createFloatingScrollbar(wrap, { axis: 'x' });
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('visible');
    entry.target.querySelectorAll('[data-chart-id]').forEach(initChart);
  });
}, { rootMargin: '140px 0px', threshold: 0.08 });

document.querySelectorAll('section').forEach((section) => revealObserver.observe(section));

window.addEventListener('resize', () => charts.forEach((chart) => chart.resize()));
window.addEventListener('load', () => {
  document.querySelectorAll('section').forEach((section) => {
    const rect = section.getBoundingClientRect();
    if (rect.top < window.innerHeight) section.classList.add('visible');
  });
  document.querySelectorAll('[data-chart-id]').forEach((el) => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight + 140) initChart(el);
  });
});
"""


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "error": message}, ensure_ascii=False), file=sys.stderr)
    raise SystemExit(code)


def e(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def inline(value: Any) -> str:
    if isinstance(value, dict) and "html" in value:
        return str(value["html"])
    return e(value)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8-sig")


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    payload = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{payload}"


def load_model(path: Path) -> dict[str, Any]:
    try:
        model = json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        fail(f"Invalid JSON model: {exc}")
    if not isinstance(model, dict):
        fail("Model root must be a JSON object")
    return model


def extract_style(template_path: Path, asset_dir: Path) -> str:
    template = read_text(template_path)
    match = re.search(r"<style>(.*?)</style>", template, flags=re.S)
    if not match:
        fail(f"No <style> block found in template: {template_path}")
    style = match.group(1)
    style = re.sub(r"\s*@import\s+url\([^)]+\);\s*", "\n", style)
    bg_path = asset_dir / "workbench-bg.png"
    if bg_path.exists():
        bg = data_uri(bg_path)
        style = re.sub(r"url\(['\"]?workbench-bg\.png['\"]?\)", f"url('{bg}')", style)
    return style


def model_uses_callout_color(model: dict[str, Any], colors: set[str]) -> bool:
    wanted = {color.lower() for color in colors}

    def visit(value: Any) -> bool:
        if isinstance(value, dict):
            if value.get("type") == "callout":
                override = str(value.get("colorOverride") or "").strip().lower()
                if override in wanted:
                    return True
            return any(visit(child) for child in value.values())
        if isinstance(value, list):
            return any(visit(item) for item in value)
        return False

    return visit(model)


def prune_unused_callout_color_styles(style: str, model: dict[str, Any]) -> str:
    if not model_uses_callout_color(model, {"gray", "grey"}):
        style = re.sub(r"\n\s*\.callout\.is-gray\s*\{[^}]*\}\n", "\n", style, flags=re.S)
    if not model_uses_callout_color(model, {"red"}):
        style = re.sub(r"\n\s*\.callout\.is-red\s*\{[^}]*\}\n", "\n", style, flags=re.S)
    return style


def load_echarts(asset_dir: Path) -> str:
    path = asset_dir / "echarts.min.js"
    if not path.exists():
        fail(f"Missing ECharts asset: {path}")
    return read_text(path)


def load_svg_icon(asset_dir: Path, name: str) -> str:
    path = asset_dir / name
    if not path.exists():
        fail(f"Missing icon asset: {path}")
    return data_uri(path)


def is_warning_badge_label(label: Any) -> bool:
    label_text = "" if label is None else str(label)
    return any(keyword in label_text for keyword in WARNING_BADGE_KEYWORDS)


def normalize_badge_tone(label: Any, tone: Any) -> str:
    tone_text = str(tone or "info")
    if tone_text not in ALLOWED_BADGE_TONES:
        return "info"
    if tone_text in COLORED_BADGE_TONES and not is_warning_badge_label(label):
        return "info"
    return tone_text


def css_size(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return f"{value:g}px"
    text = str(value).strip()
    if re.match(r"^\d+(?:\.\d+)?(?:px|%|rem|em|ch|vw)$", text):
        return text
    return ""


def value_highlight_class(item: dict[str, Any]) -> str:
    highlight = item.get("highlight", "")
    if isinstance(highlight, bool):
        if not highlight:
            return ""
        highlight = "high"
    text = str(highlight or "").strip().lower()
    if text in {"high", "danger", "red", "risk-high", "error"}:
        return "value-highlight-high"
    if text in {"mid", "warn", "warning", "orange", "risk-mid"}:
        return "value-highlight-mid"
    if text in {"ok", "success", "green", "risk-ok"}:
        return "value-highlight-ok"
    return ""


def render_badge(badge: Any) -> str:
    if not badge:
        return ""
    if isinstance(badge, str):
        label, tone = badge, "info"
    else:
        label = badge.get("label", "")
        tone = badge.get("tone", "info")
    if not str(label or "").strip():
        return ""
    tone = normalize_badge_tone(label, tone)
    return f'<span class="badge {e(tone)}">{e(label)}</span>'


def is_total_block(block: dict[str, Any]) -> bool:
    return block.get("type") in {"metrics", "callout"}


def split_section_blocks(blocks: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Keep at most one total block directly under the section header."""
    if not blocks:
        return [], []
    first = blocks[0]
    if not isinstance(first, dict) or not is_total_block(first):
        return [], blocks
    total = [first]
    detail = list(blocks[1:])
    if detail and isinstance(detail[0], dict) and detail[0].get("type") == "callout":
        detail = detail[1:]
    return total, detail


def render_header(model: dict[str, Any], building_icon: str) -> str:
    title = model.get("title") or "可视化报告"
    summary = model.get("summary") or model.get("subtitle") or ""
    return f"""
      <header class="report-title" id="top">
        <div class="hero-main">
          <div class="hero-icon" aria-hidden="true">
            <img src="{building_icon}" alt="">
          </div>
          <div class="hero-copy">
            <h1>{e(title)}</h1>
            <p class="hero-summary">{e(summary)}</p>
          </div>
        </div>
      </header>
"""


def render_kpis(model: dict[str, Any], info_icon: str) -> str:
    kpis = model.get("kpis") or []
    items = []
    for item in kpis:
        tone = item.get("tone", "")
        value_class = value_highlight_class(item)
        value_class_attr = f' class="value {e(value_class)}"' if value_class else ' class="value"'
        tooltip = item.get("tooltip", "")
        label = item.get("label", "")
        value = item.get("value", "")
        unit = item.get("unit", "")
        unit_html = f"<small>{e(unit)}</small>" if unit else ""
        tip_html = ""
        if tooltip:
            tip_html = (
                f'<button class="kpi-info" type="button" data-tooltip="{e(tooltip)}" '
                f'aria-label="{e(label)}说明"><img src="{info_icon}" alt=""></button>'
            )
        items.append(
            f"""
          <div class="kpi {e(tone)}">
            <div class="kpi-content">
              <div class="label"><span class="label-text">{e(label)}</span>{tip_html}</div>
              <div{value_class_attr}>{inline(value)}{unit_html}</div>
            </div>
          </div>"""
        )
    return '<div class="kpi-grid">' + "".join(items) + "\n        </div>"


def render_core_points(model: dict[str, Any]) -> str:
    points = model.get("corePoints") or []
    rendered = []
    for point in points:
        if isinstance(point, dict):
            lead = point.get("lead", "")
            text = point.get("text", "")
            rendered.append(f'<p class="core-point"><strong>{e(lead)}：</strong>{inline(text)}</p>')
        else:
            rendered.append(f'<p class="core-point">{inline(point)}</p>')
    return '<div class="hero-core">' + "".join(rendered) + "</div>" if rendered else ""


def render_summary_section(model: dict[str, Any], info_icon: str) -> str:
    return f"""
      <section id="summary" class="summary-module">
        <div class="section-head">
          <div class="section-head-main">
            <div class="section-head-row">
              <div class="cost-report-section-title"><span>01</span><h2>摘要</h2></div>
            </div>
          </div>
        </div>
        <div class="total-block">{render_kpis(model, info_icon)}</div>
        {render_core_points(model)}
      </section>
"""


def render_table_cell(cell: Any) -> str:
    if isinstance(cell, dict):
        classes = cell.get("class", "")
        if "badge" in cell:
            return f'<td class="{e(classes)}">{render_badge(cell["badge"])}</td>'
        if cell.get("numeric"):
            classes = (classes + " num").strip()
        if cell.get("nowrap"):
            classes = (classes + " nowrap").strip()
        return f'<td class="{e(classes)}">{inline(cell.get("text", ""))}</td>'
    return f"<td>{inline(cell)}</td>"


def render_colgroup(headers: list[Any], block: dict[str, Any]) -> str:
    column_widths = block.get("columnWidths")
    cols = []
    for index, header in enumerate(headers):
        width = ""
        if isinstance(column_widths, list) and index < len(column_widths):
            width = css_size(column_widths[index])
        if not width and isinstance(header, dict):
            width = css_size(header.get("width") or header.get("minWidth"))
        style = f' style="width:{e(width)}"' if width else ""
        cols.append(f"<col{style}>")
    return f"<colgroup>{''.join(cols)}</colgroup>" if cols else ""


def render_table(block: dict[str, Any]) -> str:
    title = block.get("title")
    headers = block.get("headers") or []
    rows = block.get("rows") or []
    head_cells = []
    for header in headers:
        if isinstance(header, dict):
            classes = []
            if header.get("numeric"):
                classes.append("num")
            if header.get("nowrap", True):
                classes.append("nowrap")
            extra_class = str(header.get("class", "")).strip()
            if extra_class:
                classes.append(extra_class)
            head_cells.append(f'<th class="{e(" ".join(classes))}">{e(header.get("label", ""))}</th>')
        else:
            head_cells.append(f'<th class="nowrap">{e(header)}</th>')
    body_rows = []
    for row in rows:
        cells = "".join(render_table_cell(cell) for cell in row)
        body_rows.append(f"<tr>{cells}</tr>")
    title_html = f'<h3 class="table-title">{e(title)}</h3>' if title else ""
    table_min_width = css_size(block.get("minWidth") or block.get("tableMinWidth"))
    table_style = f' style="min-width:{e(table_min_width)}"' if table_min_width else ""
    colgroup = render_colgroup(headers, block)
    return f"""
        <div class="table-block">
          {title_html}
          <div class="table-wrap">
            <table{table_style}>
              {colgroup}
              <thead><tr>{''.join(head_cells)}</tr></thead>
              <tbody>{''.join(body_rows)}</tbody>
            </table>
          </div>
        </div>
"""


def render_chart_grid(block: dict[str, Any]) -> str:
    columns = int(block.get("columns", 2))
    klass = "grid-3" if columns == 3 else "grid-2"
    panels = []
    for panel in block.get("panels") or []:
        chart_class = panel.get("chartClass", "")
        panels.append(
            f"""
          <div class="panel">
            <h3>{e(panel.get("title", ""))}</h3>
            <div class="chart {e(chart_class)}" data-chart-id="{e(panel.get("chartId", ""))}"></div>
          </div>"""
        )
    return f'<div class="{klass}">' + "".join(panels) + "\n        </div>"


def render_heat_panel(block: dict[str, Any]) -> str:
    rows = []
    for item in block.get("items") or []:
        percent = max(0, min(100, float(item.get("percent", 0))))
        rows.append(
            f"""
              <div class="heat-row"><div class="heat-name">{e(item.get("name", ""))}</div><div class="bar-track"><div class="bar" style="width:{percent:g}%"></div></div><strong>{e(item.get("value", ""))}</strong></div>"""
        )
    return f"""
          <div class="panel heat-panel">
            <h3>{e(block.get("title", "热度分布"))}</h3>
            <div class="heat-list">{''.join(rows)}
            </div>
            <div class="heat-legend" aria-hidden="true"><span><i></i>{e(block.get("legend", "异常热度"))}</span></div>
          </div>
"""


def render_mixed_grid(block: dict[str, Any]) -> str:
    columns = int(block.get("columns", 2))
    klass = "grid-3" if columns == 3 else "grid-2"
    children = []
    for child in block.get("items") or []:
        children.append(render_block(child))
    return f'<div class="{klass}">' + "".join(children) + "\n        </div>"


def render_summary_lines(block: dict[str, Any]) -> str:
    lines = []
    for item in block.get("items") or []:
        if isinstance(item, dict):
            lead = item.get("lead")
            text = item.get("text", "")
            if lead:
                lines.append(f'<p class="summary-line"><strong>{e(lead)}：</strong>{inline(text)}</p>')
            else:
                lines.append(f'<p class="summary-line">{inline(text)}</p>')
        else:
            lines.append(f'<p class="summary-line">{inline(item)}</p>')
    return '<div class="summary-lines">' + "".join(lines) + "</div>"


def render_metrics(block: dict[str, Any]) -> str:
    metrics = []
    for item in block.get("items") or []:
        highlight = value_highlight_class(item)
        value_class = f' class="{e(highlight)}"' if highlight else ""
        metrics.append(f'<div class="metric"><span>{e(item.get("label", ""))}</span><strong{value_class}>{inline(item.get("value", ""))}</strong></div>')
    return '<div class="trend-metrics">' + "".join(metrics) + "</div>"


def render_callout(block: dict[str, Any]) -> str:
    title = f'<h3>{e(block.get("title", ""))}</h3>' if block.get("title") else ""
    paragraphs = []
    for text in (block.get("paragraphs") or [])[:3]:
        paragraphs.append(f"<p>{inline(text)}</p>")
    color_override = str(block.get("colorOverride") or "").strip().lower()
    klass = "callout"
    klass += CALLOUT_COLOR_CLASSES.get(color_override, "")
    return f'<div class="{klass}">{title}{"".join(paragraphs)}</div>'


def render_chart_panel(block: dict[str, Any]) -> str:
    chart_class = block.get("chartClass", "")
    return f"""
          <div class="panel">
            <h3>{e(block.get("title", ""))}</h3>
            <div class="chart {e(chart_class)}" data-chart-id="{e(block.get("chartId", ""))}"></div>
          </div>
"""


def render_stack(block: dict[str, Any]) -> str:
    children = "".join(render_block(child) for child in block.get("items") or [])
    return f'<div class="stack-layout">{children}</div>'


def render_block(block: dict[str, Any]) -> str:
    kind = block.get("type")
    if kind == "table":
        return render_table(block)
    if kind == "chartGrid":
        return render_chart_grid(block)
    if kind == "mixedGrid":
        return render_mixed_grid(block)
    if kind == "heatPanel":
        return render_heat_panel(block)
    if kind == "summaryLines":
        return render_summary_lines(block)
    if kind == "metrics":
        return render_metrics(block)
    if kind == "callout":
        return render_callout(block)
    if kind == "chartPanel":
        return render_chart_panel(block)
    if kind == "stack":
        return render_stack(block)
    fail(f"Unsupported block type: {kind}")
    return ""


def render_section(section: dict[str, Any], index: int) -> str:
    number = section.get("number") or f"{index:02d}"
    summary = section.get("summary", "")
    raw_blocks = [block for block in (section.get("blocks") or []) if isinstance(block, dict)]
    total_blocks, detail_blocks = split_section_blocks(raw_blocks)
    total_html = f'<div class="total-block">{"".join(render_block(block) for block in total_blocks)}</div>' if total_blocks else ""
    blocks = total_html + "".join(render_block(block) for block in detail_blocks)
    return f"""
      <section id="{e(section.get("id", f"section-{index}"))}">
        <div class="section-head">
          <div class="section-head-main">
            <div class="section-head-row">
              <div class="cost-report-section-title"><span>{e(number)}</span><h2>{e(section.get("title", ""))}</h2></div>
            </div>
            <p class="section-summary">{inline(summary)}</p>
          </div>
        </div>
        {blocks}
      </section>
"""


def js_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def build_html(model: dict[str, Any], template: Path, asset_dir: Path) -> str:
    title = model.get("title") or "可视化报告"
    style = prune_unused_callout_color_styles(extract_style(template, asset_dir), model)
    echarts_js = load_echarts(asset_dir)
    building_icon = load_svg_icon(asset_dir, "building-fill.svg")
    info_icon = load_svg_icon(asset_dir, "info-circle.svg")

    body_parts = [
        '<div class="shell">',
        '<main class="content">',
        render_header(model, building_icon),
        render_summary_section(model, info_icon),
    ]
    for index, section in enumerate(model.get("sections") or [], start=2):
        body_parts.append(render_section(section, index))
    body_parts.extend(["</main>", "</div>"])

    charts = model.get("charts") or {}
    chart_script = "<script>\nconst chartOptions = " + js_json(charts) + ";\n" + RUNTIME_JS + "\n</script>"

    return "\n".join(
        [
            "<!doctype html>",
            '<html lang="zh-CN">',
            "<head>",
            '  <meta charset="utf-8" />',
            '  <meta name="viewport" content="width=device-width, initial-scale=1" />',
            f"  <title>{e(title)}</title>",
            "  <script>",
            echarts_js,
            "  </script>",
            "  <style>",
            style,
            "  </style>",
            "</head>",
            "<body>",
            *body_parts,
            chart_script,
            "</body>",
            "</html>",
        ]
    )


def collect_chart_ids(model: dict[str, Any]) -> set[str]:
    ids: set[str] = set()

    def visit_block(block: dict[str, Any]) -> None:
        chart_id = block.get("chartId")
        if chart_id:
            ids.add(str(chart_id))
        for key in ("panels", "items"):
            value = block.get(key)
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        visit_block(item)

    for section in model.get("sections") or []:
        for block in section.get("blocks") or []:
            visit_block(block)
    return ids


def validate_output(html_text: str, model: dict[str, Any]) -> list[str]:
    warnings: list[str] = []
    used_ids = collect_chart_ids(model)
    defined_ids = set((model.get("charts") or {}).keys())
    missing = sorted(used_ids - defined_ids)
    unused = sorted(defined_ids - used_ids)
    if missing:
        warnings.append("Missing chart options for: " + ", ".join(missing))
    if unused:
        warnings.append("Unused chart options: " + ", ".join(unused))
    if re.search(r"__(?:REPORT|PLACEHOLDER|TITLE|CONTENT|CHART|SECTION)[A-Z0-9_]*__", html_text):
        warnings.append("Possible template placeholder token remains")
    if re.search(r"<script[^>]+\bsrc\s*=", html_text, flags=re.I):
        warnings.append("External script tag remains")
    if re.search(r"<link[^>]+\bhref\s*=", html_text, flags=re.I):
        warnings.append("External link tag remains")
    for attr, value in re.findall(r"\b(src|href)\s*=\s*['\"]([^'\"]+)['\"]", html_text, flags=re.I):
        if not (value.startswith("data:") or value.startswith("#")):
            warnings.append(f"External {attr} reference remains: {value[:80]}")
            break
    if re.search(r"url\(['\"]?https?://", html_text, flags=re.I):
        warnings.append("Remote CSS url remains")
    return warnings


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a single-file HTML visual report from report-model JSON.")
    parser.add_argument("--model", required=True, help="Path to report-model JSON authored by the agent.")
    parser.add_argument("--output", required=True, help="Output .html path.")
    parser.add_argument("--template", default=str(DEFAULT_TEMPLATE), help="Visual mother-template HTML path.")
    parser.add_argument("--asset-dir", default=str(DEFAULT_ASSET_DIR), help="Directory containing ECharts and visual assets.")
    args = parser.parse_args()

    model_path = Path(args.model).resolve()
    output_path = Path(args.output).resolve()
    template = Path(args.template).resolve()
    asset_dir = Path(args.asset_dir).resolve()

    if not model_path.exists():
        fail(f"Model file does not exist: {model_path}")
    if not template.exists():
        fail(f"Template file does not exist: {template}")
    if not asset_dir.exists():
        fail(f"Asset directory does not exist: {asset_dir}")

    model = load_model(model_path)
    html_text = build_html(model, template, asset_dir)
    warnings = validate_output(html_text, model)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html_text, encoding="utf-8")

    result = {
        "ok": not any(item.startswith("Missing chart") or item.startswith("External reference") for item in warnings),
        "output": str(output_path),
        "singleFile": True,
        "sizeBytes": output_path.stat().st_size,
        "sections": 1 + len(model.get("sections") or []),
        "charts": len(model.get("charts") or {}),
        "warnings": warnings,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["ok"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
