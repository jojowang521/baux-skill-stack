#!/usr/bin/env python3
"""Theme selection must preserve report facts and reject unsupported settings."""
import json,shutil,tempfile
from pathlib import Path
from build_report import build
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as t:
 base=Path(t)/'examples';shutil.copytree(ROOT/'examples',base);src=base/'support.report.json';d=json.loads(src.read_text());blue=build(src,Path(t)/'blue.html')
 d['presentation']['theme']='orange-white';src.write_text(json.dumps(d,ensure_ascii=False));before=src.read_bytes();orange=build(src,Path(t)/'orange.html')
 assert src.read_bytes()==before and orange['counts']==blue['counts']
 assert 'orange-white' in (Path(t)/'orange.html').read_text()
 d['presentation']['theme']='unsupported';src.write_text(json.dumps(d));bad=Path(t)/'bad.html'
 try:build(src,bad)
 except ValueError as e:assert 'theme' in str(e) and not bad.exists()
 else:raise AssertionError('Unknown theme accepted')
print('3 theme checks passed: theme rendering, unchanged facts, unsupported theme blocked.')
