#!/usr/bin/env python3
"""Create a brief-only workspace, without inventing findings, maps or test results."""
import argparse,json,shutil
from datetime import date
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def initialize(name,scenario,directory):
 directory=Path(directory).resolve()
 if directory.exists():raise ValueError('请使用新的报告目录，避免覆盖已有材料。')
 d=json.loads((ROOT/'examples/brief-only.report.json').read_text())
 d['$schema']='schema/report.schema.json'
 d['metadata'].update(id='product-experience-report',title=name+'产品体验评估报告',authored_on=date.today().isoformat())
 d['content']['product'].update(id='product',name=name,description='根据当前需求建立的待补材料框架。',business_goals=[])
 d['content']['scope'].update(scenario=scenario,in_scope=[],out_of_scope=[])
 d['content']['sources'][0].update(title='当前用户需求',path='sources/brief.txt',note='仅记录用户指定的产品及场景。')
 directory.mkdir(parents=True);(directory/'sources').mkdir();(directory/'schema').mkdir()
 shutil.copy2(ROOT/'data/report.schema.json',directory/'schema/report.schema.json')
 (directory/'sources/brief.txt').write_text(f'产品：{name}\n场景：{scenario}\n',encoding='utf-8')
 target=directory/'report.json';target.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return target
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--name',required=True);p.add_argument('--scenario',required=True);p.add_argument('--directory',required=True,type=Path);a=p.parse_args()
 try:print(initialize(a.name,a.scenario,a.directory))
 except (OSError,ValueError) as e:p.exit(2,str(e)+'\n')
