#!/usr/bin/env python3
"""Author explicitly simulated regression fixtures; never run on user research."""
import copy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; EX=ROOT/'examples'
base=json.loads((EX/'brief-only.report.json').read_text()); map_base=json.loads((EX/'procurement.journey.json').read_text())

def save(path,d): path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def stmt(text,ids=None,basis='simulated'): return {'text':text,'basis':basis,'evidence_ids':ids or []}
def create(slug,name,scenario,role_specs,module_specs,issue_specs,journey_specs,decide=False):
 d=copy.deepcopy(base); c=d['content']; r=d['rules']; sid=slug+'-simulation'; source_path='sources/'+slug+'.simulated.txt'
 snapshot={'label':'模拟候选版场景','product_version':'演示版 1.0','recorded_at':None}
 d['metadata'].update(id=slug,title=name+'产品体验评估与验收报告',input_mode='simulated_material',content_nature='simulated',assessment_snapshot=snapshot,status_snapshot=copy.deepcopy(snapshot))
 c['product']={'id':slug,'name':name,'version':'演示版 1.0','description':scenario,'business_goals':['使核心任务可理解、可跟进、可恢复']}
 c['scope']={'purpose':'检验通用报告跨产品表达能力','scenario':scenario,'in_scope':[x[1] for x in module_specs],'out_of_scope':['实际性能测试','真实组织权限审计'],'start':journey_specs[0]['stages'][0][0],'end':journey_specs[0]['stages'][-1][0]}
 c['sources']=[{'id':sid,'title':name+'模拟研究材料','kind':'other','nature':'simulated','path':source_path,'source_date':None,'note':'人工构造的验证场景，无实际访谈或测试执行。'}]
 source_lines=['# '+name+' · 模拟材料','以下记录全部为验证模板构造；没有真实用户、执行时间或样本量。', 'CTX '+scenario]
 c['roles']=[{'id':id,'name':title,'is_primary':i==0,'goals':[goal],'contexts':['桌面端处理工作任务'],'permissions':permission,'evidence_ids':['EV-CTX']} for i,(id,title,goal,permission) in enumerate(role_specs)]
 c['modules']=[{'id':id,'name':title,'parent_id':None,'description':desc,'in_scope':True} for id,title,desc in module_specs]
 def ev(id,text,loc,kind='behavior'):
  c['evidence'].append({'id':id,'kind':kind,'nature':'simulated','summary':text,'source_refs':[{'source_id':sid,'locator':loc,'excerpt':text}],'observed_at':None,'product_version':None,'note':'模拟记录，不构成实际执行证明。'})
 ev('EV-CTX',scenario,'CTX','scenario_context')
 r['categories']=[{'id':'interaction','name':'交互反馈','definition':'入口、状态与操作反馈的理解问题。'},{'id':'workflow','name':'流程衔接','definition':'任务交接、恢复与闭环问题。'}]
 r['severities']=[{'id':'major','name':'关键阻断','rank':1,'definition':'核心任务在此场景无法继续。','release_blocker':True},{'id':'minor','name':'体验改进','rank':2,'definition':'任务可完成但有额外理解和沟通成本。','release_blocker':False}]
 r['statuses']=[{'id':'triaged','name':'已确认待处理','is_closed':False,'requires_confirmation':False},{'id':'verifying','name':'待验证修复','is_closed':False,'requires_confirmation':True}]
 for n,(title,module,role,category,severity,phenomenon,impact,proposal) in enumerate(issue_specs,1):
  fid=f'{slug.upper()}-{n:02}'; evid=f'EV-{n:02}'; req=f'REQ-{n:02}'; case=f'TC-{n:02}'
  source_lines.append(f'{evid} {phenomenon}'); ev(evid,phenomenon,evid,'test_result')
  c['requirements'].append({'id':req,'title':title+'的预期','criterion':proposal,'module_ids':[module],'basis':'proposed','evidence_ids':['EV-CTX']})
  c['cases'].append({'id':case,'title':'检查：'+title,'role_ids':[role],'requirement_ids':[req],'detail_level':'summary','preconditions':None,'steps':[],'expected':proposal,'actual':phenomenon,'result':'failed','evidence_ids':[evid],'executed_at':None,'product_version':None})
  c['findings'].append({'id':fid,'title':title,'module_id':module,'role_ids':[role],'primary_category_id':category,'dimension_ids':['feedback','continuity'],'phenomenon':stmt(phenomenon,[evid]),'impact':stmt(impact,[evid],'analyst_inference'),'expected_behavior':proposal,'severity_id':severity,'severity_reason':'按模拟任务能否继续分级，正式等级待业务确认。','status_id':'triaged','status_evidence_ids':[evid],'state_snapshot':copy.deepcopy(snapshot),'case_ids':[case],'requirement_ids':[req],'owner_role':None,'note':'模拟发现，未实际测试产品。'})
  c['recommendations'].append({'id':f'OP-{n:02}','proposal':stmt(proposal,[evid],'design_hypothesis'),'finding_ids':[fid],'priority':None,'priority_reason':None,'owner_role':None,'target_version':None,'target_date':None,'note':'需验证方案对任务的影响。'})
 for dim in ['feedback','continuity']:
  c['assessments'].append({'id':'ASSESS-'+dim,'dimension_id':dim,'summary':stmt('场景中存在状态理解或任务衔接问题，尚无真实材料验证。',[f'EV-{i:02}' for i in range(1,len(issue_specs)+1)]),'finding_ids':[f['id'] for f in c['findings']],'coverage':'partial','note':'其他维度未检查。'})
 c['decision']={'kind':'simulated' if decide else 'not_assessed','result':'failed' if decide else 'undetermined','scope_note':'仅模拟演示，不形成真实产品上线结论。','rationale':stmt('模拟场景仍有关键任务阻断。' if decide else '材料为模拟、门槛未确认，保留评估框架，不作验收判定。',[f['id'] for f in c['evidence']]),'gate_evaluations':[],'limitations':['没有真实访谈、测试执行和完整覆盖记录。'],'risk_acceptances':[]}
 if decide:
  r['acceptance']={'applicable':True,'gates':[{'id':'G1','title':'核心任务可完成','criterion':'关键阻断项须解决并复验。','mandatory':True,'basis':'proposed','requirement_ids':[x['id'] for x in c['requirements']],'evidence_ids':['EV-CTX']}],'note':'门槛为模拟提议，须业务确认。'}
  c['decision']['gate_evaluations']=[{'gate_id':'G1','result':'not_satisfied','evidence_ids':['EV-01'],'note':'模拟场景有关键阻断。'}]
 c['missing_information']=[{'id':'GAP-REAL','area':'研究与测试','description':'没有真实用户研究或实际执行证据。','effect':'不能用于真实产品验收。','blocks_acceptance':True},{'id':'GAP-CRITERIA','area':'验收口径','description':'门槛和等级尚未获业务确认。','effect':'需确认后另行评估。','blocks_acceptance':True}]
 for ix,spec in enumerate(journey_specs,1):
  role=next(x for x in c['roles'] if x['id']==spec['role']); mid=slug+'-journey-'+str(ix); mp=mid+'.json'
  m=copy.deepcopy(map_base); m['map_id']=mid
  m['sources']=[{'id':sid,'type':'text','filename':Path(source_path).name,'path':source_path,'role':'simulated_research_material','locator_method':'record_id'}]
  ref=lambda loc:[{'source_id':sid,'locator':loc}]
  m['provenance'].update(note='全部为模拟内容；人物感受与行为均未经过真实研究验证。',normalization=['每张地图只表达一个角色。','未知情绪留空，数值评分不补造。'])
  m['overview']['title']=name+' · '+role['name']+'体验地图'; m['overview']['subtitle']=scenario; m['overview']['vision']={'text':role['goals'][0],'supporting_text':'模拟场景 · 待验证','kind':'design_hypothesis'}; m['overview']['source_refs']=ref('CTX')
  m['summary']['persona'].update(role=role['name'],goals=role['goals'],usage_context={'source_text':'桌面端工作场景','devices':['PC'],'work_contexts':['工作场所']},source_refs=ref('CTX'))
  myissues=[c['findings'][i-1] for i in spec['issues'].values()]
  m['summary']['core_problems'].update(items=[x['title'] for x in myissues],source_refs=ref('CTX'))
  m['summary']['optimization_directions'].update(items=[x['expected_behavior'] for x in myissues],source_refs=ref('CTX'))
  m['task']={'primary_role':role['name'],'scenario':scenario,'start':spec['stages'][0][0],'end':spec['stages'][-1][0],'purpose':'呈现模拟任务与体验阻碍，验证跨产品结构。','map_state':'hypothesis','assumptions':['行为与情绪均为模拟，情绪只有定性假设。']}
  m['stages']=[]; links=[]
  for n,(title,goal,activity,touchpoint) in enumerate(spec['stages'],1):
   stage=copy.deepcopy(map_base['stages'][0]); stid=f'stage-{n:02}'; loc=f'M{ix}-{n:02}'
   source_lines.append(f'{loc} {role["name"]}：{title}；目标：{goal}；行为：{activity}；接触点：{touchpoint}。'+('情绪未记录。' if n==3 else '定性情绪为模拟假设。'))
   stage.update(id=stid,order=n,name=title,source_refs=ref(loc),user_goal=goal,activities=[{'id':stid+'-a1','text':activity,'evidence_status':'simulated_observation','source_refs':ref(loc)}],touchpoints={'source_text':touchpoint,'items':[touchpoint],'source_refs':ref(loc)},pain_points=[],opportunities=[])
   stage['emotion']=copy.deepcopy(map_base['stages'][4]['emotion']) if n==3 else {'caption':'中性' if n not in spec['issues'] else '低落','caption_kind':'analyst_summary','score':None,'visual_interpretation':{'label':'中性' if n not in spec['issues'] else '低落','status':'hypothesis'},'source_refs':ref(loc)}
   stage['pain_opportunity_relation']['note']='同阶段分组，改善建议尚未验证。'
   if n in spec['issues']:
    issue=c['findings'][spec['issues'][n]-1]; op=c['recommendations'][spec['issues'][n]-1]; evidence=issue['phenomenon']['evidence_ids'][0]
    stage['pain_points']=[{'id':issue['id'],'text':issue['title'],'evidence_status':'analysis_from_simulated_material','source_refs':ref(evidence)}]
    stage['opportunities']=[{'id':op['id'],'text':op['proposal']['text'],'evidence_status':'design_hypothesis','source_refs':ref(evidence)}]
    links.append({'stage_id':stid,'finding_id':issue['id'],'relation':'experienced','note':'模拟角色任务中的体验问题。'})
   m['stages'].append(stage)
  m['branches']=[{'id':'return-1','from_stage_id':f'stage-{spec["return"][0]:02}','to_stage_id':f'stage-{spec["return"][1]:02}','label':spec['return'][2],'condition':spec['return'][3],'source_refs':ref('CTX')}]
  source_lines.append('CTX 路径：'+spec['return'][3]+'时'+spec['return'][2]+'。')
  m['presentation'].update(highlighted_stage_ids=[],highlight_meaning="未突出特定阶段",source_refs=ref('CTX'))
  m['missing_information']=[{'field':'research','note':'没有真实研究。'},{'field':'emotion','note':'第三阶段情绪未记录，其余仅为模拟定性假设。'}]
  save(EX/mp,m)
  c['journeys'].append({'id':mid,'title':role['name']+'完整体验地图','role_id':role['id'],'map_file':mp,'map_state':'hypothesis','snapshot':copy.deepcopy(snapshot),'finding_links':links,'note':'多角色分别呈现，不能将两张地图的痛点相加当作独立问题数。'})
 (EX/source_path).write_text('\n\n'.join(source_lines)+'\n',encoding='utf-8'); save(EX/(slug+'.report.json'),d)

create('support','协答客服工单平台','员工提交设备故障工单，由客服受理、协调处理并确认关闭。',
 [('requester','报障员工','让设备故障得到解决并知道进展','仅查看本人的工单'),('agent','客服专员','持续跟进任务直到确认解决','处理分配给本组的工单')],
 [('intake','工单提交','记录故障与附件'),('queue','受理与转派','分派责任并协作处理'),('tracking','跟进与关闭','通知结果、重开与归档')],
 [('重试提交产生重复工单','intake','requester','workflow','major','员工提交失败后重试，列表中出现两条相同故障工单。','可能重复分派并造成协作冲突。','提供幂等提交与明确的重试结果。'),('转派缺少交接说明','queue','agent','workflow','minor','接手工单的客服看不到转派原因，需再次询问前一位客服。','增加交接沟通和重复排查。','在转派时记录原因、已完成动作和待办。'),('关闭后找不到重开入口','tracking','requester','interaction','minor','故障再次出现时，员工在已关闭工单中找不到继续处理入口。','可能新建重复工单，历史排查中断。','在可重开期限内提供重开入口及规则。')],
 [{'role':'requester','stages':[('描述问题','明确故障','整理报错与截图','服务入口'),('提交工单','成功登记','填写表单并提交','提交页'),('等待受理','知道谁负责','查看受理状态','我的工单'),('配合处理','帮助定位故障','补充日志与说明','工单会话'),('确认结果','确认设备恢复','验证并关闭或重开','工单详情')],'issues':{2:1,5:3},'return':(5,4,'重开并补充记录','故障仍存在')},
 {'role':'agent','stages':[('领取任务','确认待办','查看待分配队列','工单工作台'),('判断问题','明确处理路径','查看分类与历史记录','工单详情'),('协作转派','完成责任交接','转派并交接说明','转派面板'),('执行处理','解决故障','记录排查与解决动作','处理记录'),('请求确认','获得结果确认','通知员工验证','通知中心'),('关闭归档','沉淀解决过程','确认关闭并整理知识','归档页')],'issues':{3:2},'return':(5,4,'继续排查','员工反馈未解决')}],True)
create('publishing','知页内容发布平台','内容编辑撰写知识文章，提交审核，按计划发布并查看结果。',
 [('editor','内容编辑','确保正确版本按计划发布','编辑自己的草稿并查看审核结果')],
 [('editor','内容编辑器','撰写、预览与管理版本'),('review','审核协作','审核意见与修改提交'),('publish','发布管理','排期、撤回与状态查询')],
 [('退回意见没有定位到正文','review','editor','interaction','minor','审核意见只有汇总文字，编辑需要反复查找对应段落。','增加定位与修改成本。','将意见关联正文片段，并保留版本上下文。'),('排期变更缺少时区说明','publish','editor','interaction','minor','编辑更改发布时间时，界面没有说明时区。','不同地区协作可能对发布时间产生不同理解。','在排期与确认中明确时区及本地时间。')],
 [{'role':'editor','stages':[('撰写草稿','形成完整内容','编辑正文并预览','编辑器'),('提交审核','获得明确反馈','提交稿件并查看退回意见','审核面板'),('安排发布','确认发布时间','选择时间与发布范围','发布设置'),('跟踪结果','确认内容可访问','检查发布状态与访问入口','发布列表')],'issues':{2:1,3:2},'return':(2,1,'修改后再次提交','审核退回')}])
print('Created support (2 maps) and publishing (1 map) simulated fixtures.')
