#!/usr/bin/env python3
"""Validate a product experience contract and generate a portable HTML report (stdlib)."""
from __future__ import annotations
import argparse
import base64
from collections import Counter
import copy
import html
import json
from pathlib import Path
import render_layout as layout
from validate_report import validate, safe_file

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'
THEMES = json.loads((ASSETS / 'themes/registry.json').read_text(encoding='utf-8'))
LABEL = {
 'real':'真实材料','simulated':'模拟材料','hypothesis':'假设版','mixed':'混合材料','unverified':'未核验',
 'actual':'实际判定','not_assessed':'尚未评估','passed':'通过','conditional':'有条件通过','failed':'未通过',
 'undetermined':'暂无法判定','not_applicable':'不适用','pending_retest':'待复验','not_run':'未执行','blocked':'受阻','unknown':'未知',
 'observed':'真实观察','reported':'用户报告','analyst_inference':'分析推断','design_hypothesis':'设计假设',
 'reference_transcription':'原稿转录','confirmed':'已确认','proposed':'拟议，待确认','inherited_unverified':'继承但未核验',
 'satisfied':'满足','not_satisfied':'未满足','reviewed':'已检查','partial':'部分检查','not_reviewed':'未检查',
 'current_state':'现状','future_state':'未来状态','brief':'需求说明','summary':'概要记录','reproducible':'可复现记录',
 'approved':'已批准','rejected':'未批准',
}

def e(value): return html.escape(str(value if value is not None else ''), quote=True)
def label(value): return LABEL.get(value, value or '待补充')
def decision_kind(value): return '模拟判定' if value=='simulated' else label(value)
def aid(kind, value): return kind + '-' + base64.urlsafe_b64encode(str(value).encode()).decode().rstrip('=')
def js(value): return json.dumps(value, ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e')
def raw(value): return {'html':value}
def joined(value): return '；'.join(map(str,value)) if value else '待补充'
def lines(*items): return {'type':'summaryLines','items':list(items)}
def callout(title, *paragraphs): return {'type':'callout','title':title,'paragraphs':list(paragraphs)}
def table(title, headers, rows, collapsed=False):
 return {'type':'table','title':title,'headers':headers,'rows':[[{'text':cell} if isinstance(cell,dict) and 'html' in cell else cell for cell in row] for row in rows],'minWidth':max(640,len(headers)*150),'collapse':collapsed}

def make_model(data, base, checked):
 c=data['content']; r=data['rules']; p=data['presentation']; meta=data['metadata']; counts=checked['counts']
 theme=THEMES[p['theme']]
 indexes={k:{x['id']:x for x in c[k]} for k in ['roles','modules','sources','evidence','findings','requirements','cases']}
 defs={k:{x['id']:x for x in r[k]} for k in ['categories','dimensions','severities','statuses']}
 names=lambda kind,value: defs[kind].get(value,{}).get('name', '未分类' if kind=='categories' else '未指定')
 visible_kinds=set()
 availability={'users':bool(c['roles']),'journeys':bool(c['journeys']),'assessment':bool(c['assessments']),
  'findings':bool(c['findings']),'statistics':bool(c['findings'] or c['cases']), 'recommendations':bool(c['recommendations']),
  'criteria':bool(c['requirements'] or r['acceptance']['gates']), 'cases':bool(c['cases']),'evidence':bool(c['sources'] or c['evidence'])}
 selected=[]
 for group in p['groups']:
  views=[]
  for v in group['modules']:
   available=availability.get(v['kind'],True)
   if v['visibility']=='hide' or (not available and (v['visibility']=='when_available' or v['empty_policy']=='omit')): continue
   views.append(v); visible_kinds.add(v['kind'])
  if views: selected.append((group,views))
 # Anchors belong to the first view of a kind; repeated views remain safe.
 emitted=set()
 def anchor(kind,id,text):
  key=(kind,id)
  if key in emitted: return raw(e(text))
  emitted.add(key)
  return raw(f'<span id="{aid(kind,id)}">{e(text)}</span>')
 target_view={'evidence':'evidence','finding':'findings','requirement':'criteria','case':'cases'}
 def refs(kind,ids):
  if not ids: return '未提供'
  return raw('、'.join(f'<a href="#{aid(kind,x)}">{e(x)}</a>' if target_view[kind] in visible_kinds else e(x) for x in ids))
 def statement(s):
  if not s: return '待补充'
  evidence=refs('evidence',s['evidence_ids']); evidence=evidence.get('html') if isinstance(evidence,dict) else e(evidence)
  return raw(e(s['text'])+f'<small class="basis">{e(label(s["basis"]))} · 依据：{evidence}</small>')
 def snapshot(s): return f'{s["label"]} · 版本：{s["product_version"] or "未知"} · 时间：{s["recorded_at"] or "未记录"}'
 maps=[]; charts={}
 def blocks(kind,v):
  collapse=v['details_collapsed'] and p['detail_level']=='overview'
  if kind=='scope':
   s=c['scope']
   return [lines({'lead':'评估目的','text':s['purpose']},{'lead':'任务场景','text':s['scenario']},
    {'lead':'范围内','text':joined(s['in_scope'])},{'lead':'范围外','text':joined(s['out_of_scope'])},
    {'lead':'起点 → 终点','text':f'{s["start"] or "待确认"} → {s["end"] or "待确认"}'},
    {'lead':'体验快照','text':snapshot(meta['assessment_snapshot'])},{'lead':'状态快照','text':snapshot(meta['status_snapshot'])})]
  if kind=='product':
   product=c['product']
   def module_path(m):
    parts=[m['name']]; parent=m['parent_id']
    while parent: a=indexes['modules'][parent]; parts.insert(0,a['name']); parent=a['parent_id']
    return ' / '.join(parts)
   out=[lines(product['description'],{'lead':'业务目标','text':joined(product['business_goals'])})]
   if c['modules']: out.append(table('产品功能框架',['模块层级','职责','本轮范围'],[[module_path(m),m['description'],'范围内' if m['in_scope'] else '范围外'] for m in c['modules']]))
   else: out.append(callout('产品框架待补充','没有提供模块信息，不能据此推断功能覆盖。'))
   return out
  if kind=='users': return [table('角色与目标',['角色','任务目标','使用情境','权限边界','依据'],[[x['name']+(' · 主角色' if x['is_primary'] else ''),joined(x['goals']),joined(x['contexts']),x['permissions'] or '待确认',refs('evidence',x['evidence_ids'])] for x in c['roles']])]
  if kind=='journeys':
   out=[]
   for j in c['journeys']:
    map_data=json.loads(safe_file(base,j['map_file']).read_text(encoding='utf-8'))
    map_data=copy.deepcopy(map_data)
    # Findings are canonical. Preserve map evidence references and stage grouping.
    for stage in map_data['stages']:
     for pain in stage['pain_points']:
      f=indexes['findings'][pain['id']]
      pain['text']=f'{f["id"]} {f["title"]}（{names("statuses",f["status_id"])}）'
    map_data['summary']['persona']['role']=indexes['roles'][j['role_id']]['name']
    document=(ASSETS/'journey-template.html').read_text()
    if theme['journey_css']:
     theme_css=(ASSETS/'themes'/theme['journey_css']).read_text()
     document=document.replace('</style>',theme_css+'\n</style>',1)
    document=document.replace('__JOURNEY_DATA__',js(map_data))
    if not p['journey_view']['show_sources']:
     # Disable only the source popover, leaving map content and downloads usable.
     document=document.replace('function show(title,body){','function show(title,body){return; ',1)
     document=document.replace('</head>','<style>#sources-button{display:none!important}[data-inspect]{cursor:default!important}</style></head>',1)
    token='map-slot-'+str(len(maps)+1)
    maps.append({'token':token,'document':document,'data':map_data,'journey':j,'options':p['journey_view']})
    out.extend([lines({'lead':j['title'],'text':f'{label(j["map_state"])} · {snapshot(j["snapshot"])}'},j['note']),{'type':'mapMount','token':token}])
   return out
  if kind=='assessment':
   assessment_by_dim={x['dimension_id']:x for x in c['assessments']}
   return [table('按体验维度归纳',['维度','检查范围','评价','相关问题'],[[d['name'],label(assessment_by_dim[d['id']]['coverage']),statement(assessment_by_dim[d['id']]['summary']),refs('finding',assessment_by_dim[d['id']]['finding_ids'])] if d['id'] in assessment_by_dim else [d['name'],'未检查','没有评价记录','—'] for d in r['dimensions']]),callout('维度口径','同一问题可以影响多个维度，维度数量不可相加作为问题总数。')]
  if kind=='findings':
   module_counts=Counter(f['module_id'] for f in c['findings'])
   out=[table('模块反馈概览',['模块','问题数','问题'],[[indexes['modules'].get(k,{}).get('name','未指定模块'),n,refs('finding',[f['id'] for f in c['findings'] if f['module_id']==k])] for k,n in module_counts.items()])]
   rows=[]
   for f in c['findings']:
    rows.append([anchor('finding',f['id'],f['id']+' '+f['title']),
     indexes['modules'].get(f['module_id'],{}).get('name','未指定'),
     names('categories',f['primary_category_id'])+' / '+joined([names('dimensions',x) for x in f['dimension_ids']]),
     statement(f['phenomenon']),statement(f['impact']),
     names('severities',f['severity_id'])+' / '+(f['severity_reason'] or '理由待补'),
     raw(e(names('statuses',f['status_id']))+'<small class="basis">'+e(snapshot(f['state_snapshot']))+'</small>'+e('负责人：'+(f['owner_role'] or '待定'))),
     refs('case',f['case_ids']),refs('requirement',f['requirement_ids']),refs('evidence',f['status_evidence_ids']),
     f['expected_behavior'] or '待补充', f['note']])
   out.append(table('逐项问题明细',['问题','模块','分类 / 维度','现象及依据','影响判断','严重程度 / 理由','当前状态','用例','要求','状态依据','期望行为','备注'],rows,collapse))
   return out
  if kind=='statistics':
   out=[callout('统计口径','按唯一问题ID计数；未分类单独列出。关闭依据状态定义；未关闭阻断项依据配置等级判断。','下列数字只描述已有记录，不代表研究样本量、发生频率或产品整体质量。')]
   for field,defs_key,title in [('primary_category','categories','问题主分类'),('severity','severities','严重程度'),('status','statuses','处理状态'),('case_results',None,'用例结果')]:
    counter=counts[field]
    if not counter: continue
    pairs=[(names(defs_key,k) if defs_key else label(k),n) for k,n in counter.items()]
    chartid=aid('chart',v['id']+'-'+field)
    charts[chartid]={'tooltip':{'trigger':'axis'},'legend':{'show':False},'xAxis':{'type':'category','data':[x[0] for x in pairs],'axisLabel':{'interval':0}},'yAxis':{'type':'value','minInterval':1},'series':[{'type':'bar','barMaxWidth':42,'data':[x[1] for x in pairs],'label':{'show':True,'position':'top'}}]}
    out.append({'type':'chartPanel','title':title,'chartId':chartid})
   return out
  if kind=='recommendations': return [table('改善建议（方案仍需验证）',['建议','相关问题','优先级及理由','负责人 / 计划','备注'],[[statement(x['proposal']),refs('finding',x['finding_ids']),(x['priority'] or '未排期')+' / '+(x['priority_reason'] or '待确认'),f'{x["owner_role"] or "待定"} / {x["target_version"] or "版本待定"} / {x["target_date"] or "日期待定"}',x['note']] for x in c['recommendations']])]
  if kind=='decision':
   d=c['decision']; out=[callout(decision_kind(d['kind'])+' · '+label(d['result']),d['scope_note'],statement(d['rationale'])),lines(*d['limitations'])]
   if d['gate_evaluations']: out.append(table('门槛核对',['门槛','结果','说明','依据'],[[next(g['title'] for g in r['acceptance']['gates'] if g['id']==x['gate_id']),label(x['result']),x['note'],refs('evidence',x['evidence_ids'])] for x in d['gate_evaluations']]))
   if c['missing_information']: out.append(table('材料与覆盖缺口',['领域','缺失','影响','妨碍正式验收'],[[x['area'],x['description'],x['effect'],'是' if x['blocks_acceptance'] else '否'] for x in c['missing_information']]))
   if d['risk_acceptances']: out.append(table('风险接受记录',['问题','理由','批准状态','批准人','依据'],[[refs('finding',x['finding_ids']),x['reason'],label(x['approval_status']),x['approved_by'] or '待确认',refs('evidence',x['evidence_ids'])] for x in d['risk_acceptances']]))
   return out
  if kind=='criteria':
   out=[callout('验收适用范围',r['acceptance']['note'])]
   if r['acceptance']['gates']: out.append(table('判定门槛',['门槛','条件','必需','确认程度','关联要求','依据'],[[x['title'],x['criterion'],'是' if x['mandatory'] else '否',label(x['basis']),refs('requirement',x['requirement_ids']),refs('evidence',x['evidence_ids'])] for x in r['acceptance']['gates']]))
   if c['requirements']: out.append(table('要求与预期',['要求','准则','确认程度','依据'],[[anchor('requirement',x['id'],x['id']+' '+x['title']),x['criterion'],label(x['basis']),refs('evidence',x['evidence_ids'])] for x in c['requirements']],collapse))
   for field,title in [('categories','主分类定义'),('severities','严重程度定义'),('statuses','状态定义')]:
    out.append(table(title,['名称','定义'],[[x['name'],x.get('definition') or ('关闭状态' if x['is_closed'] else '未关闭状态')] for x in r[field]],True))
   return out
  if kind=='cases': return [table('任务用例与执行记录',['用例','结果','记录深度','关联要求','前提 / 步骤','预期 / 实际','版本 / 时间','证据'],[[anchor('case',x['id'],x['id']+' '+x['title']),label(x['result']),label(x['detail_level']),refs('requirement',x['requirement_ids']),f'{x["preconditions"] or "前提待补"} / {joined(x["steps"])}',f'{x["expected"] or "预期待补"} / {x["actual"] or "实际待补"}',f'{x["product_version"] or "未知"} / {x["executed_at"] or "未记录"}',refs('evidence',x['evidence_ids'])] for x in c['cases']],collapse)]
  if kind=='evidence':
   out=[table('材料目录',['来源ID','材料','性质','日期','位置与说明'],[[s['id'],s['title'],label(s['nature']),s['source_date'] or '未记录',f'{s["path"] or "未附文件"}；{s["note"]}'] for s in c['sources']],collapse)]
   if c['evidence']: out.append(table('具体证据索引',['证据','性质','内容','来源位置与摘录','观察版本 / 时间','说明'],[[anchor('evidence',x['id'],x['id']),label(x['nature']),x['summary'],'\n'.join(f'{ref["source_id"]} · {ref["locator"]}'+(f'\n摘录：{ref["excerpt"]}' if ref['excerpt'] is not None else '') for ref in x['source_refs']),f'{x["product_version"] or "未知"} / {x["observed_at"] or "未记录"}',x['note']] for x in c['evidence']],collapse))
   return out
  raise ValueError('Unknown view: '+kind)
 model={'title':meta['title'],'summary':f'{c["product"]["name"]} · {c["product"]["version"] or "版本待确认"} · {label(meta["content_nature"])} · 编写日期 {meta["authored_on"]}',
  'kpis':[{'label':decision_kind(c['decision']['kind']),'value':label(c['decision']['result'])},
          {'label':'已有问题记录','value':str(counts['findings'])}, {'label':'未关闭阻断项','value':str(counts['unclosed_blockers'])},
          {'label':'已有用例记录','value':str(counts['cases'])}],
  'corePoints':[{'lead':'结论依据','text':statement(c['decision']['rationale'])},{'lead':'材料性质','text':label(meta['content_nature'])+'；没有记录不等于没有问题，结构校验不代表研究结论正确。'}],
  'sections':[],'charts':charts}
 nav=[]
 for group,views in selected:
  nav_views=[]
  for v in views:
   sid=aid('section',v['id'])
   b=blocks(v['kind'],v) if availability.get(v['kind'],True) else [callout('待补充','尚无该部分记录，请补充材料后再形成结论。')]
   model['sections'].append({'id':sid,'title':v['title'],'summary':group['title'],'blocks':b,'groupStart':group['title'] if not nav_views else None})
   nav_views.append({'id':sid,'title':v['title']})
  nav.append({'title':group['title'],'views':nav_views})
 if theme['palette']:
  for option in charts.values():
   option['color']=theme['palette']
   option['tooltip']['borderColor']='#f0d9c3'
 return model,nav,maps

def map_markup(item):
 j=item['journey']; options=item['options']; width=max(1040,144+len(item['data']['stages'])*174+(len(item['data']['stages'])-1)*12)+50
 buttons='<button data-map-action="size">原尺寸阅读</button>'
 if options['fullscreen']: buttons+='<button data-map-action="fullscreen">全屏查看</button>'
 buttons+='<button data-map-action="open">单独打开</button>'
 return f'''<div class="map-card" data-map-width="{width}" data-mode="{e(options['initial_mode'])}"><div class="map-controls"><strong>{e(j['title'])}</strong><div>{buttons}</div></div><div class="map-scroll"><div class="map-stage"><iframe title="{e(j['title'])}" srcdoc="{e(item['document'])}" style="width:{width}px" sandbox="allow-scripts allow-same-origin allow-downloads allow-popups"></iframe></div></div><p class="map-hint">{e(label(j['map_state']))} · {len(item['data']['stages'])} 个阶段 · 缺失情绪保留空白；绘图位置不等于测量评分。</p></div>'''

def build(source, output):
 source=Path(source).resolve(); output=Path(output).resolve()
 data=json.loads(source.read_text(encoding='utf-8')); checked=validate(data,source.parent,check_sources=True)
 if not checked['valid']: raise ValueError('数据校验未通过：\n'+'\n'.join(checked['errors']))
 if output.suffix.lower()!='.html': raise ValueError('输出必须是 .html 文件。')
 outputs=[output,output.with_suffix('.model.json'),output.with_suffix('.validation.json')]
 protected={source,*(safe_file(source.parent,j['map_file']) for j in data['content']['journeys']),*(safe_file(source.parent,s['path']) for s in data['content']['sources'] if s['path'])}
 if any(x.resolve() in protected for x in outputs): raise ValueError('输出不能覆盖输入或来源文件。')
 model,nav,maps=make_model(data,source.parent,checked)
 original_table=layout.render_table; original_block=layout.render_block
 def wrapped_table(b):
  result=original_table(b)
  return f'<details class="report-details"><summary>{e(b.get("title","明细"))}（{len(b.get("rows",[]))}项）</summary>{result}</details>' if b.get('collapse') else result
 def wrapped_block(b):
  if b['type']=='mapMount': return map_markup(next(m for m in maps if m['token']==b['token']))
  return original_block(b)
 layout.render_table=wrapped_table; layout.render_block=wrapped_block
 try: document=layout.build_html(model,ASSETS/'report-template.html',ASSETS)
 finally: layout.render_table=original_table; layout.render_block=original_block
 for s in model['sections']:
  if s['groupStart']: document=document.replace(f'<section id="{s["id"]}">',f'<div class="report-group">{e(s["groupStart"])}</div>\n<section id="{s["id"]}">',1)
 navigation=''
 if data['presentation']['navigation']['enabled']:
  items='<a href="#top">报告首页</a><a href="#summary">报告摘要</a>'
  for group in nav:
   items+=f'<div class="nav-group">{e(group["title"])}</div>'+''.join(f'<a href="#{v["id"]}">{e(v["title"])}</a>' for v in group['views'])
  navigation='<nav class="report-nav" aria-label="报告目录"><details open><summary>报告目录</summary>'+items+'</details></nav>'
 toolsbar='<div class="report-tools"><button id="report-print">打印 / 保存 PDF</button><button id="report-download">下载结构化数据包</button></div>'
 # Bundle map JSON too so downloaded data remains reusable; explicit local source documents are not silently exported.
 bundle={'report':data,'maps':{j['map_file']:json.loads(safe_file(source.parent,j['map_file']).read_text()) for j in data['content']['journeys']},'note':'JSON 数据包；重建时按 maps 的相对路径保存地图文件，并随包携带 sources 中登记的原始材料。'}
 extra='<script type="application/json" id="report-bundle">'+js(bundle)+'</script>'
 document=document.replace('\n<body>\n','\n<body'+(' class="with-nav"' if navigation else '')+'>\n'+navigation+toolsbar+'\n',1)
 css=(ASSETS/'report-runtime.css').read_text()
 theme=THEMES[data['presentation']['theme']]
 if theme['report_css']: css+='\n'+(ASSETS/'themes'/theme['report_css']).read_text()
 document=document.replace('<html lang="zh-CN">','<html lang="zh-CN" data-theme="'+e(data['presentation']['theme'])+'">',1)
 document=document.replace('  </style>\n</head>',css+'\n  </style>\n</head>',1)
 runtime=(ASSETS/'report-runtime.js').read_text().replace('__HIGHLIGHT_CURRENT__',str(data['presentation']['navigation']['highlight_current']).lower())
 head,tail=document.rsplit('\n</body>',1)
 document=head+'\n'+extra+'\n<script>'+runtime+'</script>\n</body>'+tail
 output.parent.mkdir(parents=True,exist_ok=True)
 output.write_text(document,encoding='utf-8')
 outputs[1].write_text(json.dumps(model,ensure_ascii=False,indent=2),encoding='utf-8')
 outputs[2].write_text(json.dumps(checked,ensure_ascii=False,indent=2),encoding='utf-8')
 return {'output':str(output),'counts':checked['counts'],'warnings':checked['warnings'],'maps':len(maps)}

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('source',type=Path); parser.add_argument('-o','--output',required=True,type=Path)
 args=parser.parse_args()
 try: print(json.dumps(build(args.source,args.output),ensure_ascii=False,indent=2))
 except (OSError,ValueError,KeyError) as exc: parser.exit(2,str(exc)+'\n')
