#!/usr/bin/env python3
"""Behavior checks for the generic renderer. No browser or third-party packages needed."""
import copy,json,shutil,tempfile
from pathlib import Path
from html.parser import HTMLParser
from build_report import build
ROOT=Path(__file__).resolve().parents[1]
class Page(HTMLParser):
 def __init__(self,text):
  super().__init__();self.ids=[];self.hrefs=[];self.frames=[];self.data=[];self.feed(text)
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='a' and a.get('href','').startswith('#'):self.hrefs.append(a['href'][1:])
  if tag=='iframe':self.frames.append(a['srcdoc'])
 def handle_data(self,text):self.data.append(text)
results=[]
def check(name,condition):
 results.append({'name':name,'passed':bool(condition)})
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp); examples=root/'examples';shutil.copytree(ROOT/'examples',examples)
 for slug,expected_maps in [('procurement',1),('support',2),('publishing',1),('brief-only',0)]:
  target=root/(slug+'.html');res=build(examples/(slug+'.report.json'),target);text=target.read_text();page=Page(text)
  check(slug+' 无重复锚点或失效引用',len(page.ids)==len(set(page.ids)) and set(page.hrefs)<=set(page.ids))
  check(slug+' 嵌入完整角色地图',len(page.frames)==expected_maps and all('__JOURNEY_DATA__' not in frame and 'pain_points' in frame for frame in page.frames))
  if slug in ['support','publishing']:check(slug+' 不残留采购场景',all(x not in text for x in ['采序','采购','UX-01']))
  if slug=='brief-only':check('材料不足不补造地图或通过结论','暂无法判定' in text and res['counts']['findings']==0 and not page.frames)
  if slug=='publishing':check('没有阻断问题不自动判定通过',res['counts']['unclosed_blockers']==0 and '暂无法判定' in text)
 d=json.loads((examples/'procurement.report.json').read_text())
 # Canonical finding title/state override the display copies in the map.
 d['content']['findings'][0]['title']='更新后的统一问题标题'
 altered=examples/'altered.json';altered.write_text(json.dumps(d,ensure_ascii=False));target=root/'altered.html';build(altered,target)
 check('地图痛点标题跟随主台账', '更新后的统一问题标题' in Page(target.read_text()).frames[0])
 for g in d['presentation']['groups']:
  for v in g['modules']:
   if v['kind'] in ['evidence','journeys','criteria']:v['visibility']='hide'
 d['presentation']['navigation']['enabled']=False
 altered.write_text(json.dumps(d,ensure_ascii=False));build(altered,target);page=Page(target.read_text())
 check('隐藏模块不留下失效引用',set(page.hrefs)<=set(page.ids) and not page.frames and '<nav class=' not in target.read_text())
 d=json.loads((examples/'procurement.report.json').read_text());attack='<script>window.reportPwned=true</script>'
 d['metadata']['title']=attack;d['content']['findings'][0]['title']=attack
 altered.write_text(json.dumps(d,ensure_ascii=False));build(altered,target);text=target.read_text()
 check('输入文案不能成为可执行HTML',attack not in text and '&lt;script&gt;' in text)
 d['content']['findings'][0]['module_id']='missing';altered.write_text(json.dumps(d));badtarget=root/'bad.html'
 try:build(altered,badtarget);blocked=False
 except ValueError:blocked=True
 check('无效关联在输出前阻断',blocked and not badtarget.exists())
 source=examples/'procurement.report.json'
 try:build(source,source);blocked=False
 except ValueError:blocked=True
 check('拒绝用HTML覆盖输入',blocked and json.loads(source.read_text())['schema_version']=='0.1.0')
(ROOT/'validation').mkdir(exist_ok=True)
summary={'passed':sum(x['passed'] for x in results),'total':len(results),'results':results}
(ROOT/'validation/renderer-tests.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2));raise SystemExit(0 if all(x['passed'] for x in results) else 1)
