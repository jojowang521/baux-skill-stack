#!/usr/bin/env python3
"""One-off adapter for the procurement example. Generic consumers must not import it."""
import argparse, json, shutil, re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def plain(v):
    if isinstance(v,dict):return plain(v.get('text',v.get('html','')))
    return re.sub('<[^>]+>','',str(v))
def statement(text,basis='simulated',evidence=None):return {'text':text,'basis':basis,'evidence_ids':evidence or []}
def source_ref(sid,locator,excerpt=None):return {'source_id':sid,'locator':locator,'excerpt':excerpt}
def snapshot(label):return {'label':label,'product_version':None,'recorded_at':None}
def convert(source:Path):
    dest=ROOT/'examples'; files=dest/'sources';files.mkdir(exist_ok=True,parents=True)
    for name in ['scenario-ledger.json','report-model.json','journey-scenario.simulated.txt']:
        shutil.copy(source/name,files/name)
    old=json.loads((source/'scenario-ledger.json').read_text()); view=json.loads((source/'report-model.json').read_text()); journey=json.loads((source/'procurement-journey.json').read_text())
    by_section={s['id']:s for s in view['sections']}
    def legacy_table(section,title):return next(b for b in by_section[section]['blocks'] if b.get('title')==title)
    statuses=[('open','待修复'),('in_progress','修复中'),('pending_retest','待复验'),('closed','已关闭')]
    status_ids={label:id for id,label in statuses}
    mods=list(dict.fromkeys(x['module'] for x in old['issues']));mid={name:f'module-{i:02d}' for i,name in enumerate(mods,1)}
    dimdefs=[('discoverability','可发现与可理解','能否发现入口、理解状态与下一步？'),('efficiency','操作效率与填写负担','是否发生重复填报或额外沟通？'),('feedback','状态反馈与过程可控','是否能知道进度、责任和后续动作？'),('recovery','错误预防与恢复','能否防止错误并恢复有效数据？'),('continuity','任务连续性与协作','任务与协作能否连续推进？'),('mobile','移动端适配','当前设备与使用环境是否支持完成任务？')]
    # Mappings belong to this migration example only, never to the generic schema or validator.
    dimissues=[['UX-01','UX-04','UX-12'],['UX-02','UX-05'],['UX-05','UX-07','UX-10'],['UX-02','UX-03'],['UX-08','UX-09'],['UX-11']]
    primary=lambda iid:'access' if iid=='UX-06' else 'functional' if iid in ['UX-02','UX-03','UX-08','UX-09'] else 'experience'
    rules={'categories':[{'id':'experience','name':'交互与协同体验','definition':'理解、反馈、效率及操作便利。'},{'id':'functional','name':'业务功能与数据','definition':'任务能力、数据保留、业务校验和单据关联。'},{'id':'access','name':'权限与数据隔离','definition':'非授权访问和数据边界。'}], 'dimensions':[{'id':i,'name':n,'question':q} for i,n,q in dimdefs], 'severities':[], 'statuses':[{'id':i,'name':n,'is_closed':i=='closed','requires_confirmation':i in ['pending_retest','closed']} for i,n in statuses], 'counting':{'findings':'unique_finding_id','primary_category':'single_or_unclassified','dimensions':'multi_label_non_additive','closure':'status_is_closed','case_results':'unique_case_id'},'acceptance':{'applicable':True,'gates':[],'note':'继承原模拟报告的门槛，仅迁移，不视为业务方已确认，也不在本步骤修订发布规则。'}}
    sevrows=legacy_table('criteria','严重程度定义')['rows']
    for i,row in enumerate(sevrows,1):rules['severities'].append({'id':plain(row[0]),'name':plain(row[0]),'rank':i,'definition':plain(row[1]),'release_blocker':plain(row[0]) in ['P0','P1']})
    sources=[{'id':'SRC-LEDGER','title':'原采购模拟问题与用例台账','kind':'existing_report','nature':'simulated','path':'sources/scenario-ledger.json','source_date':None,'note':'模拟来源，非真实执行记录。'}, {'id':'SRC-REPORT','title':'原采购报告内容模型','kind':'existing_report','nature':'simulated','path':'sources/report-model.json','source_date':None,'note':'保留原报告的分类、规则和结论，不作为独立实证。'}, {'id':'procurement-report-scenario','title':'采购地图模拟场景','kind':'existing_map','nature':'simulated','path':'sources/journey-scenario.simulated.txt','source_date':None,'note':'与问题台账同源，不构成独立验证。'}]
    evidence=[]
    for i,x in enumerate(old['issues']):evidence.append({'id':x['evidence_id'],'kind':'behavior' if x['id']!='UX-06' else 'test_result','nature':'simulated','summary':x['trigger'],'source_refs':[source_ref('SRC-LEDGER',f'/issues/{i}/trigger',x['trigger'])],'observed_at':None,'product_version':None,'note':'从原报告迁移的模拟问题记录；实际时间和构建版本未提供。'})
    for i,c in enumerate(old['cases']):evidence.append({'id':'CASE-EV-'+c['id'],'kind':'test_result','nature':'simulated','summary':f"{c['task']}：{c['result']}（原模拟台账）",'source_refs':[source_ref('SRC-LEDGER',f'/cases/{i}/result',c['result'])],'observed_at':None,'product_version':None,'note':'仅用例概要及结果，缺少可复现的执行详情。'})
    evidence.append({'id':'EV-RT-01','kind':'retest','nature':'simulated','summary':old['retest_records'][0]['action'],'source_refs':[source_ref('SRC-LEDGER','/retest_records/0/action',old['retest_records'][0]['action'])],'observed_at':None,'product_version':None,'note':'原报告RT-01模拟复验记录，非实际复验。'})
    reqblock=legacy_table('criteria','本场景预设的验收标准'); reqs=[]
    for i,r in enumerate(reqblock['rows']):
        rid=plain(r[0]);eid='RULE-EV-'+rid
        evidence.append({'id':eid,'kind':'requirement','nature':'simulated','summary':plain(r[2]),'source_refs':[source_ref('SRC-REPORT','criteria / 本场景预设的验收标准 / '+str(i),plain(r[2]))],'observed_at':None,'product_version':None,'note':'样例预设规则，尚未经真实业务确认。'})
        reqs.append({'id':rid,'title':plain(r[1]),'criterion':plain(r[2]),'module_ids':list(dict.fromkeys(mid[x['module']] for x in old['issues'] if x['requirement_id']==rid)),'basis':'inherited_unverified','evidence_ids':[eid]})
    roleids=lambda name:['requester','buyer'] if '采购专员' in name else ['requester']
    cases=[]
    resultids={'通过':'passed','失败':'failed','待复验':'pending_retest'}
    for c in old['cases']:
        evs=['CASE-EV-'+c['id']]+[x['evidence_id'] for x in old['issues'] if x['case_id']==c['id']]
        if c['id']=='TC-12':evs.append('EV-RT-01')
        cases.append({'id':c['id'],'title':c['task'],'role_ids':roleids(c['role']),'requirement_ids':[c['requirement_id']],'detail_level':'summary','preconditions':None,'steps':[],'expected':next(r['criterion'] for r in reqs if r['id']==c['requirement_id']),'actual':None,'result':resultids[c['result']],'evidence_ids':evs,'executed_at':None,'product_version':None})
    findings=[]; recommendations=[]
    for x in old['issues']:
        ev=[x['evidence_id']]
        findings.append({'id':x['id'],'title':x['title'],'module_id':mid[x['module']],'role_ids':roleids(x['role']),'primary_category_id':primary(x['id']),'dimension_ids':[dimdefs[i][0] for i,ids in enumerate(dimissues) if x['id'] in ids],'phenomenon':statement(x['trigger'],evidence=ev),'impact':statement(x['impact'],'analyst_inference',ev),'expected_behavior':x['expected'],'severity_id':x['severity'],'severity_reason':'继承原模拟报告等级，尚未重新评定。','status_id':status_ids[x['status']],'status_evidence_ids':['EV-RT-01'] if x['status']=='已关闭' else ev,'state_snapshot':snapshot('原报告最新状态；未给出实际复验时间和构建版本'),'case_ids':[x['case_id']],'requirement_ids':[x['requirement_id']],'owner_role':x['owner'],'note':'影响描述为分析判断，不能当作独立观察结论。'})
        recommendations.append({'id':'REC-'+x['id'][3:],'proposal':statement(x['recommendation'],'design_hypothesis',ev),'finding_ids':[x['id']],'priority':None,'priority_reason':None,'owner_role':x['owner'],'target_version':None,'target_date':None,'note':'原台账建议：'+x['target']+'；未经团队确认，不转成承诺日期。'})
    gate_rows=legacy_table('decision','发布门槛核对')['rows']; gate_results=[]
    for n,r in enumerate(gate_rows,1):
        gid=f'GATE-{n:02d}';rules['acceptance']['gates'].append({'id':gid,'title':plain(r[0]),'criterion':plain(r[0]),'mandatory':True,'basis':'inherited_unverified','requirement_ids':[],'evidence_ids':[]})
        gate_results.append({'gate_id':gid,'result':'not_satisfied' if n<=3 else 'satisfied','evidence_ids':[],'note':'原报告模拟判断：'+plain(r[1])+'；'+plain(r[2])})
    roles=[{'id':i,'name':n,'is_primary':i=='requester','goals':goals,'contexts':ctx,'permissions':perm,'evidence_ids':[]} for i,n,goals,ctx,perm in [('requester','项目助理／采购申请人',['正确提交需求','及时取得可用设备','跟进异常'],['办公室PC填报','现场移动验收'],'本人及明确授权范围'),('buyer','采购专员',['维护订单与交期','协调异常'],['采购协同'],'授权采购范围'),('approver','审批人',['检查用途与预算','审批或退回'],['审批任务'],'被分派任务'),('receiver','验收责任人',['准确记录实收','重验替换件'],['收货现场'],'被分派验收记录')]]
    stageids={s['name']:s['id'] for s in journey['stages']}
    links=[{'stage_id':stageids[x['stage']],'finding_id':x['id'],'relation':'contextual' if x['id']=='UX-06' else 'experienced','note':'独立权限检查，与本阶段相关但不推断用户情绪。' if x['id']=='UX-06' else '对应地图痛点；保留原报告状态。'} for x in old['issues']]
    journey['$schema']='../data/journey-map.schema.json'
    journey['sources'][0]['path']='sources/journey-scenario.simulated.txt'
    write(dest/'procurement.journey.json',journey)
    assessmentrows=legacy_table('assessment','体验维度与主要发现')['rows']
    assessments=[{'id':f'ASSESS-{i+1:02d}','dimension_id':dimdefs[i][0],'summary':statement(plain(r[2]),'analyst_inference',list(dict.fromkeys(x['evidence_id'] for x in old['issues'] if x['id'] in dimissues[i]))),'finding_ids':dimissues[i],'coverage':'partial','note':'基于现有模拟问题归纳，不等于该维度全部检查通过。'} for i,r in enumerate(assessmentrows)]
    missing=[{'id':'GAP-REAL','area':'研究依据','description':'没有真实访谈、观察或测试执行证据。','effect':'仅用于模拟演示，不能给出真实产品结论。','blocks_acceptance':True},{'id':'GAP-COVERAGE','area':'覆盖范围','description':'用例仅为概要，不能证明完整主流程及所有要求已测试。','effect':'无法判断验收覆盖充分性。','blocks_acceptance':True},{'id':'GAP-TIME','area':'时间与版本','description':'原报告混合初次发现和修复状态，缺少实际观察及复验时间。','effect':'保留未知值，不能重建统一时点的现状地图。','blocks_acceptance':True},{'id':'GAP-GATES','area':'验收规则','description':'门槛继承原样例，未获真实业务确认。','effect':'仅保留原模拟不通过结论，不自动升级为真实判定。','blocks_acceptance':True}]
    groups=[]
    groupdefs=[('product-analysis','产品与用户分析',[('scope','背景与范围'),('product','产品框架'),('users','目标用户'),('journeys','完整体验地图')]),('experience-review','体验评估与问题反馈',[('assessment','体验评估总览'),('findings','模块反馈与问题分类')]),('conclusions','汇总分析与验收结论',[('statistics','统计汇总'),('recommendations','优化方向'),('decision','结论与限制')]),('appendices','附录',[('criteria','验收口径'),('cases','用例记录'),('evidence','来源与证据')])]
    for gid,title,modsview in groupdefs:groups.append({'id':gid,'title':title,'modules':[{'id':'view-'+kind,'kind':kind,'title':name,'visibility':'show','empty_policy':'show_gap','details_collapsed':kind in ['findings','cases','evidence']} for kind,name in modsview]})
    d={'$schema':'../data/report.schema.json','schema_version':'0.1.0','metadata':{'id':old['report_id'],'title':'采序采购平台 · 产品体验评估与验收报告','language':'zh-CN','authored_on':old['authored_date'],'revised_on':'2026-10-23','input_mode':'simulated_material','content_nature':'simulated','assessment_snapshot':snapshot('原模拟发现，具体时间不详'),'status_snapshot':snapshot('原报告修复状态快照，具体时间不详')},'content':{'product':{'id':'procurement-demo','name':old['product'],'version':old['version'],'description':'项目制企业的办公设备采购协同平台（虚构）','business_goals':['准确提交采购需求','跟踪交付与异常']},'scope':{'purpose':'呈现申请到收货及异常处理的体验评估与验收结构','scenario':old['scenario'],'in_scope':['需求与目录','申请与预算','审批协同','订单与权限','收货验收','异常协同'],'out_of_scope':['寻源与招投标','合同法律审核','支付与发票','库存财务记账','性能与安全渗透测试'],'start':'需求准备','end':'异常关闭（任务目标，未证明完整路径通过）'},'roles':roles,'modules':[{'id':mid[m],'name':m,'parent_id':None,'description':'原采购报告范围内的业务模块','in_scope':True} for m in mods],'sources':sources,'evidence':evidence,'requirements':reqs,'cases':cases,'findings':findings,'recommendations':recommendations,'journeys':[{'id':journey['map_id'],'title':journey['overview']['title'],'role_id':'requester','map_file':'procurement.journey.json','map_state':'hypothesis','snapshot':snapshot('沿用原图的模拟任务与修复状态混合展示；未补造时间'),'finding_links':links,'note':'11项体验痛点；权限问题UX-06仅为阶段背景关联，不作为地图痛点。'}],'assessments':assessments,'decision':{'kind':'simulated','result':'failed','scope_note':'只适用于本采购模拟范围','rationale':statement('原样例仍有4项阻断问题未关闭，关键用例失败，2条用例待复验。',evidence=['EV-02','EV-03','EV-06','EV-08']),'gate_evaluations':gate_results,'limitations':['没有真实研究和测试','未核验全部任务覆盖','原门槛有待真实项目确认'],'risk_acceptances':[]},'missing_information':missing},'rules':rules,'presentation':{'theme':'blue-white','detail_level':'overview','groups':groups,'navigation':{'enabled':True,'highlight_current':True},'journey_view':{'initial_mode':'responsive','fullscreen':True,'show_sources':True}}}
    write(dest/'procurement.report.json',d)
    # Small brief-only fixture verifies that absent data is representable without invented findings.
    import copy
    brief=copy.deepcopy(d)
    brief_text='为内部知识库产品规划体验评估报告，重点关注员工查找并使用知识；尚未提供研究材料。'
    (files/'knowledge-brief.txt').write_text(brief_text+'\n')
    brief['metadata'].update(id='knowledge-brief-example',title='内部知识库体验评估 · 待补材料',authored_on='2026-10-23',revised_on=None,input_mode='brief_only',content_nature='hypothesis',assessment_snapshot=snapshot('未开展评估'),status_snapshot=snapshot('无问题记录'))
    c=brief['content']
    c['product']={'id':'knowledge','name':'内部知识库','version':None,'description':'一句话需求示例','business_goals':['支持员工查找和使用知识']}
    c['scope']={'purpose':'准备评估框架','scenario':'员工查找并使用知识','in_scope':['知识查找与使用'],'out_of_scope':[],'start':None,'end':None}
    for k in ['roles','modules','evidence','requirements','cases','findings','recommendations','journeys','assessments']:c[k]=[]
    c['sources']=[{'id':'BRIEF','title':'示例需求','kind':'user_brief','nature':'brief','path':'sources/knowledge-brief.txt','source_date':None,'note':'示例需求，只描述意图，不证明行为或缺陷。'}]
    c['decision']={'kind':'not_assessed','result':'undetermined','scope_note':'尚未开始验收','rationale':statement('材料不足，不能判断产品体验与验收结果。','unknown'),'gate_evaluations':[],'limitations':['产品版本、角色、旅程和研究材料待补充'],'risk_acceptances':[]}
    c['missing_information']=[{'id':'NEEDS-MATERIAL','area':'输入材料','description':'未提供版本、角色和研究材料。','effect':'先保留结构，不补造地图或验收结果。','blocks_acceptance':True}]
    brief['rules']['acceptance']={'applicable':False,'gates':[],'note':'尚无验收标准，不进行通过判定。'}
    write(dest/'brief-only.report.json',brief)
    print(json.dumps({'migrated_findings':len(findings),'cases':len(cases),'maps':1,'output':str(dest/'procurement.report.json')},ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source_dir',type=Path);args=p.parse_args();convert(args.source_dir)
