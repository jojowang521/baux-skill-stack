(() => {
 const nav=document.querySelector('.report-nav details');
 if(nav && innerWidth<=1100)nav.open=false;
 document.addEventListener('click',event=>{
  const a=event.target.closest('a[href^="#"]');if(!a)return;
  const target=document.getElementById(a.hash.slice(1));if(!target)return;
  event.preventDefault();let parent=target.parentElement;
  while(parent){if(parent.tagName==='DETAILS')parent.open=true;parent=parent.parentElement;}
  if(nav&&innerWidth<=1100)nav.open=false;
  history.replaceState(null,'',a.hash);requestAnimationFrame(()=>target.scrollIntoView({block:'start',behavior:'smooth'}));
 });
 if(__HIGHLIGHT_CURRENT__){
  const links=[...document.querySelectorAll('.report-nav a')],targets=links.map(a=>document.getElementById(a.hash.slice(1)));let pending=false;
  function mark(){let active=0;targets.forEach((t,i)=>{if(t&&t.getBoundingClientRect().top<140)active=i});links.forEach((a,i)=>a.setAttribute('aria-current',String(i===active)));pending=false;}
  addEventListener('scroll',()=>{if(!pending){pending=true;requestAnimationFrame(mark)}},{passive:true});mark();
 }
 const resizers=[];
 document.querySelectorAll('.map-card').forEach(card=>{
  const frame=card.querySelector('iframe'),viewport=card.querySelector('.map-scroll'),stage=card.querySelector('.map-stage'),toggle=card.querySelector('[data-map-action=size]');
  const width=Number(card.dataset.mapWidth);let fit=card.dataset.mode==='fit'||(card.dataset.mode==='responsive'&&innerWidth>640);
  function resize(){const doc=frame.contentDocument;const height=Math.ceil(doc?.querySelector('.viewport')?.getBoundingClientRect().bottom||1420)+16;const scale=fit?Math.min(1,viewport.clientWidth/width):1;frame.style.height=height+'px';frame.style.transform='scale('+scale+')';stage.style.width=width*scale+'px';stage.style.height=height*scale+'px';toggle.textContent=fit?'原尺寸阅读':'适应宽度';toggle.setAttribute('aria-pressed',String(!fit));}
  frame.addEventListener('load',()=>{resize();frame.contentDocument.fonts.ready.then(resize)});new ResizeObserver(resize).observe(viewport);resizers.push(resize);
  toggle.addEventListener('click',()=>{fit=!fit;resize()});
  const fullscreen=card.querySelector('[data-map-action=fullscreen]');
  fullscreen?.addEventListener('click',async()=>{try{if(document.fullscreenElement===card)await document.exitFullscreen();else await card.requestFullscreen();resize()}catch{fullscreen.textContent='请使用单独打开'}});
  document.addEventListener('fullscreenchange',()=>{if(fullscreen)fullscreen.textContent=document.fullscreenElement===card?'退出全屏':'全屏查看';resize()});
  card.querySelector('[data-map-action=open]').addEventListener('click',()=>{const u=URL.createObjectURL(new Blob([frame.srcdoc],{type:'text/html;charset=utf-8'}));window.open(u,'_blank','noopener');setTimeout(()=>URL.revokeObjectURL(u),60000)});
  card.preparePrint=()=>{card.previousFit=fit;fit=true;resize()};card.restorePrint=()=>{fit=card.previousFit;resize()};resize();
 });
 let printState=[];
 addEventListener('beforeprint',()=>{document.querySelectorAll('section').forEach(s=>s.classList.add('visible'));document.querySelectorAll('[data-chart-id]').forEach(el=>{initChart(el);const chart=echarts.getInstanceByDom(el);chart?.setOption({animation:false});chart?.resize()});printState=[...document.querySelectorAll('.report-details')].map(d=>[d,d.open]);printState.forEach(([d])=>d.open=true);document.querySelectorAll('.map-card').forEach(c=>c.preparePrint());});
 addEventListener('afterprint',()=>{printState.forEach(([d,open])=>d.open=open);document.querySelectorAll('.map-card').forEach(c=>c.restorePrint());});
 document.getElementById('report-print').addEventListener('click',()=>window.print());
 document.getElementById('report-download').addEventListener('click',()=>{const data=document.getElementById('report-bundle').textContent;const u=URL.createObjectURL(new Blob([data],{type:'application/json;charset=utf-8'}));const a=document.createElement('a');a.href=u;a.download='experience-report.bundle.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)});
})();
