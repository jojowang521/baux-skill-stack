"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Plus, Users } from "lucide-react";
import {
  CrmButton,
  CrmCard,
  CrmConfirmDialog,
  CrmDetailDrawer,
  CrmMetricCard,
  CrmSectionHeading,
} from "./crm-components";
import {
  CrmDataTable,
  CrmFilterBar,
  CrmPaginationFooter,
  CrmSelectFilter,
  CrmTextFilter,
} from "./crm-data-table";
import { CrmField, CrmFormModal, CrmModalFooter } from "./crm-form-modal";
export type Customer = {
  id: string;
  name: string;
  country: string;
  owner: string;
  status: string;
  amount: number;
  linkedOpportunityCount?: number;
};
type Draft = {
  id: string;
  name: string;
  country: string;
  owner: string;
  status: string;
  amount: string;
};
const blank: Draft = {
  id: "",
  name: "",
  country: "",
  owner: "",
  status: "合作中",
  amount: "0",
};
const examples: Customer[] = [
  {
    id: "c1",
    name: "远辰制造",
    country: "中国",
    owner: "林悦",
    status: "合作中",
    amount: 1200000,
    linkedOpportunityCount: 1,
  },
  {
    id: "c2",
    name: "澜海科技",
    country: "中国",
    owner: "林悦",
    status: "潜在客户",
    amount: 0,
  },
  {
    id: "c3",
    name: "启明物流",
    country: "中国",
    owner: "陈宁",
    status: "合作中",
    amount: 680000,
  },
  {
    id: "c4",
    name: "云山商业",
    country: "中国",
    owner: "周航",
    status: "潜在客户",
    amount: 0,
  },
  {
    id: "c5",
    name: "恒川能源",
    country: "中国",
    owner: "陈宁",
    status: "合作中",
    amount: 1600000,
  },
  {
    id: "c6",
    name: "星桥医疗",
    country: "中国",
    owner: "林悦",
    status: "已归档",
    amount: 350000,
  },
];
function validRows(x: unknown): x is Customer[] {
  return (
    Array.isArray(x) &&
    x.every(
      (r) =>
        r &&
        typeof r.id === "string" &&
        typeof r.name === "string" &&
        typeof r.country === "string" &&
        typeof r.owner === "string" &&
        typeof r.status === "string" &&
        typeof r.amount === "number" &&
        Number.isFinite(r.amount) &&
        r.amount >= 0,
    )
  );
}
export function CustomerCrudPageExample(props: {
  initialRows?: Customer[];
  storageKey?: string;
}) {
  return <CustomerCrudContent key={props.storageKey || "memory"} {...props} />;
}
function CustomerCrudContent({
  initialRows = examples,
  storageKey,
}: {
  initialRows?: Customer[];
  storageKey?: string;
}) {
  const [rows, setRows] = useState<Customer[]>(initialRows),
    [ready, setReady] = useState(false),
    [storageError, setStorageError] = useState("");
  const [query, setQuery] = useState(""),
    [status, setStatus] = useState(""),
    [page, setPage] = useState(1),
    [viewId, setViewId] = useState<string | null>(null),
    [draft, setDraft] = useState<Draft | null>(null),
    [deleting, setDeleting] = useState<Customer | null>(null),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const loadedKey = useRef<string | undefined>(undefined);
  useEffect(() => {
    setReady(false);
    setStorageError("");
    let next = initialRows;
    if (storageKey)
      try {
        const raw = localStorage.getItem(storageKey);
        if (raw) {
          const parsed: unknown = JSON.parse(raw);
          if (validRows(parsed)) next = parsed;
          else setStorageError("已有演示数据格式不兼容，本次使用初始数据。");
        }
      } catch {
        setStorageError("无法读取本地存储，本次使用初始数据。");
      }
    setRows(next);
    loadedKey.current = storageKey;
    setReady(true);
  }, [storageKey]);
  useEffect(() => {
    if (!ready || !storageKey || loadedKey.current !== storageKey) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(rows));
    } catch {
      setStorageError("本地存储不可用，修改仅保留在当前页面。");
    }
  }, [rows, storageKey, ready]);
  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          (!status || r.status === status) &&
          `${r.name} ${r.country} ${r.owner}`
            .toLowerCase()
            .includes(query.trim().toLowerCase()),
      ),
    [rows, query, status],
  );
  const pageSize = 5,
    totalPages = Math.max(1, Math.ceil(filtered.length / pageSize)),
    currentPage = Math.min(Math.max(1, page), totalPages),
    viewing = rows.find((r) => r.id === viewId);
  function edit(row?: Customer) {
    setError("");
    setDraft(row ? { ...row, amount: String(row.amount) } : { ...blank });
  }
  function save() {
    if (!draft) return;
    const data = {
      ...draft,
      name: draft.name.trim(),
      country: draft.country.trim(),
      owner: draft.owner.trim(),
      amount: Number(draft.amount),
    };
    if (!data.name || !data.owner) return setError("请填写客户名称和负责人。");
    if (
      draft.amount.trim() === "" ||
      !Number.isFinite(data.amount) ||
      data.amount < 0
    )
      return setError("累计销售额应为有效的非负金额。");
    if (
      rows.some(
        (r) =>
          r.id !== draft.id &&
          r.name.toLocaleLowerCase() === data.name.toLocaleLowerCase(),
      )
    )
      return setError("客户名称已存在，请使用其他名称。");
    const old = rows.find((r) => r.id === draft.id);
    const next: Customer = {
      ...old,
      ...data,
      id: draft.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    };
    setRows((rs) =>
      draft.id ? rs.map((r) => (r.id === draft.id ? next : r)) : [next, ...rs],
    );
    setPage(1);
    setNotice(draft.id ? "客户已更新。" : "客户已新增。");
    setDraft(null);
  }
  return (
    <div className="baux-crm crm-stack">
      <CrmMetricCard title="客户总数" value={rows.length} icon={Users} />
      <CrmCard>
        <CrmSectionHeading
          title="客户列表"
          description="虚构演示数据"
          action={
            <CrmButton variant="primary" onClick={() => edit()}>
              <Plus size={16} />
              新增客户
            </CrmButton>
          }
        />
        {storageError && (
          <p className="crm-error" role="alert">
            {storageError}
          </p>
        )}
        {notice && (
          <p className="crm-notice" role="status">
            {notice}
          </p>
        )}
        <CrmFilterBar>
          <CrmTextFilter
            value={query}
            onChange={(v) => {
              setQuery(v);
              setPage(1);
            }}
            placeholder="客户名称 / 国家 / 负责人"
            label="搜索客户"
          />
          <CrmSelectFilter
            value={status}
            onChange={(v) => {
              setStatus(v);
              setPage(1);
            }}
            options={["合作中", "潜在客户", "已归档"]}
            placeholder="全部状态"
          />
        </CrmFilterBar>
        <CrmDataTable<Customer>
          rows={filtered.slice(
            (currentPage - 1) * pageSize,
            currentPage * pageSize,
          )}
          rowKey={(r) => r.id}
          loading={!ready}
          emptyText={
            query || status
              ? "没有符合筛选条件的客户"
              : "暂无客户，点击新增客户开始"
          }
          columns={[
            {
              key: "name",
              title: "客户名称",
              render: (r) => (
                <button
                  className="crm-link-button"
                  onClick={() => setViewId(r.id)}
                >
                  {r.name}
                </button>
              ),
            },
            {
              key: "country",
              title: "国家",
              render: (r) => r.country || "未填写",
            },
            { key: "owner", title: "负责人", render: (r) => r.owner },
            {
              key: "status",
              title: "状态",
              render: (r) => <span className="crm-badge">{r.status}</span>,
            },
            {
              key: "amount",
              title: "累计销售额（元）",
              render: (r) =>
                r.amount.toLocaleString("zh-CN", { minimumFractionDigits: 2 }),
            },
            {
              key: "actions",
              title: "操作",
              width: "170px",
              render: (r) => (
                <div className="crm-inline">
                  <button
                    className="crm-link-button"
                    onClick={() => setViewId(r.id)}
                  >
                    查看
                  </button>
                  <button className="crm-link-button" onClick={() => edit(r)}>
                    编辑
                  </button>
                  <button
                    className="crm-link-button crm-danger-text"
                    onClick={() => setDeleting(r)}
                  >
                    删除
                  </button>
                </div>
              ),
            },
          ]}
        />
        <CrmPaginationFooter
          total={rows.length}
          filtered={filtered.length}
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setPage}
          itemLabel="个客户"
        />
      </CrmCard>
      <CrmDetailDrawer
        open={Boolean(viewing)}
        title="客户详情"
        onClose={() => setViewId(null)}
      >
        {viewing && (
          <>
            <div className="crm-profile">
              <span className="crm-user">{viewing.name[0]}</span>
              <h3>{viewing.name}</h3>
              <span className="crm-badge">{viewing.status}</span>
            </div>
            <dl className="crm-details">
              <dt>客户名称</dt>
              <dd>{viewing.name}</dd>
              <dt>国家</dt>
              <dd>{viewing.country || "未填写"}</dd>
              <dt>负责人</dt>
              <dd>{viewing.owner}</dd>
              <dt>累计销售额</dt>
              <dd>{viewing.amount.toLocaleString("zh-CN")} 元</dd>
              <dt>关联商机</dt>
              <dd>{viewing.linkedOpportunityCount || 0} 个</dd>
            </dl>
            <CrmButton onClick={() => edit(viewing)}>编辑客户</CrmButton>
          </>
        )}
      </CrmDetailDrawer>
      <CrmFormModal
        open={Boolean(draft)}
        title={draft?.id ? "编辑客户" : "新增客户"}
        onClose={() => setDraft(null)}
        footer={
          <CrmModalFooter
            onCancel={() => setDraft(null)}
            onSubmit={save}
            submitText="保存客户"
          />
        }
      >
        {draft && (
          <>
            {(
              [
                ["name", "客户名称 *"],
                ["country", "国家"],
                ["owner", "负责人 *"],
                ["amount", "累计销售额（元）"],
              ] as const
            ).map(([key, label]) => (
              <CrmField key={key} label={label}>
                <input
                  className="control"
                  type={key === "amount" ? "number" : "text"}
                  min={key === "amount" ? 0 : undefined}
                  step={key === "amount" ? "0.01" : undefined}
                  value={draft[key]}
                  onChange={(e) =>
                    setDraft({ ...draft, [key]: e.target.value })
                  }
                />
              </CrmField>
            ))}
            <CrmField label="客户状态">
              <select
                className="control"
                value={draft.status}
                onChange={(e) => setDraft({ ...draft, status: e.target.value })}
              >
                {["合作中", "潜在客户", "已归档"].map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </CrmField>
            {error && (
              <p className="crm-error crm-field-wide" role="alert">
                {error}
              </p>
            )}
          </>
        )}
      </CrmFormModal>
      <CrmConfirmDialog
        open={Boolean(deleting)}
        title={
          (deleting?.linkedOpportunityCount || 0) > 0
            ? "客户存在关联商机"
            : `确定删除客户「${deleting?.name || ""}」吗？`
        }
        description={
          (deleting?.linkedOpportunityCount || 0) > 0
            ? "请先处理关联业务，保留数据追溯关系。"
            : "此操作会移除该客户，请确认是否继续。"
        }
        error={
          (deleting?.linkedOpportunityCount || 0) > 0
            ? "存在关联商机，不能删除。"
            : undefined
        }
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting || (deleting.linkedOpportunityCount || 0) > 0) return;
          setRows((rs) => rs.filter((r) => r.id !== deleting.id));
          if (viewId === deleting.id) setViewId(null);
          setDeleting(null);
          setNotice("客户已删除。");
        }}
      />
    </div>
  );
}
