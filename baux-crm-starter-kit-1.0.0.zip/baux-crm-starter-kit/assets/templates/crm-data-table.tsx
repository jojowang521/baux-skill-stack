"use client";
import { type ReactNode } from "react";
import { cn, CrmButton } from "./crm-components";
export type CrmColumn<T> = {
  key: string;
  title: string;
  width?: string;
  className?: string;
  render: (row: T, index: number) => ReactNode;
};
export function CrmFilterBar({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={cn("crm-filters", className)}>{children}</div>;
}
export function CrmTextFilter({
  value,
  onChange,
  placeholder,
  label = "搜索",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  label?: string;
}) {
  return (
    <input
      className="control"
      aria-label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
    />
  );
}
export function CrmSelectFilter({
  value,
  onChange,
  options,
  placeholder,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder: string;
  label?: string;
}) {
  return (
    <select
      className="control"
      aria-label={label || placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">{placeholder}</option>
      {options.map((x) => (
        <option key={x}>{x}</option>
      ))}
    </select>
  );
}
export function CrmDataTable<T>({
  columns,
  rows,
  rowKey,
  minWidth = 720,
  emptyText = "暂无数据",
  loading = false,
}: {
  columns: CrmColumn<T>[];
  rows: T[];
  rowKey: (row: T, index: number) => string;
  minWidth?: number;
  emptyText?: string;
  loading?: boolean;
}) {
  return (
    <div
      className="crm-table-scroll"
      tabIndex={0}
      role="region"
      aria-label="数据列表"
      aria-busy={loading}
    >
      <table className="crm-table" style={{ minWidth }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th
                scope="col"
                key={c.key}
                style={{ width: c.width }}
                className={c.className}
              >
                {c.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td colSpan={columns.length} className="crm-empty" role="status">
                正在加载…
              </td>
            </tr>
          ) : rows.length ? (
            rows.map((r, i) => (
              <tr key={rowKey(r, i)}>
                {columns.map((c) => (
                  <td key={c.key} className={c.className}>
                    {c.render(r, i)}
                  </td>
                ))}
              </tr>
            ))
          ) : (
            <tr>
              <td className="crm-empty" colSpan={columns.length}>
                {emptyText}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
export function CrmPaginationFooter({
  total,
  filtered,
  currentPage,
  totalPages,
  onPageChange,
  itemLabel = "条数据",
}: {
  total: number;
  filtered: number;
  currentPage: number;
  totalPages: number;
  onPageChange: (p: number) => void;
  itemLabel?: string;
}) {
  const pages = Math.max(1, totalPages),
    page = Math.min(pages, Math.max(1, currentPage));
  return (
    <div className="crm-pagination">
      <span>
        筛选结果 {filtered} / {total} {itemLabel}
      </span>
      <div>
        <CrmButton disabled={page <= 1} onClick={() => onPageChange(page - 1)}>
          上一页
        </CrmButton>
        <span aria-live="polite">
          {page} / {pages}
        </span>
        <CrmButton
          disabled={page >= pages}
          onClick={() => onPageChange(page + 1)}
        >
          下一页
        </CrmButton>
      </div>
    </div>
  );
}
