"use client";
import { useState, type ReactNode, type MouseEvent } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "./crm-components";
export type CrmNavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  badge?: number | string;
};
export type CrmPageMeta = {
  match: (pathname: string) => boolean;
  title: string;
  description?: string;
  breadcrumb?: { href: string; label: string; current: string };
};
export function CrmShell({
  appName,
  subtitle,
  logoSrc,
  userLabel = "用户",
  pathname,
  navItems,
  pageMeta,
  onNavigate,
  headerActions,
  children,
}: {
  appName: string;
  subtitle?: string;
  logoSrc?: string;
  userLabel?: string;
  pathname: string;
  navItems: CrmNavItem[];
  pageMeta: CrmPageMeta[];
  onNavigate?: (href: string) => void;
  headerActions?: ReactNode;
  children: ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false),
    [mobile, setMobile] = useState(false);
  const meta = pageMeta.find((m) => m.match(pathname)) || pageMeta[0];
  function navigate(e: MouseEvent<HTMLAnchorElement>, href: string) {
    if (
      onNavigate &&
      !e.metaKey &&
      !e.ctrlKey &&
      !e.shiftKey &&
      !e.altKey &&
      e.button === 0
    ) {
      e.preventDefault();
      onNavigate(href);
    }
    setMobile(false);
  }
  return (
    <div
      className={cn("baux-crm crm-shell", collapsed && "crm-shell-collapsed")}
    >
      <aside className="crm-sidebar">
        <div className="crm-brand">
          {logoSrc && <img src={logoSrc} alt="" />}
          {!collapsed && (
            <div>
              <strong>{appName}</strong>
              <small>{subtitle}</small>
            </div>
          )}
          <button
            className="crm-icon-button"
            onClick={() => setCollapsed(!collapsed)}
            aria-label={collapsed ? "展开导航" : "收起导航"}
          >
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>
        <nav aria-label="主导航">
          {navItems.map((n) => (
            <a
              key={n.href}
              href={n.href}
              aria-label={n.label}
              aria-current={
                pathname === n.href ||
                (n.href !== "/" && pathname.startsWith(n.href + "/"))
                  ? "page"
                  : undefined
              }
              onClick={(e) => navigate(e, n.href)}
              title={n.label}
            >
              <n.icon size={17} />
              {!collapsed && (
                <>
                  <span>{n.label}</span>
                  {n.badge !== undefined && <small>{n.badge}</small>}
                </>
              )}
            </a>
          ))}
        </nav>
      </aside>
      <div className="crm-main">
        <header className="crm-topnav">
          <button
            className="crm-mobile-toggle crm-icon-button"
            aria-expanded={mobile}
            aria-label="切换移动导航"
            onClick={() => setMobile(!mobile)}
          >
            {mobile ? <X size={18} /> : <Menu size={18} />}
          </button>
          <div className="crm-page-meta">
            {meta?.breadcrumb ? (
              <div className="crm-breadcrumb">
                <a
                  href={meta.breadcrumb.href}
                  onClick={(e) => navigate(e, meta.breadcrumb!.href)}
                >
                  {meta.breadcrumb.label}
                </a>
                <ChevronRight size={14} />
                <h1>{meta.breadcrumb.current}</h1>
              </div>
            ) : (
              <>
                <h1>{meta?.title || appName}</h1>
                {meta?.description && <p>{meta.description}</p>}
              </>
            )}
          </div>
          <div className="crm-header-actions">
            {headerActions}
            <span className="crm-user" title={userLabel}>
              {userLabel.slice(0, 1)}
            </span>
          </div>
        </header>
        {mobile && (
          <nav className="crm-mobile-nav" aria-label="移动导航">
            {navItems.map((n) => (
              <a
                key={n.href}
                href={n.href}
                aria-current={pathname === n.href ? "page" : undefined}
                onClick={(e) => navigate(e, n.href)}
              >
                <n.icon size={17} />
                {n.label}
              </a>
            ))}
          </nav>
        )}
        <main className="crm-content">{children}</main>
      </div>
    </div>
  );
}
