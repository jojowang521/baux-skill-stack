"use client";
import { FileText } from "lucide-react";
export type CrmReportListItem = {
  id: string;
  title: string;
  type: string;
  fileName: string;
  rowCount: number;
  createdAt: string;
  status: string;
  builtIn?: boolean;
};
export function CrmReportFrame({ src, title }: { src: string; title: string }) {
  return <iframe className="crm-report-frame" src={src} title={title} />;
}
export function CrmReportNameLink({
  href,
  title,
}: {
  href: string;
  title: string;
}) {
  return (
    <a className="crm-report-link" href={href}>
      <FileText size={16} />
      {title}
    </a>
  );
}
export function reportTheme(title: string) {
  if (title.includes("增长"))
    return { name: "growth", brand: "#F97316", soft: "#FFF7ED" };
  if (title.includes("经营"))
    return { name: "ops", brand: "#10B981", soft: "#ECFDF5" };
  return { name: "sales", brand: "#3569FD", soft: "#EEF3FF" };
}
