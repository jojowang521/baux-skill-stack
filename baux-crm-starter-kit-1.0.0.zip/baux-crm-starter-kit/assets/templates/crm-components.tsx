"use client";
import {
  useEffect,
  useId,
  useRef,
  useState,
  type ReactNode,
  type ButtonHTMLAttributes,
} from "react";
import { createPortal } from "react-dom";
import { AlertTriangle, X, type LucideIcon } from "lucide-react";

export function cn(...values: Array<string | false | undefined>) {
  return values.filter(Boolean).join(" ");
}
export function CrmButton({
  variant = "default",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "primary" | "danger";
}) {
  return (
    <button
      type="button"
      className={cn("crm-button", `crm-button-${variant}`, className)}
      {...props}
    />
  );
}
export function CrmCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={cn("crm-card", className)}>{children}</section>;
}
export function CrmSectionHeading({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="crm-section-heading">
      <div>
        <h2>{title}</h2>
        {description && <p className="crm-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}
export function CrmMetricCard({
  title,
  value,
  unit,
  icon: Icon,
  tone = "blue",
  variant = "icon",
}: {
  title: string;
  value: string | number;
  unit?: string;
  icon: LucideIcon;
  tone?: "blue" | "green" | "amber" | "rose" | "violet";
  variant?: "icon" | "gradient";
}) {
  return (
    <CrmCard
      className={cn(
        "crm-metric",
        `crm-tone-${tone}`,
        variant === "gradient" && "crm-metric-gradient",
      )}
    >
      <div className="crm-muted">{title}</div>
      <div className="crm-metric-line">
        <strong>
          {value}
          <small>{unit}</small>
        </strong>
        {variant === "icon" && (
          <span className="crm-metric-icon">
            <Icon size={20} />
          </span>
        )}
      </div>
    </CrmCard>
  );
}
// The stack makes Esc/Tab apply only to the topmost overlay. Portals escape shell stacking contexts.
const dialogs: Array<symbol> = [];
let locks = 0,
  savedOverflow = "";
export function CrmDialog({
  open,
  title,
  onClose,
  children,
  footer,
  drawer = false,
  alert = false,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  drawer?: boolean;
  alert?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  const titleId = useId();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!open || !mounted) return;
    const token = Symbol();
    dialogs.push(token);
    const previous = document.activeElement as HTMLElement | null;
    if (locks++ === 0) {
      savedOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
    }
    const root = ref.current;
    const focusable = () =>
      Array.from(
        root?.querySelectorAll<HTMLElement>(
          'button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]',
        ) || [],
      ).filter((el) => !el.hidden && el.getClientRects().length > 0);
    (
      root?.querySelector<HTMLElement>("[data-crm-autofocus]") ||
      focusable()[0] ||
      root
    )?.focus();
    const key = (e: KeyboardEvent) => {
      if (dialogs[dialogs.length - 1] !== token) return;
      if (e.key === "Escape") {
        e.preventDefault();
        close.current();
      }
      if (e.key === "Tab") {
        const els = focusable(),
          first = els[0],
          last = els[els.length - 1];
        if (!first) {
          e.preventDefault();
          root?.focus();
        } else if (
          e.shiftKey &&
          (document.activeElement === first ||
            !root?.contains(document.activeElement))
        ) {
          e.preventDefault();
          last.focus();
        } else if (
          !e.shiftKey &&
          (document.activeElement === last ||
            document.activeElement === root ||
            !root?.contains(document.activeElement))
        ) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("keydown", key);
      dialogs.splice(dialogs.indexOf(token), 1);
      if (--locks === 0) document.body.style.overflow = savedOverflow;
      if (previous?.isConnected) previous.focus();
    };
  }, [open, mounted]);
  if (!open || !mounted) return null;
  return createPortal(
    <div
      className={cn("crm-overlay", drawer && "crm-overlay-drawer")}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && !alert) onClose();
      }}
    >
      <div
        ref={ref}
        role={alert ? "alertdialog" : "dialog"}
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={drawer ? "crm-drawer" : "crm-modal"}
      >
        <header className="crm-dialog-header">
          <h2 id={titleId}>{title}</h2>
          <button
            type="button"
            className="crm-icon-button"
            aria-label="关闭"
            onClick={onClose}
          >
            <X size={18} />
          </button>
        </header>
        <div className="crm-dialog-body">{children}</div>
        {footer && <footer className="crm-dialog-footer">{footer}</footer>}
      </div>
    </div>,
    document.body,
  );
}
export function CrmDetailDrawer({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <CrmDialog open={open} title={title} onClose={onClose} drawer>
      {children}
    </CrmDialog>
  );
}
export function CrmConfirmDialog({
  open,
  title,
  description,
  onCancel,
  onConfirm,
  busy = false,
  error,
}: {
  open: boolean;
  title: string;
  description: string;
  onCancel: () => void;
  onConfirm: () => void | Promise<void>;
  busy?: boolean;
  error?: string;
}) {
  return (
    <CrmDialog
      open={open}
      title={title}
      onClose={() => {
        if (!busy) onCancel();
      }}
      alert
      footer={
        <>
          <CrmButton data-crm-autofocus onClick={onCancel} disabled={busy}>
            取消
          </CrmButton>
          <CrmButton variant="danger" onClick={onConfirm} disabled={busy}>
            {busy ? "处理中…" : "确定"}
          </CrmButton>
        </>
      }
    >
      <div className="crm-warning">
        <AlertTriangle size={20} />
        <p>{description}</p>
      </div>
      {error && (
        <p className="crm-error" role="alert">
          {error}
        </p>
      )}
    </CrmDialog>
  );
}
