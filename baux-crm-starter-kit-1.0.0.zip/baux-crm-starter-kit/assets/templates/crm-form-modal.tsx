"use client";
import { type ReactNode } from "react";
import { CrmButton, CrmDialog, cn } from "./crm-components";
export function CrmFormModal({
  open,
  title,
  onClose,
  children,
  footer,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <CrmDialog open={open} title={title} onClose={onClose} footer={footer}>
      <div className="crm-form-grid">{children}</div>
    </CrmDialog>
  );
}
export function CrmField({
  label,
  children,
  wide = false,
  error,
}: {
  label: string;
  children: ReactNode;
  wide?: boolean;
  error?: string;
}) {
  return (
    <label className={cn("crm-field", wide && "crm-field-wide")}>
      <span>{label}</span>
      {children}
      {error && (
        <small className="crm-error" role="alert">
          {error}
        </small>
      )}
    </label>
  );
}
export function CrmModalFooter({
  onCancel,
  onSubmit,
  submitText = "保存",
  busy = false,
  disabled = false,
}: {
  onCancel: () => void;
  onSubmit: () => void | Promise<void>;
  submitText?: string;
  busy?: boolean;
  disabled?: boolean;
}) {
  return (
    <>
      <CrmButton onClick={onCancel} disabled={busy}>
        取消
      </CrmButton>
      <CrmButton
        variant="primary"
        onClick={onSubmit}
        disabled={busy || disabled}
      >
        {busy ? "保存中…" : submitText}
      </CrmButton>
    </>
  );
}
