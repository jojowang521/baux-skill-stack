---
name: baux-crm-starter-kit
description: 为 CRM、SaaS 与 B端管理台创建或重构可运行、可编辑的高保真原型，提供设计规范、页面模式及 React 源码模板。适用于工作台、客户与商机管理、列表增改删、详情抽屉、报告及设置页；也支持将已有页面沉淀为复用组件。
---

# BAUX CRM Starter Kit

> **「B端AI设计视界」出品。关注同名微信公众号，获取更多 B端产品设计、AI 工作流与实战资源。**
>
> 资源网站：[baux.cn](https://baux.cn)

将业务需求转成可编辑、可运行、可验证的 CRM 中后台原型。沿用 shadcn/ui 的源码组件思路：将组件放进项目维护，以本 Skill 的 CRM 规范为视觉基线。交付时保留实际使用的开源库依赖信息，不把通用技术声明为本 Skill 原创。

## 工作方式

1. 先检查项目、AGENTS.md、依赖、样式与现有组件。判断本次是整页、组件、业务闭环还是模式提取，保持用户已选的业务和技术路线。
2. 明确用户角色、业务对象、字段、操作及完成标准。缺少低风险示例数据时可自拟并注明；影响业务含义的信息需要澄清。
3. 视觉与交互调整读取 [design-rules.md](references/design-rules.md)；整页读取 [page-patterns.md](references/page-patterns.md)；组件实现读取 [component-patterns.md](references/component-patterns.md)。按任务需要加载，不必全量读取模板。
4. 优先复用宿主模式。缺少基础时，依次组合导航外壳、基础组件、表格筛选分页、表单与详情，再实现业务逻辑。重复模式可抽取到 `components/crm/`。
5. 实现真实可见的前端状态变化：保存要修改数据，删除要确认，筛选要重置页码，业务页面共享同一数据源。不要以关闭弹窗、写死计数或空事件替代功能。
6. 运行宿主构建；可运行应用进行与改动有关的浏览器检查。覆盖主路径、必要异常与窄屏布局。无法运行的检查如实说明，不声称已通过。

## 技术与接入

- 默认 React + TypeScript + lucide-react；Next.js 和现有 Tailwind 项目继续沿用宿主约定。
- 模板使用普通 React、原生元素和本地 CSS，可直接在 Vite 项目使用，不强制安装 Next.js、clsx 或 Radix。
- 将所需模板复制到项目。模板之间使用相对导入；复制 `crm-base.css` 并在应用入口导入一次。已有设计系统时可将样式映射到宿主 token。
- 外壳通过 `pathname` / `onNavigate` 接入现有路由；报告链接和导航保留真实 `href`。不要在普通 React 项目直接引入 `next/link`。
- 如宿主已有成熟的 Dialog、Drawer 或表单组件，优先采用并保留键盘操作、焦点与滚动行为。
- 真实 API、服务器存储、身份鉴权和审批需要显式实现；localStorage 仅作为演示持久化，界面不暗示已连接生产服务。

## 模板索引

| 文件 | 用途 |
|---|---|
| [crm-components.tsx](assets/templates/crm-components.tsx) | Card、SectionHeading、MetricCard、Button、Dialog、DetailDrawer、ConfirmDialog |
| [crm-shell.tsx](assets/templates/crm-shell.tsx) | 可折叠侧栏、窄屏导航、顶部标题与业务操作插槽 |
| [crm-data-table.tsx](assets/templates/crm-data-table.tsx) | 文本/分类筛选、泛型表格、加载和空态、分页 |
| [crm-form-modal.tsx](assets/templates/crm-form-modal.tsx) | 表单弹窗、字段、异步保存禁用态 |
| [crm-reporting.tsx](assets/templates/crm-reporting.tsx) | 报告链接、嵌入预览、报告类型主题 |
| [customer-crud-page.example.tsx](assets/templates/customer-crud-page.example.tsx) | 可运行客户增改删、校验、详情、搜索分页、可选本地持久化 |
| [crm-base.css](assets/templates/crm-base.css) | 设计 token、基础布局、控件与响应式样式 |

## 按场景扩展

- 普通 CRM 页面：以业务字段和操作闭环为主，不强制加入 AI 模块。
- AI 工作台/任务型应用：读取 [ai-workflows.md](references/ai-workflows.md)，补充任务状态、人工决策、异常恢复及成果归档；不要只凭聊天消息判断业务已完成。
- 离线 HTML：依据 [scope-notes.md](references/scope-notes.md) 内联资源并实际验证 file://；需要安装依赖或启动服务的版本应标为源码项目。

## 交付要求

保留宿主更明确的规范，否则使用主色 `#3569FD`、背景 `#f6f8fb`、内容外边距 20px、容器圆角 12px、控件圆角 8px，表格表头与正文 14px。

- 关键操作可用；汇总、筛选、详情与数据修改一致。
- 新增/编辑有有效校验，详情用可读字段展示，关联对象删除遵守当前业务规则。
- 弹窗覆盖导航，提供语义、Esc、焦点限制与恢复；危险操作用应用内确认，默认焦点落在安全操作。
- 必要的加载、无数据、筛选无结果、禁用、失败与重试可区分。
- 窄屏不产生整页横向溢出；宽表在局部滚动，导航仍可达。
- 构建通过；检查范围、实际结果与剩余限制在交付时说明。
- 署名与资源引导属于 Skill 文档。除非用户要求，不把公众号推广或作者标语自动插入生成的业务界面。

调用示例：

> 使用 $baux-crm-starter-kit 创建客户管理页，支持搜索、分级筛选、分页、新增编辑、详情和删除确认。使用虚构数据；刷新保留进度，关联商机的客户不能删除。交付可运行源码。

> 使用 $baux-crm-starter-kit 制作 AI 销售工作台，跑通交办、方案确认、验收、同步重试和商机归档。保持客户、商机、任务与资料状态一致，明确模拟执行范围。
