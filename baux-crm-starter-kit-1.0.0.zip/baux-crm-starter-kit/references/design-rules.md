# CRM Design Rules

## Intent

This CRM style is for business operators scanning repeated work: customers, orders, payments, reports, risks, and actions. It should feel calm, dense, and operational. Avoid marketing-page hero treatment.

## Tokens

- Primary: `#3569FD`
- Brand soft: `#EEF3FF`
- Page background: `#f6f8fb`
- Main text: `#0f172a` or Tailwind `slate-950`
- Secondary text: Tailwind `slate-500` / `slate-600`
- Border: Tailwind `slate-200`
- Content outer padding: `20px`
- Container radius: `12px`
- Button/control radius: `8px`
- Card shadow: subtle, no heavy floating panels

## Layout

- Use a left sidebar + top nav shell for desktop.
- Sidebar supports expanded/collapsed states.
- Top nav owns the page title. Avoid duplicate page titles inside the content area.
- Page content uses `20px` outer padding.
- Sections use `space-y-5` or equivalent `20px` vertical rhythm.
- Do not nest cards inside cards unless the inner card is a repeated item or detail block.

## Cards

- Cards are white with `12px` radius.
- Metric cards use right-side icons in soft color blocks.
- Keep descriptions in tooltip icons when they are explanatory, not primary content.
- Units like `万` should be small and aligned to the number baseline.

## Icons

- Use `lucide-react` icons by default. Do not mix icon libraries inside one page unless the host project already has a stronger convention.
- Keep icons linear/outline style. Avoid filled emoji, decorative illustrations, and mixed stroke styles in operational CRM screens.
- Do not use emoji as icons anywhere in the CRM UI. Use lucide line icons or source-owned SVG icons that match the demo's linear style.
- Match the demo icon style: thin outline, rounded stroke joins, restrained size, soft-color icon containers for metric cards, and no decorative standalone icons.
- Choose icons by business meaning, not decoration:
  - customers: `Users`, `UserRound`, `Building2`
  - orders/tasks: `ClipboardList`, `PackageCheck`, `Truck`, `CalendarDays`
  - money/payments: `CircleDollarSign`, `Banknote`, `WalletCards`, `ReceiptText`
  - risk/warning: `AlertTriangle`, `ShieldAlert`, `CircleAlert`
  - reports/files: `FileText`, `BarChart3`, `ChartNoAxesCombined`
  - settings: `Settings`, `SlidersHorizontal`
- Standard sizes:
  - sidebar navigation: `17px`
  - top-nav utility icon: `18px`
  - button icon: `16px`
  - metric card icon: `20px` inside a `40px` soft-color block
  - close icon: `18px`
  - warning dialog icon: `20px` inside a `36px` circle
- Icon buttons should use `36px` or `40px` square hit areas with `8px` radius, even when the icon itself is smaller.
- In metric rows with many cards or long values, omit the right icon and use a soft color-to-white gradient background instead.
- Icons must not overlap text, shrink data columns, or make numbers wrap. Preserve at least `12px` spacing between icon blocks and text.
- Do not use icons as the only signal for destructive or risky actions; pair with text or a confirmation dialog.

## Tables

- Header and body font size should match at `14px`.
- Keep row hover subtle.
- Put list-level actions on the far right of the list title row.
- Put filters below the list title.
- Put summary count bottom-left and pagination bottom-right.
- Operation columns must be wide enough for aligned action buttons.

## Forms

- Use modal forms for create/edit unless the form is complex enough for a dedicated page.
- Use drawers for view/detail.
- Controls use `8px` radius and consistent height.
- Select arrows need custom right padding and must not touch the border.

## Overlays

- Drawers and modals must overlay top navigation.
- Use z-index above the shell, e.g. `z-[100]`.
- Delete confirmation uses a standard warning dialog with an icon, title, body text, cancel button, and red confirm button.

## Reports

- Report library is a list/table.
- Clicking report name opens the report.
- Report detail can embed HTML reports in the CRM shell.
- Different report themes may use distinct gradients:
  - Sales: blue
  - Operations: green
  - Growth: orange
