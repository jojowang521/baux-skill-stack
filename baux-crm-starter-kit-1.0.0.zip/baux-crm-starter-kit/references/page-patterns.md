# CRM Page Patterns

## Workbench / Dashboard

Use when the page summarizes cross-module or cross-report operations.

Structure:

1. KPI summary row
2. AI/business interpretation panel
3. Operational charts
4. Action list/table

Guidelines:

- Do not duplicate KPI numbers inside AI interpretation.
- Use tabs/segmented controls for action-list categories.
- Dashboard charts should answer different questions, not repeat the same chart form.

## List Page

Use for customers, orders, payments, reports, and master data.

Structure:

1. Optional metric cards
2. Main list card
3. List title row with right-side actions
4. Filters below title
5. Table
6. Footer with count left and pagination right

Required states:

- Loading
- Empty
- Filtered empty
- Row hover
- Disabled pagination

## CRUD Page

Use for editable entities.

Behavior:

- Create/edit in a centered modal.
- View in a right-side detail drawer.
- Delete through a standard confirm dialog, not browser `confirm`.
- Persist local demo data with localStorage only in prototype mode.

## Detail Drawer

Structure:

1. Sticky drawer header with title and close icon
2. Profile/summary card
3. Basic information card
4. Related records or actions if needed

Rules:

- Drawer overlay must cover top nav.
- Drawer width around `520px` for business profiles.
- Close icon is an icon button, not text.

## Report Library

Structure:

1. List title `本地报告库` or domain-specific label
2. New report action on the right
3. Table with report name, type, source, rows, generated time, status, operations

Rules:

- Report name is clickable.
- Report name hover uses primary blue.
- Built-in reports are not deletable.

## Report Detail

Structure:

1. Shell breadcrumb in top nav
2. Embedded report or native report view
3. Download actions inside the report header

Rules:

- Embedded report should visually blend into the CRM shell.
- Report background may use type-specific gradients.

## Upload / Generation Flow

Structure:

1. Process steps
2. Report configuration
3. Upload zone
4. Field recognition result
5. Output preview
6. Data preview
7. Generate action

Rules:

- Support multiple known data schemas when the product has multiple report types.
- Error messages should say what schema was expected and what was detected.
