# 组件实现与模板接入

## 源码接入

模板使用 React、React DOM、lucide-react 与 crm-base.css。复制所需文件到同一组件目录，入口导入 CSS 一次。模板没有 Next.js、clsx 或 Radix 的硬依赖。已有 Tailwind 或设计系统时，保留组件行为并映射宿主样式，不必同时叠加两套全局样式。

模板不是 npm 包。项目内可以改名和拆分；不要生成不存在的 baux-crm-starter-kit npm import。宿主已有更完善的组件时优先复用。

## 外壳

CrmShell 接收 appName、pathname、navItems、pageMeta、可选 onNavigate/headerActions。pathname 由宿主提供；onNavigate 适配现有客户端路由；不传时使用 href 普通跳转。headerActions 放置有真实行为的通知、搜索或设置。小屏通过菜单按钮展开导航。

## 表格

CrmDataTable<T> 接收 columns、rows、rowKey，可选 minWidth、emptyText、loading。每列 render 负责业务呈现，rowKey 使用稳定业务 ID。表格容器支持局部滚动；表头和正文都是 14px。

过滤、分页由页面管理。筛选改变回第一页；删除末页最后一项后重新计算有效页码。用 filtered 表示筛选结果数，不把它描述为当前页行数。加载中不展示旧表格操作。

## 表单

CrmFormModal 组合 CrmDialog；CrmField 提供 label 包裹，CrmModalFooter 支持 busy 与 disabled。页面维护 Draft，金额字符串在提交时校验并转换。必填、重复名称、无效金额明确报错；服务端规则由接口再次校验。

客户示例覆盖新增、编辑、搜索、分类筛选、分页、详情、删除、关联商机删除保护。storageKey 可选，代表演示存储命名空间；initialRows 是初始数据。真实业务通过宿主状态/接口替换，不保留演示 localStorage。

## 弹窗与抽屉

CrmDialog 通过 portal 渲染到 body，使用统一 z-index 和 DOM 顺序保证嵌套层级。管理焦点进入、Tab 循环、Esc、关闭后的焦点恢复及页面滚动锁。删除确认默认聚焦取消；忙碌状态禁止取消和重复确认。抽屉调用相同底层行为。

复杂应用已有 Radix 等组件时可替换底层，保留同等交互。不要在表格行内创建重复 IDs 或用图标替代所有操作文字。

## 指标与报告

MetricCard 的值与图标用流式布局，长数值不被绝对定位图标覆盖；单位紧跟数值。仪表盘统计应从共享业务数据计算。

CrmReportNameLink 使用普通链接，CrmReportFrame 只负责嵌入。iframe 内容来自用户允许的可信来源；此模板不提供不可信 HTML 的隔离机制。报告可见范围和正式状态由业务模型处理。
