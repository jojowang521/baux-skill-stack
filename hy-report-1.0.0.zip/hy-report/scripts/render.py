#!/usr/bin/env python3
"""
render.py — HY Report Skill 渲染引擎
接收 report_data.json，输出自包含单文件 HTML（G2 内联，离线可用）

核心设计：
  - g2_spec 字段直接序列化为 JS 对象，不做任何翻译
  - Claude 通过 mcp-server-antv 获取的 spec 在这里原样注入
  - 渲染层只负责：HTML骨架 + CSS + 数据注入 + mk() 挂载
"""
import json
import sys
import argparse
import html as html_module
import re
from pathlib import Path

SKILL_DIR = Path(__file__).parent.parent
def text(value):
    return html_module.escape(str(value), quote=True)

def paragraphs(value):
    escaped = text(value)
    bold = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
    return "".join("<p>" + line.strip().replace("\n", "<br>") + "</p>" for line in bold.split("\n\n") if line.strip())

ALLOW_JS_FUNCTIONS = False

def spec_json(spec):
    raw = json.dumps(spec, ensure_ascii=False, allow_nan=False)
    if "=>" in raw and not ALLOW_JS_FUNCTIONS:
        raise ValueError("Function-valued specs require --allow-js-functions and reviewed, trusted JSON")
    if ALLOW_JS_FUNCTIONS:
        return unescape_js_functions(raw).replace("</", "<\\/")
    return raw.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


G2_PATH = SKILL_DIR / "assets" / "g2.min.js"

PALETTE = ["#3569FD", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#06B6D4", "#F97316", "#EC4899"]

# ── 主题配置 ─────────────────────────────────────────────────────────────────
THEMES = {
    "销售蓝": {"brand": "#3569FD", "brand_soft": "#EEF3FF", "brand_border": "#C7D7FE"},
    "经营绿": {"brand": "#10B981", "brand_soft": "#ECFDF5", "brand_border": "#A7F3D0"},
    "增长橙": {"brand": "#F97316", "brand_soft": "#FFF7ED", "brand_border": "#FED7AA"},
    "暮光紫": {"brand": "#7C3AED", "brand_soft": "#F5F3FF", "brand_border": "#DDD6FE"},
    "党建红": {"brand": "#DC2626", "brand_soft": "#FEF2F2", "brand_border": "#FECACA"},
}

BUSINESS_THEME = {
    "sales": "销售蓝",
    "ops": "经营绿",
    "growth": "增长橙",
}

def get_theme(name: str, business_type: str = "") -> dict:
    selected = name if name in THEMES and name != "auto" else BUSINESS_THEME.get(business_type, "销售蓝")
    return THEMES.get(selected, THEMES["销售蓝"])


# ── HTML 构件 ────────────────────────────────────────────────────────────────
def render_kpi(kpi: dict, theme: dict) -> str:
    direction = kpi.get("trend_direction", "flat")
    cls = {"up": "up", "down": "down", "flat": "flat"}.get(direction, "flat")
    brand = theme["brand"]
    return f"""
    <div class="kpi-card">
      <div class="kpi-label">{text(kpi.get('label',''))}</div>
      <div class="kpi-value" style="color:{brand}">{text(kpi.get('value',''))}</div>
      <div class="kpi-sub">
        <span class="kpi-trend {cls}">{text(kpi.get('trend',''))}</span>
        <span class="kpi-desc">{text(kpi.get('sub',''))}</span>
      </div>
    </div>"""


def inject_data_to_spec(spec: dict, data: list) -> dict:
    """为 view 类型的 children 以及普通 spec 注入 data"""
    import copy
    spec = copy.deepcopy(spec)
    if spec.get("type") == "view":
        for child in spec.get("children", []):
            if not child.get("data"):
                child["data"] = data
    else:
        if not spec.get("data"):
            spec["data"] = data
    return spec


def unescape_js_functions(spec_str: str) -> str:
    """
    JSON 序列化后箭头函数变成字符串，例如：
      "text": "(d) => d.name"
      "fill": "(d) => d.value > 0 ? '#EF4444' : '#10B981'"
    把这类 JSON 字符串值还原为不带引号的 JS 表达式。
    """
    import re

    def replace_fn(m):
        inner = m.group(1)
        # 还原 JSON 转义的单引号
        js_expr = json.loads('"' + inner + '"')
        if "=>" in js_expr:
            # 是箭头函数，去掉外层引号
            return f": {js_expr}"
        return m.group(0)

    # 匹配 JSON 中 ": "..." " 格式的字符串值
    return re.sub(r':\s*"((?:[^"\\]|\\.)*)"', replace_fn, spec_str)


def render_section(sec: dict, idx: int) -> tuple[str, str]:
    """
    返回 (html片段, js片段)
    html片段：section 的 DOM 结构
    js片段：图表初始化代码
    """
    sec_type = sec.get("type", "chart")
    title = text(sec.get("title", ""))
    desc = text(sec.get("desc", ""))
    sec_id = f"s{idx}"

    # section 头部
    num_html = f'<span class="sec-num">{idx}</span>'
    desc_html = f'<div class="sec-desc">{desc}</div>' if desc else ""
    head = f"""
    <div class="sec-head">
      <div class="sec-head-left">
        {num_html}
        <div>
          <div class="sec-title">{title}</div>
          {desc_html}
        </div>
      </div>
    </div>"""

    if sec_type == "text":
        paras = paragraphs(sec.get("content", ""))
        html = f'<div class="card">{head}<div class="text-body">{paras}</div></div>'
        return html, ""

    if sec_type == "chart":
        cid = f"chart_{sec_id}"
        height = max(120, min(1600, int(sec.get("height", 300))))
        g2_spec = sec.get("g2_spec")
        data = sec.get("data")

        if not g2_spec:
            html = f'<div class="card">{head}<div class="chart-empty">⚠ 无图表 spec</div></div>'
            return html, ""

        # 把 data 注入到 spec 的 data 字段（如果 spec 中 data 是字符串引用）
        # 注入 data（包括 view 类型的 children）
        spec_with_data = inject_data_to_spec(g2_spec, data or [])
        spec_str = spec_json(spec_with_data)
        # 还原箭头函数字符串为 JS 函数表达式


        html = f"""
        <div class="card">
          {head}
          <div class="chart-wrap"><div id="{cid}" style="height:{height}px"></div></div>
        </div>"""

        js = f"""
        (function() {{
          var spec = {spec_str};
          mk('{cid}', spec);
        }})();"""

        return html, js

    if sec_type == "chart_grid":
        charts = sec.get("charts", [])
        html_parts = []
        js_parts = []
        for ci, chart_cfg in enumerate(charts):
            cid = f"chart_{sec_id}_{ci}"
            height = max(120, min(1600, int(chart_cfg.get("height", 240))))
            chart_title = text(chart_cfg.get("title", ""))
            g2_spec = chart_cfg.get("g2_spec")
            data = chart_cfg.get("data")

            sub_title = f'<div class="sub-title">{chart_title}</div>' if chart_title else ""
            if g2_spec:
                spec_with_data = inject_data_to_spec(g2_spec, data or [])
                spec_str = spec_json(spec_with_data)
        
                html_parts.append(f"""
                <div class="grid-cell">
                  {sub_title}
                  <div class="chart-wrap"><div id="{cid}" style="height:{height}px"></div></div>
                </div>""")
                js_parts.append(f"""
                (function() {{
                  var spec = {spec_str};
                  mk('{cid}', spec);
                }})();""")
            else:
                html_parts.append(f'<div class="grid-cell">{sub_title}<div class="chart-empty">⚠ 无 spec</div></div>')

        grid_html = f'<div class="chart-grid-2">{"".join(html_parts)}</div>'
        html = f'<div class="card">{head}{grid_html}</div>'
        js = "\n".join(js_parts)
        return html, js

    if sec_type == "table":
        headers = sec.get("headers", [])
        rows = sec.get("rows", [])
        highlight_col = sec.get("highlight_col")

        th_html = "".join(f"<th>{text(h)}</th>" for h in headers)
        tr_html = ""
        for row in rows:
            tds = ""
            for ci, cell in enumerate(row):
                cls_attr = ' class="highlight"' if ci == highlight_col else ""
                tds += f"<td{cls_attr}>{text(cell)}</td>"
            tr_html += f"<tr>{tds}</tr>"

        html = f"""
        <div class="card">
          {head}
          <div class="tbl-wrap"><table>
            <thead><tr>{th_html}</tr></thead>
            <tbody>{tr_html}</tbody>
          </table></div>
        </div>"""
        return html, ""

    # 未知类型
    return f'<div class="card">{head}<div class="chart-empty">未知 section 类型: {text(sec_type)}</div></div>', ""


# ── 主渲染函数 ────────────────────────────────────────────────────────────────
def render(report_data: dict, output_path: str):
    meta = report_data.get("meta", {})
    theme_name = meta.get("theme", "auto")
    business_type = meta.get("business_type", "")
    theme = get_theme(theme_name, business_type)

    title = text(meta.get("title", "数据分析报告"))
    subtitle = text(meta.get("subtitle", ""))
    period = text(meta.get("period", ""))
    generated = text(meta.get("generated", ""))
    badges = meta.get("badges", [])
    footer = text(report_data.get("footer", f"报告生成于 {generated}"))

    # 提取 summary（摘要/建议）section，渲染到 KPI 之前
    summary_html = ""
    regular_sections = []
    for sec in report_data.get("sections", []):
        if sec.get("type") == "summary":
            paras = paragraphs(sec.get("content", ""))
            title_s = text(sec.get("title", "经营建议"))
            summary_html += f"""
<div class="summary-card">
  <div class="summary-head">
    <span class="summary-icon" aria-hidden="true"></span>
    <span class="summary-label">{title_s}</span>
  </div>
  <div class="summary-body">{paras}</div>
</div>"""
        else:
            regular_sections.append(sec)

    # KPI 行
    kpis_html = "".join(render_kpi(k, theme) for k in report_data.get("kpis", []))

    # 其余 Sections
    sections_html_parts = []
    charts_js_parts = []
    for i, sec in enumerate(regular_sections, start=1):
        html, js = render_section(sec, i)
        sections_html_parts.append(html)
        if js:
            charts_js_parts.append(js)

    sections_html = "\n".join(sections_html_parts)
    charts_js = "\n".join(charts_js_parts)

    # badges
    badges_html = "".join(f'<span class="badge">{text(b)}</span>' for b in badges)

    # G2 库（内联）
    g2_js = ""
    if G2_PATH.exists():
        g2_js = G2_PATH.read_text(encoding="utf-8")
    else:
        raise FileNotFoundError("Missing assets/g2.min.js; offline report cannot be generated")

    brand = theme["brand"]
    brand_soft = theme["brand_soft"]
    brand_border = theme["brand_border"]

    # CSS 变量注入
    css_vars = f"""
    :root {{
      --brand: {brand};
      --brand-soft: {brand_soft};
      --brand-border: {brand_border};
      --ink: #0f172a;
      --sub: #64748b;
      --line: #e2e8f0;
      --bg: #f8fafc;
      --card: #ffffff;
      --up: #10B981;
      --down: #EF4444;
      --warn: #F59E0B;
    }}"""

    html = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
{css_vars}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: var(--bg); color: var(--ink); font-family: "PingFang SC","Microsoft YaHei",sans-serif; font-size: 14px; }}
.page {{ max-width: 1280px; margin: 0 auto; padding: 28px 32px 56px; }}
h1 {{ font-size: 22px; font-weight: 800; }}
.subtitle {{ color: var(--sub); font-size: 13px; margin-top: 5px; }}
.period {{ color: var(--sub); font-size: 12px; margin-top: 4px; font-weight: 600; }}
.badges {{ display: flex; gap: 7px; margin-top: 8px; flex-wrap: wrap; }}
.badge {{ font-size: 11.5px; font-weight: 700; color: var(--brand); background: var(--brand-soft);
  border: 1px solid var(--brand-border); border-radius: 999px; padding: 3px 11px; }}
.kpis {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin: 20px 0 16px; }}
.kpi-card {{ background: var(--card); border: 1px solid var(--line); border-radius: 14px;
  padding: 15px 16px 13px; box-shadow: 0 4px 16px rgba(0,0,0,.04); }}
.kpi-label {{ font-size: 12px; font-weight: 700; color: var(--sub); }}
.kpi-value {{ font-size: 22px; font-weight: 800; margin-top: 8px; }}
.kpi-sub {{ font-size: 12px; margin-top: 8px; line-height: 1.5; display: flex; gap: 6px; align-items: baseline; flex-wrap: wrap; }}
.kpi-trend {{ font-weight: 800; }}
.kpi-desc {{ color: var(--sub); }}
.up {{ color: var(--up); }} .down {{ color: var(--down); }} .flat {{ color: var(--sub); }}
.card {{ background: var(--card); border: 1px solid var(--line); border-radius: 14px;
  padding: 18px; box-shadow: 0 4px 16px rgba(0,0,0,.04); margin-bottom: 14px; }}
.sec-head {{ display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }}
.sec-head-left {{ display: flex; align-items: flex-start; gap: 9px; }}
.sec-num {{ flex: 0 0 auto; width: 22px; height: 22px; border-radius: 6px; background: var(--brand);
  color: #fff; font-size: 11px; font-weight: 800; display: flex; align-items: center; justify-content: center; }}
.sec-title {{ font-size: 14px; font-weight: 800; }}
.sec-desc {{ font-size: 12px; color: var(--sub); margin-top: 3px; line-height: 1.6; }}
.sub-title {{ font-size: 13px; font-weight: 700; margin-bottom: 6px; color: var(--ink); }}
.chart-wrap {{ border: 1px solid var(--line); border-radius: 10px; padding: 6px; background: color-mix(in srgb, var(--brand-soft) 35%, #FAFBFF); margin-top: 8px; }}
.chart-grid-2 {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-top: 8px; }}
.grid-cell {{ display: flex; flex-direction: column; }}
.chart-empty {{ padding: 40px; text-align: center; color: var(--sub); font-size: 13px; }}
.text-body {{ font-size: 13.5px; line-height: 1.9; color: #334155; margin-top: 8px; }}
.text-body p {{ margin-bottom: 12px; }}
.text-body strong {{ color: var(--ink); font-weight: 700; }}
.tbl-wrap {{ border: 1px solid var(--line); border-radius: 10px; overflow: hidden; max-height: 400px; overflow-y: auto; margin-top: 10px; }}
table {{ width: 100%; border-collapse: collapse; font-size: 12.5px; }}
thead th {{ background: #F1F5F9; color: var(--sub); font-weight: 700; text-align: left;
  padding: 8px 11px; border-bottom: 1px solid var(--line); white-space: nowrap; position: sticky; top: 0; z-index: 1; }}
tbody td {{ padding: 7px 11px; border-bottom: 1px solid #F8FAFC; color: #334155; }}
tbody td.highlight {{ font-weight: 700; color: var(--brand); }}
tbody tr:hover {{ background: #F8FAFF; }}
.footer {{ margin-top: 40px; font-size: 12px; color: var(--sub); text-align: center;
  padding-top: 16px; border-top: 1px solid var(--line); }}
.summary-card {{ background: linear-gradient(135deg, var(--brand-soft) 0%, #fff 100%);
  border: 1px solid var(--brand-border); border-radius: 14px; padding: 18px 20px;
  margin-bottom: 14px; }}
.summary-head {{ display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }}
.summary-icon {{ width: 22px; height: 22px; border-radius: 6px; background: var(--brand);
  display: inline-flex; align-items: center; justify-content: center; position: relative; }}
.summary-icon::after {{ content: ""; width: 8px; height: 8px; border-radius: 3px; background: #fff; transform: rotate(45deg); }}
.summary-label {{ font-size: 13px; font-weight: 800; color: var(--brand); }}
.summary-body {{ font-size: 13.5px; line-height: 1.9; color: #334155; }}
.summary-body p {{ margin-bottom: 10px; }}
.summary-body p:last-child {{ margin-bottom: 0; }}
.summary-body strong {{ color: var(--ink); font-weight: 700; }}
@media (max-width: 900px) {{
  .kpis {{ grid-template-columns: repeat(2, 1fr); }}
  .chart-grid-2 {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>
<main class="page">

<header style="margin-bottom:4px">
  <h1>{title}</h1>
  <div class="subtitle">{subtitle}</div>
  <div class="period">{period}</div>
  <div class="badges">{badges_html}</div>
</header>

{summary_html}
<div class="kpis">{kpis_html}</div>

{sections_html}

<footer class="footer">{footer}</footer>

</main>
<script>{g2_js}</script>
<script>
var PAL = {json.dumps(PALETTE, ensure_ascii=False)};

function mk(id, spec) {{
  var el = document.getElementById(id);
  if (!el) return;
  var h = parseInt(el.style.height) || 280;
  var chart = new G2.Chart({{container: id, autoFit: true, height: h}});
  chart.options(spec);
  chart.render().then(function() {{ el.dataset.renderState = 'ready'; }}).catch(function(e) {{ el.dataset.renderState = 'error'; el.textContent = '图表渲染失败：' + e.message; console.error(id, e); }});
}}
</script>
<script>
{charts_js}
</script>
</body>
</html>"""

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(html, encoding="utf-8")
    print(f"✅  {output_path}")


# ── CLI 入口 ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HY Report Skill Renderer")
    parser.add_argument("json_path", help="report_data.json 路径")
    parser.add_argument("--output", default="report.html")
    parser.add_argument("--allow-js-functions", action="store_true", help="Allow reviewed trusted function expressions in specs")
    args = parser.parse_args()
    ALLOW_JS_FUNCTIONS = args.allow_js_functions

    with open(args.json_path, encoding="utf-8") as f:
        data = json.load(f)

    render(data, args.output)
