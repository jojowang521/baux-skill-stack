import unittest, tempfile
from pathlib import Path
import render as r
class RenderTests(unittest.TestCase):
 def test_bold_and_escape(self):
  self.assertEqual(r.paragraphs('**重点** <img>'), '<p><strong>重点</strong> &lt;img&gt;</p>')
 def test_function_opt_in(self):
  with self.assertRaises(ValueError): r.spec_json({'labels':[{'text':'(d) => d.value'}]})
 def test_script_close_escaped(self):
  self.assertNotIn('</script>', r.spec_json({'data':[{'x':'</script><img>'}]}))
 def test_render_nested_path_and_text(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'nested/report.html'
   r.render({'meta':{'title':'<img>'},'sections':[{'type':'text','content':'**ok**'}]},str(path))
   self.assertIn('<title>&lt;img&gt;</title>',path.read_text())
   self.assertIn('<strong>ok</strong>',path.read_text())
 def test_missing_library_errors(self):
  old=r.G2_PATH
  try:
   r.G2_PATH=Path('/nonexistent/baux-g2.js')
   with self.assertRaises(FileNotFoundError):r.render({},'/tmp/unused-hy-report.html')
  finally:r.G2_PATH=old
if __name__=='__main__':unittest.main()
