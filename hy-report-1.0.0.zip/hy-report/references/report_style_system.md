# HY Report Visual System

This reference defines the three primary report themes and the stable page structure used by HY Report Skill v1.0. Read it when generating sales, operations, or growth reports.

## Three Primary Themes

| Business type | Theme name | Brand color | Soft background | Border | Use case |
|---|---|---:|---:|---:|---|
| `sales` | 销售蓝 | `#3569FD` | `#EEF3FF` | `#C7D7FE` | Sales orders, regions, customers, channels, payment risk |
| `ops` | 经营绿 | `#10B981` | `#ECFDF5` | `#A7F3D0` | Revenue, cost, profit, cash, working capital |
| `growth` | 增长橙 | `#F97316` | `#FFF7ED` | `#FED7AA` | Customer growth, retention, ARPC/ARPU, penetration |

Secondary themes remain available only when the user explicitly asks for them: 暮光紫 and 党建红.

## Theme Selection Rules

- If `meta.business_type` is `sales`, use 销售蓝 unless `meta.theme` explicitly overrides it.
- If `meta.business_type` is `ops`, use 经营绿 unless `meta.theme` explicitly overrides it.
- If `meta.business_type` is `growth`, use 增长橙 unless `meta.theme` explicitly overrides it.
- Do not use one blue theme for all reports. The report type should be visually recognizable from the background, badges, KPI values, section numbers, and summary card.
- Keep colors soft. The report should feel like a business analysis document, not a big-screen dashboard.

## Stable Page Structure

Every standard report should follow this order:

1. Header: title, subtitle, period, badges
2. Summary recommendation card: one concise decision-oriented section before KPI cards
3. KPI row: 4-5 cards, calculated from data
4. Analysis sections: charts and chart grids ordered by business logic
5. Supporting table: detailed data at the bottom
6. Footer: data date, method, or generation note

## Shared Layout Tokens

- Page max width: `1280px`
- Page padding: `28px 32px 56px`
- Card radius: `14px`
- Chart wrap radius: `10px`
- KPI grid: five columns on desktop, two on narrow screens
- Section card spacing: `14px`
- Summary card: soft theme gradient from theme soft color to white
- Chart background: soft tinted `#FAFBFF`
- Text color: `#0f172a`, secondary text `#64748b`

## Summary Card Rules

- Summary comes before KPI cards.
- Title should be report-specific: `经营建议`, `经营解读与建议`, or `增长解读与建议`.
- Use 3-4 short paragraphs with bold lead phrases.
- Focus on business judgment and action, not chart descriptions.
- Do not use emoji or decorative symbols. The summary mark is rendered by CSS.

## Report-Specific Section Blueprints

### Sales / 销售蓝

Subtitle pattern: `订单结构 · 品类盈利 · 回款风险全景`

Required order:

1. 月度销售额与毛利率趋势
2. 品类竞争力四象限
3. 区域市场分布与客户贡献
4. 客户 × 品类 销售热力图
5. 渠道结构与执行风险
6. 回款健康度
7. 回款风险明细
8. 销售负责人绩效

### Operations / 经营绿

Subtitle pattern: `利润率改善路径 · 成本结构拆解 · 资金周转效率`

Required order:

1. 季度营收与利润率趋势
2. 成本费用率结构演变
3. 最新季度成本瀑布拆解
4. 汇率走势与汇兑损益
5. 营运资本效率与关键指标改善
6. 核心财务指标明细

### Growth / 增长橙

Subtitle pattern: `客户规模扩张 · 复购深度 · 品类渗透路径`

Required order:

1. 客户规模增长与留存率
2. ARPC 与下单频次
3. TOP 客户季度销售额轨迹
4. 高端款渗透率与客户品类深度
5. 关键增长指标首末对比
6. 增长指标明细

## Visual Quality Rules

- Use at least three chart forms per report.
- Do not repeat KPI numbers inside summary text unless necessary for a conclusion.
- Do not use emoji. Use CSS marks, numbers, badges, and chart encodings.
- Use concise section `desc` values as insights, not chart instructions.
- Keep tables compact and place them after charts.
