---
name: hy-report
description: 将 CSV、Excel 或已整理数据转成面向 B 端业务的数据分析报告，交付内联 AntV G2 的单文件 HTML。覆盖指标口径、业务分析、图表与建议；销售、经营、增长有完整样例，工单与行为有分析参考。适用于完整报告，不用于仅生成图表组件。
metadata:
  version: "1.0.0"
---

# B 端业务数据报告

输入真实数据与分析目标，先核对口径，再计算指标、组织图表与证据，最后输出可离线查看的 HTML。渲染器不读取 Excel，也不自动计算业务指标；这些工作由调用方在组装 JSON 前完成。

## 工作流程

1. 明确报告读者、问题、统计周期与数据来源。检查字段、单位、币种、缺失、重复和异常值。没有实际数据时使用明确标记的样例，不生成真实业务结论。
2. 选取所需业务参考：`references/business_types/sales.md`、`ops.md`、`growth.md`、`ticket.md` 或 `behavior.md`。前三类有完整 demo，后两类是分析框架，不宣称有同等模板验证。
3. 阅读 `references/chart_selection.md` 与 `references/report_style_system.md`，按问题选图。模板中的固定章节、三种图表要求和趋势禁用柱图视为建议；数据不足时省略并说明，不为凑数编造分析。
4. 计算 KPI 与聚合数据，记录来源字段、公式、分母、筛选范围及单位。缺失值不自动补零；分母为零标不可计算；同比/环比只比较相同口径。区分事实、解释假设与建议，不把相关性当因果。
5. 构建 JSON，按需要核对 G2 语法。AntV 文档连接器可用时使用；不可用时可参考随包已核验示例与官方文档。连接器不是渲染依赖，不能保证输出正确。
6. 执行渲染，在浏览器检查图表、文字、数字与窄屏布局。生成文件成功不等于图表成功；查看控制台与图表错误提示。
7. 交付 HTML、报告 JSON、必要的计算口径及实际截图，说明验证范围。按当前工作区保存和链接文件，不依赖固定沙箱路径或特定文件展示工具。

## 渲染入口

需要 Python 3.10+；读取 Excel 时由调用方选用可用解析库。随包 `assets/g2.min.js` 必须保留，报告会将其内联。

```bash
python3 scripts/render.py report_data.json --output output/report.html
python3 scripts/test_render.py
```

默认只接受声明式 JSON。函数型图表配置需要先审阅 JSON 中的 JavaScript 表达式，再显式使用 `--allow-js-functions`；不要为未知来源的数据启用此选项。优先预计算标签字段，避免函数表达式。

## JSON 契约

- `meta`：title、subtitle、period、business_type、theme、generated、badges。业务类型为 sales/ops/growth/ticket/behavior；主题为 auto 或 `references/themes.json` 中的名称。
- `kpis`：label、value、sub、trend、trend_direction。trend_direction 表示变化方向，不代表好坏；成本等逆向指标要在文字中说明。
- `sections`：type 为 summary/chart/chart_grid/table/text；title 与 desc 为纯文本。
- summary/text：content 支持换行与 `**加粗**`，不接受原始 HTML。
- chart：data、g2_spec、height；chart_grid：charts 数组，每项同 chart 并可有 title。
- table：headers、rows，可选 highlight_col。单元格作为文本输出。
- `footer`：来源、截止日期和限制说明。

渲染层生成唯一图表 DOM ID；图表高度限制在 120–1600px。所有指标须在输入 JSON 前核对，渲染器不证明分析结论正确。

## 样例与边界

`demo/*_demo.json`、CSV 与 HTML 是随包样例，不是本站真实经营数据。已有样例包含函数表达式，审阅后可运行：

```bash
python3 scripts/render.py demo/sales_demo.json --output output/sales_report.html --allow-js-functions
```

对 ops、growth 同样操作。截图注明样例数据，实际渲染检查以本次记录为准，不继承原包“已验证”声明。

完整报告分析与叙事由本 Skill 承担；ECharts 图表积木负责可嵌入页面的单图、图表卡与 option。两者使用不同渲染栈，不互相代替。

原包未附独立授权文件，G2 资源保留原始内容；对外分发前补充 Skill 与第三方资源的许可说明。
