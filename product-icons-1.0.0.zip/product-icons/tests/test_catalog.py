import unittest,sys,tempfile,shutil,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import catalog_tool as tool
class CatalogTests(unittest.TestCase):
    def test_inventory(self):
        self.assertEqual(tool.check(),{'ok':True,'assets':38,'semanticMappings':13,'errors':[]})
        self.assertEqual(len(tool.search(style='workbench-unified')),22)
        self.assertEqual(len(tool.search(style='high-saturation')),16)
    def test_semantic_differs_from_asset(self):
        r=tool.resolve('settings','dashboard-shortcut');self.assertEqual(r['asset'],'setting');self.assertEqual(r['projectApproval'],'unknown')
    def test_wrong_surface(self):
        r=tool.resolve('settings','toolbar');self.assertEqual(r['status'],'requires-project-ui-variant');self.assertNotIn('path',r)
    def test_unknown_does_not_fallback(self):
        self.assertEqual(tool.resolve('sales-management','dashboard-shortcut')['status'],'unresolved')
    def test_missing_and_tampered_assets(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp)/'skill';shutil.copytree(tool.ROOT,r)
            p=next((r/'assets/workbench-3d').glob('*.png'));original=p.read_bytes();p.write_bytes(original+b'x')
            self.assertFalse(tool.check(r)['ok']);p.unlink();self.assertFalse(tool.check(r)['ok'])
    def test_read_only_and_safe_paths(self):
        p=tool.ROOT/'catalog/workbench-assets.json';before=p.read_bytes();tool.resolve('product','dashboard-shortcut');tool.search('generic');self.assertEqual(before,p.read_bytes())
        with self.assertRaises(ValueError):tool.safe_path(tool.ROOT,'../../escape.png')
if __name__=='__main__':unittest.main()
