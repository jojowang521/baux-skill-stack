# 项目接入边界

原包描述的依赖包括 `.icon-system/icon-manifest.yaml`、ProductIcon / WorkbenchIcon 组件，以及 `icon:resolve-product`、`icon:resolve-visual`、`icon:install`、`icon:generate`、`icon:workbench:generate`、`icon:check`、`icon:audit` 等 pnpm 脚本。名称仅为原包约定，不保证目标项目存在；先检查 package.json、组件导出与真实命令帮助，按项目实际命令运行。

1. 识别页面区域，记录业务意图与语义名。项目不存在时只输出候选表与缺失依赖。
2. 运行已有 resolver；依其真实返回值区分 approved、needs-review、unresolved，不预设“销售管理”等意图的状态。
3. 原资产目录的 approved 与项目 manifest 的审批状态独立；未知项目状态标记 unknown。
4. 只有映射已获项目允许，才执行该项目安装/生成步骤；外部 provider 的结果同样需要项目治理，不能绕过审批。
5. 业务代码按真实接口使用 ProductIcon 或工作台 WorkbenchIcon。示意 `name="settings"` 不是保证可运行的组件声明。
6. 运行实际存在的生成、类型检查与审计；检查新增/已有页面，报告退出状态。命令缺失时报告未验证，不以本地 catalog 检查替代项目验收。

包内图片在 `assets/workbench-3d`；原包建议项目目标目录为 `src/assets/product-icons/workbench-3d`。这是两个不同路径，不应在本地包中假设已有 src 目录。

示例候选：设置 / dashboard-shortcut / settings / setting / 目录 approved / 项目 unknown。UI 工具栏设置图标需要项目 UI variant，不能拿这张 3D 图片替代。
