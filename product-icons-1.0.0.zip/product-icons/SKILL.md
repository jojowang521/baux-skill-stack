---
name: product-icons
description: 为企业产品选择语义图标、检索本地图标资产并接入已有图标治理流程。适用于工作台快捷入口的 3D 图标、业务语义映射和页面图标一致性检查；不生成新图标，不提供完整项目图标工具链。
metadata:
  version: 1.0.0
---

# Product Icons

将业务意图、展示区域与已有图标资产分开判断。包内含 38 张原始 PNG、两套风格、13 条已有语义映射。

## 输入与交付

输入：业务对象或动作、展示区域、目标风格、现有项目路径（接入时需要）。
输出：语义与资产候选表、可用性/审批状态、引用方式和验证记录；需要演示时附独立 HTML。
缺少展示区域时先识别它；影响选择且无法推断时询问。未知映射、工具兼容性、许可和项目审批状态不得编造。

## 两种使用方式

### 本地资产模式

不需要前端项目。Python 3.9+，仅标准库，从本 Skill 根目录运行：

```sh
python3 scripts/catalog_tool.py check
python3 scripts/catalog_tool.py list --style workbench-unified
python3 scripts/catalog_tool.py list --query report
python3 scripts/catalog_tool.py resolve settings --surface dashboard-shortcut
```

目录以 `catalog/workbench-assets.json` 为唯一可执行来源；其中 `version: 1` 是目录结构版本，Skill 版本为 1.0.0。`status: approved` 沿用原始资产目录状态，不表示目标项目审批通过。
精确解析仅识别 13 个已声明语义名，不是自然语言或 AI 解析器。检索结果只是候选，不能自动新增映射。包内演示入口为 `assets/demo/index.html`。

### 已有项目接入模式

先读 [项目接入](references/project-integration.md)，核对项目清单、组件接口和 package.json 中实际存在的命令。包内没有 resolver、安装器、React 组件或项目审批清单，不得声称可直接完成这套流程。
遵循目标项目现有治理规则；`needs-review` 不得静默安装，`unresolved` 不得伪装为批准结果。任何写入项目清单的变更先呈现具体映射并按该项目流程处理。

## 能力边界与选择规则

- sidebar-navigation、toolbar、table-row-action、system-control、metric-card、status 使用项目的 UI 图标；本包 3D 图标只适用于 dashboard-shortcut。
- 优先按业务语义选择，业务对象与动作分开；指标先找指标/状态语义，再考虑明确的业务对象回退。
- 工作台默认 workbench-unified；high-saturation 独立成组，不在同一区域混用风格。
- `settings` 是语义名，`setting` 是资产键；`customer → contacts`、`order → document` 均为原始映射，不是自动猜测。
- shape-a/shape-b 是通用资产，不得当作所有未知意图的回退；已有 `product → shape-b` 可保留。
- 保留 PNG 原始字节、比例与色彩；禁止裁切、重着色、滤镜、给图标本体叠加阴影或擅自修改原图。
- 项目业务代码优先引用经核实的语义组件，不绕过现有 manifest 直接引入内部生成文件或第三方图标。
- 不生成图标、不搭建整页设计系统、不保证跨工具自动安装，不授予未知的资产许可。

## 验收

运行目录检查与 `python3 -m unittest discover -s tests`。本地检查只证明文件/映射/完整性；目标项目生成、类型检查和审计必须在实际项目另行验证。
交付列出已验证、未验证、待审批项，参考 [验证记录](references/validation.md)。

原包署名：B端AI设计视界 出品；公众号：B端AI设计视界。资产许可未明确，待作者补充。

已知资产问题：home 原图在白色页面上呈现深色矩形底。未经修复确认，不推荐用于浅色工作台；保留原始文件及映射，见验证记录。
