"""Read-only local catalogue utility. Python 3.9+, standard library only."""
import argparse, hashlib, json, struct
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SURFACES = ('dashboard-shortcut','sidebar-navigation','toolbar','table-row-action','system-control','metric-card','status')
def read(root=ROOT):
    return json.loads((root/'catalog/workbench-assets.json').read_text())
def safe_path(root, relative):
    p=(root/relative).resolve()
    if root.resolve() not in p.parents: raise ValueError('Path escapes skill root')
    return p

def check(root=ROOT):
    c=read(root); collection=c['collections']['workbench-3d']; assets=collection['assets']
    hashes=json.loads((root/'catalog/asset-checksums.json').read_text()); errors=[]
    if {a['file'] for a in assets.values()} != set(hashes): errors.append('Checksum inventory mismatch')
    for key,a in assets.items():
        try:
            p=safe_path(root,Path(collection['directory'])/a['file']); b=p.read_bytes()
            if b[:8]!=b'\x89PNG\r\n\x1a\n' or b[12:16]!=b'IHDR': raise ValueError('Invalid PNG header')
            width,height=struct.unpack('>II',b[16:24])
            if not width or not height: raise ValueError('Invalid dimensions')
            if hashlib.sha256(b).hexdigest()!=hashes[a['file']]: raise ValueError('Asset checksum mismatch')
            if a['style'] not in ('workbench-unified','high-saturation'): raise ValueError('Unknown style')
        except (OSError,ValueError,KeyError,struct.error) as e: errors.append(f'{key}: {e}')
    for name,mapping in c['semanticMappings'].items():
        if mapping['asset'] not in assets: errors.append(f'{name}: missing mapped asset')
    return {'ok':not errors,'assets':len(assets),'semanticMappings':len(c['semanticMappings']),'errors':errors}

def resolve(semantic,surface,root=ROOT):
    if surface not in SURFACES: raise ValueError('Unknown surface')
    result={'semantic':semantic,'surface':surface,'projectApproval':'unknown'}
    if surface!='dashboard-shortcut': return dict(result,status='requires-project-ui-variant')
    c=read(root); mapping=c['semanticMappings'].get(semantic)
    if not mapping: return dict(result,status='unresolved')
    col=c['collections']['workbench-3d']; a=col['assets'][mapping['asset']]
    p=safe_path(root,Path(col['directory'])/a['file'])
    return dict(result,status='catalog-mapped',asset=mapping['asset'],style=a['style'],catalogStatus=a['status'],path=str(p.relative_to(root.resolve())))

def search(query='',style=None,root=ROOT):
    assets=read(root)['collections']['workbench-3d']['assets']
    return [dict(asset=k,**a) for k,a in assets.items() if (not style or a['style']==style) and query.casefold() in ' '.join([k,a['category']]+a['searchTerms']).casefold()]

def main():
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('check'); ls=sub.add_parser('list');ls.add_argument('--query',default='');ls.add_argument('--style',choices=['workbench-unified','high-saturation'])
    res=sub.add_parser('resolve');res.add_argument('semantic');res.add_argument('--surface',required=True,choices=SURFACES)
    args=parser.parse_args()
    try:
        result=check() if args.command=='check' else search(args.query,args.style) if args.command=='list' else resolve(args.semantic,args.surface)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 1 if args.command=='check' and not result['ok'] else 0
    except (OSError,ValueError,KeyError) as e:
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));return 1
if __name__=='__main__': raise SystemExit(main())
