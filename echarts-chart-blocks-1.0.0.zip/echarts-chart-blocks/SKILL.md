---
name: echarts-chart-blocks
description: 生成或修改可复用的 ECharts 图表、KPI 卡片和仪表板图表区。适用于 ECharts option、图表 JSON、独立 HTML 区块及 React 图表组件骨架；完整报告或整站任务仅在需要图表子模块时使用。
metadata:
  version: "1.0.0"
---

# ECharts 图表积木

把已有数据转成可嵌入页面的图表资产。标题、单位和必要的数据说明随图表交付，完整业务报告叙事由当前报告任务承接。

## 输入与输出

读取数据、指标单位、展示目标及已有页面约定，再选择输出模式：

| 模式 | 交付 | 实现方式 |
| --- | --- | --- |
| option | ECharts option | 按需生成配置 |
| block-json | 可复用图表 JSON | 按 schema 组织 |
| html-block | 单个 HTML 图表/KPI 卡片 | Python 脚本 |
| html-section | 多个图表区块组成的 HTML | Python 脚本 |
| react-component | React 组件骨架 | 按项目技术栈生成，并说明集成与未验证项 |

Python 脚本只生成 HTML，不是 React 或全部模式的编译器。HTML 自带页面外壳，嵌入已有页面时提取所需区块并复用该页面的 ECharts 实例、样式和资源加载方式。

## 工作方式

1. 需要 JSON 或 HTML 时读 [图表结构](references/chart_block_schema.md)；选型不明确时读 [图表模式](references/chart_patterns.md)。
2. 保留真实数据、单位和来源。仅在用户允许演示数据时使用样例，并在标题或副标题标明；不得把未知数值补成 0。
3. 优先沿用项目主题。无约定时采用原有蓝白卡片样式，主色 `#3569FD`。
4. HTML 使用脚本生成；输入错误按错误路径修正后再运行。空序列、未知指标和无占比总量显示明确空态，不生成假数值。
5. 交付时说明依赖与实际验证范围；存在脚本测试不等于 React 集成、所有宿主或业务正确性都已验证。

```bash
python3 scripts/render_chart_blocks.py references/example_crm_blocks.json --output chart-blocks.html
```

命令在 Skill 目录运行。也可用绝对路径指定脚本和输入输出。需要 Python 3.9+，仅用标准库。HTML 通过 CDN 加载 ECharts 5.4.3，需要网络；此版本为图表库依赖，不是 Skill 版本。资源失败时页面会提示，不宣称离线可用。

## 判断边界

- 数据足够就继续；缺少会改变图表含义的指标、单位或口径时，指出缺口，不自行编造。
- 只有完整报告请求时，先完成报告任务的组织，按需使用此 Skill 生成图表部分。
- React 骨架需要处理容器尺寸、数据更新、resize 和卸载 dispose，并在目标项目验证。
- 局部图表修改只处理受影响区块，保留已有页面结构和无关业务行为。

## 包与验证

- [README](README.md)：使用、依赖、版本来源和未声明的作者/授权信息。
- [CHANGELOG](CHANGELOG.md)：本次轻量修改。
- [验证记录](references/validation-report.md)：脚本和浏览器的实际结果及未覆盖项。
- `tests/test_render.py`：可复现的标准库测试。

`1.0.0` 是本轮统一发布编号。原包未声明 Skill 版本，不据此推断历史成熟度。
