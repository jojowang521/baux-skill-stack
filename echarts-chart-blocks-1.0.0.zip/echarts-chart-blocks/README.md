# ECharts 图表积木 1.0.0

生成可复用图表资产，保留原有 12 种图表类型及 KPI、图表分组。Python 只生成 HTML，其余输出模式由 AI 按任务组织。

## 使用

把完整 echarts-chart-blocks 文件夹放入目标工具支持的 Skill 目录，或向 AI 提供 SKILL.md 与相关资料。目录名保持不变；本包不自动安装，也不修改已有项目。

在本文件所在目录运行：

```bash
python3 scripts/render_chart_blocks.py references/example_crm_blocks.json --output chart-blocks.html
python3 -m unittest discover -s tests -v
```

Python 3.9+，无需第三方 Python 包。HTML 通过 CDN 加载 ECharts 5.4.3，需要网络；不保证离线显示。输入错误退出码为 2，报告字段位置，不覆盖已有输出文件。

原示例为演示数据。合法输入格式保留；过去未知图表类型静默转成折线、缺失数据被默认为零等行为改为校验或空态，请按 schema 修正不合规输入。

## 版本与来源

原包：echarts-chart-blocks.zip，未声明 Skill 版本。本次统一编号 1.0.0，整理日期 2026-10-09。
作者、仓库与 Skill 授权条款：原包未声明，等待维护者补充。本次不新增授权，不把图表库的许可证套用于 Skill。

变化见 CHANGELOG.md；测试范围见 references/validation-report.md。宿主配置文件存在不代表所有 AI 工具均已实测。
