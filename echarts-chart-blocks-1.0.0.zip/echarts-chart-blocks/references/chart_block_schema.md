# Chart Block JSON Schema

## 1.0.0 校验与空数据约定

顶层为对象，blocks 至少一个区块；每个 block.type 必须是 kpi、chart 或 chart-group，图表明确提供支持的 chart.type。未知类型报错。

- 分类图 categories 与每个 series[].data 长度相同，至少一个 series；数据点为有限数值或 null。0 是真实零值，null 是缺失。
- 空分类图使用 categories: [] 与 series: [{"name":"数量","data":[]}]；全 null 也显示空态。
- KPI 必须有 value，可为有限数值、文字或 null。null 显示“暂无数据”，0 正常显示。
- 饼/环图 value 为非负有限数值；空数组显示空态，全部 0 显示没有可展示占比。
- 仪表盘 value 必须明确提供，为 0–100 或 null；这是当前脚本范围，不代表所有业务指标的范围。
- 散点 value 是两个有限数值；热力图整数索引必须在 x/y 标签范围内。
- 同一轴上的 series 使用同一 unit。bar-line 可指定 yAxisIndex 为 0 或 1；默认 line 或 unit 为 % 用右轴，其余用左轴。不自动换算单位。
- height 为 120–1200 的整数像素；颜色支持 #RGB/#RRGGBB；layout 仅支持下面四种值。
- 分组最多嵌套 8 层；未声明的额外字段不参与绘制。

错误输入退出码 2，不写入输出。复杂 ECharts 能力使用 option 模式按需实现，不宣称脚本已支持。

Use this schema when generating reusable chart blocks or rendering HTML with `scripts/render_chart_blocks.py`.

## Top Level

```json
{
  "title": "经营概览",
  "subtitle": "基于本期订单、客户与回款数据",
  "theme": {
    "primary": "#3569FD",
    "palette": ["#3569FD", "#10B981", "#F97316", "#8B5CF6", "#EF4444"]
  },
  "layout": "grid-2",
  "blocks": []
}
```

`layout` values:
- `grid-1`
- `grid-2`
- `grid-3`
- `auto`

## Block Types

### KPI

```json
{
  "type": "kpi",
  "title": "本月销售额",
  "value": "50931.4",
  "unit": "万",
  "delta": "同比 +18.6%",
  "tone": "positive"
}
```

`tone`: `positive` | `negative` | `warning` | `neutral`

### Chart

```json
{
  "type": "chart",
  "title": "月度销售趋势",
  "description": "按订单月份汇总",
  "height": 300,
  "chart": {
    "type": "line",
    "categories": ["1月", "2月", "3月"],
    "series": [
      { "name": "销售额", "data": [3200, 4100, 3900], "unit": "万" }
    ]
  }
}
```

Supported `chart.type`:
- `line`
- `area`
- `bar`
- `horizontal-bar`
- `grouped-bar`
- `stacked-bar`
- `bar-line`
- `pie`
- `doughnut`
- `gauge`
- `scatter`
- `heatmap`

### Chart Group

```json
{
  "type": "chart-group",
  "title": "结构分析",
  "layout": "grid-2",
  "blocks": [
    { "type": "chart", "title": "市场结构", "chart": { "type": "doughnut", "data": [] } },
    { "type": "chart", "title": "客户排行", "chart": { "type": "horizontal-bar", "categories": [], "series": [] } }
  ]
}
```

## Chart Data Patterns

### line / area / bar / horizontal-bar

```json
{
  "type": "line",
  "categories": ["1月", "2月"],
  "series": [
    { "name": "销售额", "data": [120, 180], "unit": "万" }
  ]
}
```

### grouped-bar / stacked-bar

```json
{
  "type": "grouped-bar",
  "categories": ["北美", "欧洲"],
  "series": [
    { "name": "本期", "data": [120, 90], "unit": "万" },
    { "name": "上期", "data": [100, 80], "unit": "万" }
  ]
}
```

### bar-line

```json
{
  "type": "bar-line",
  "categories": ["1月", "2月"],
  "series": [
    { "name": "销售额", "type": "bar", "data": [120, 180], "unit": "万" },
    { "name": "毛利率", "type": "line", "data": [26.2, 28.4], "unit": "%" }
  ]
}
```

### pie / doughnut

```json
{
  "type": "doughnut",
  "data": [
    { "name": "北美", "value": 9623.2 },
    { "name": "欧洲", "value": 5906.9 }
  ],
  "unit": "万"
}
```

### gauge

```json
{
  "type": "gauge",
  "name": "回款率",
  "value": 78,
  "unit": "%"
}
```

### scatter

```json
{
  "type": "scatter",
  "xName": "销售额",
  "yName": "回款率",
  "data": [
    { "name": "客户A", "value": [5906.9, 74.5] }
  ]
}
```

### heatmap

```json
{
  "type": "heatmap",
  "x": ["北美", "欧洲"],
  "y": ["T恤", "夹克"],
  "data": [[0, 0, 120], [1, 0, 90], [0, 1, 60], [1, 1, 110]]
}
```
