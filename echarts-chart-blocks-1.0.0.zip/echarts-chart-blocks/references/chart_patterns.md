# Chart Pattern Guide

Use these patterns to select chart blocks quickly.

## CRM Workbench

- Business summary: KPI row
- Sales trend: line or area
- Key markets: horizontal-bar
- Customer contribution: horizontal-bar or table outside this skill
- Collection rate: gauge
- Risk distribution: doughnut or stacked-bar
- Action workload: stacked-bar

## Sales Analysis

- Monthly sales: line or bar-line
- Market ranking: horizontal-bar
- Product mix: doughnut
- Customer ranking: horizontal-bar
- Sales vs margin: bar-line

## Operations Analysis

- Delivery cycle: line
- Order status: stacked-bar
- Fulfillment health: gauge
- Region/product heat: heatmap
- Efficiency comparison: grouped-bar

## Growth Analysis

- New customer trend: area
- Growth contribution: waterfall-like bar or grouped-bar
- Market opportunity: scatter
- Retention or repurchase: line
- Stage conversion: funnel if available, otherwise horizontal-bar

## Risk Analysis

- Risk level distribution: doughnut
- Risk amount ranking: horizontal-bar
- Amount vs collection rate: scatter
- Aging buckets: stacked-bar
- Risk matrix: heatmap

## Selection Rules

- Use horizontal bars for rankings with long labels.
- Use line/area for time trend.
- Use doughnut only for 3-6 categories.
- Use gauge only for one target-rate metric.
- Use scatter when two numeric dimensions matter.
- Use heatmap for matrix-like cross analysis.
- Avoid pie charts for precise comparisons.
