"""Small, standard-library-only validator for the chart block contract."""
import math
import re

TYPES = {'line', 'area', 'bar', 'horizontal-bar', 'grouped-bar', 'stacked-bar',
         'bar-line', 'pie', 'doughnut', 'gauge', 'scatter', 'heatmap'}
LAYOUTS = {'auto', 'grid-1', 'grid-2', 'grid-3'}


def require(ok, path, message):
    if not ok:
        raise ValueError(f'{path}: {message}')


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def validate_chart(chart, path):
    require(isinstance(chart, dict), path, '必须是对象')
    kind = chart.get('type')
    require(isinstance(kind, str) and kind in TYPES, path + '.type', '不支持或缺少图表类型')
    if kind in {'line', 'area', 'bar', 'horizontal-bar', 'grouped-bar', 'stacked-bar', 'bar-line'}:
        cats, series = chart.get('categories'), chart.get('series')
        require(isinstance(cats, list) and all(isinstance(x, str) or number(x) for x in cats), path + '.categories', '必须是文字/数值数组')
        require(isinstance(series, list) and len(series) > 0, path + '.series', '至少提供一个序列；空图表可使用空 categories 与空 data')
        axis_units = {}
        for i, item in enumerate(series):
            p = f'{path}.series[{i}]'
            require(isinstance(item, dict), p, '必须是对象')
            data = item.get('data')
            require(isinstance(data, list) and len(data) == len(cats), p + '.data', '长度必须与 categories 一致')
            require(all(x is None or number(x) for x in data), p + '.data', '只接受有限数值或 null，不能将缺失值填成 0')
            require(isinstance(item.get('unit', ''), str), p + '.unit', '必须是文字')
            if kind == 'bar-line':
                require(item.get('type', 'bar') in ('bar', 'line'), p + '.type', '只能为 bar 或 line')
                axis = item.get('yAxisIndex', 1 if item.get('unit') == '%' or item.get('type') == 'line' else 0)
                require(type(axis) is int and axis in (0, 1), p + '.yAxisIndex', '只能为整数 0 或 1')
            else:
                axis = 0
            unit = item.get('unit', '')
            require(axis not in axis_units or axis_units[axis] == unit, p + '.unit', '同一坐标轴的单位必须一致；混合单位请用 bar-line 双轴')
            axis_units[axis] = unit
    elif kind in ('pie', 'doughnut', 'scatter'):
        data = chart.get('data')
        require(isinstance(data, list), path + '.data', '必须是数组，可为空')
        for i, item in enumerate(data):
            p = f'{path}.data[{i}]'
            require(isinstance(item, dict), p, '必须是对象')
            value = item.get('value')
            if kind == 'scatter':
                require(isinstance(value, list) and len(value) == 2 and all(number(v) for v in value), p + '.value', '必须是两个有限数值 [x,y]')
            else:
                require(number(value) and value >= 0, p + '.value', '必须是非负有限数值')
    elif kind == 'gauge':
        require('value' in chart, path + '.value', '必须明确提供数值或 null')
        value = chart['value']
        require(value is None or (number(value) and 0 <= value <= 100), path + '.value', '当前仪表盘范围为 0–100；未知请用 null')
    else:
        for axis in ('x', 'y'):
            require(isinstance(chart.get(axis), list) and all(isinstance(x, str) or number(x) for x in chart[axis]), path + '.' + axis, '必须是文字/数值数组')
        require(isinstance(chart.get('data'), list), path + '.data', '必须是数组，可为空')
        for i, row in enumerate(chart['data']):
            p = f'{path}.data[{i}]'
            require(isinstance(row, list) and len(row) == 3, p, '必须是 [x索引,y索引,数值]')
            require(type(row[0]) is int and 0 <= row[0] < len(chart['x']) and type(row[1]) is int and 0 <= row[1] < len(chart['y']), p, '坐标索引超出范围')
            require(number(row[2]), p, '必须提供有限数值')


def validate_blocks(blocks, path='blocks', depth=0):
    require(isinstance(blocks, list) and len(blocks) > 0, path, '至少提供一个区块')
    require(depth <= 8, path, '分组嵌套过深，请简化布局')
    for i, block in enumerate(blocks):
        p = f'{path}[{i}]'
        require(isinstance(block, dict), p, '必须是对象')
        kind = block.get('type')
        require(kind in ('kpi', 'chart', 'chart-group'), p + '.type', '只能为 kpi、chart 或 chart-group')
        if kind == 'kpi':
            require('value' in block, p + '.value', '必须明确提供数值、文字或 null')
            v = block['value']
            require(v is None or isinstance(v, str) or number(v), p + '.value', '必须为有限数值、文字或 null')
            require(block.get('tone', 'neutral') in ('positive', 'negative', 'warning', 'neutral'), p + '.tone', '不支持的状态')
        elif kind == 'chart-group':
            require(isinstance(block.get('layout', 'grid-2'), str) and block.get('layout', 'grid-2') in LAYOUTS, p + '.layout', '不支持的布局')
            validate_blocks(block.get('blocks'), p + '.blocks', depth + 1)
        else:
            h = block.get('height', 300)
            require(type(h) is int and 120 <= h <= 1200, p + '.height', '必须为 120–1200 的整数（像素）')
            validate_chart(block.get('chart'), p + '.chart')


def validate_model(model):
    require(isinstance(model, dict), 'model', '顶层必须是对象')
    layout = model.get('layout', 'auto')
    require(isinstance(layout, str) and layout in LAYOUTS, 'layout', '不支持的布局')
    theme = model.get('theme', {})
    require(isinstance(theme, dict), 'theme', '必须是对象')
    colors = theme.get('palette', ['#3569FD'])
    require(isinstance(colors, list) and len(colors) > 0, 'theme.palette', '必须是非空颜色数组')
    for color in [theme.get('primary', '#3569FD'), *colors]:
        require(isinstance(color, str) and re.fullmatch(r'#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?', color), 'theme', '颜色必须为 #RGB 或 #RRGGBB')
    validate_blocks(model.get('blocks'))


def has_data(chart):
    kind = chart['type']
    if kind == 'gauge':
        return chart['value'] is not None
    if kind in {'line', 'area', 'bar', 'horizontal-bar', 'grouped-bar', 'stacked-bar', 'bar-line'}:
        return any(v is not None for series in chart['series'] for v in series['data'])
    if kind in ('pie', 'doughnut'):
        return any(item['value'] > 0 for item in chart['data'])
    return bool(chart['data'])
