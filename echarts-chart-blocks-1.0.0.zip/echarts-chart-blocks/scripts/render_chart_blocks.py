#!/usr/bin/env python3
import argparse
import html
import json
from pathlib import Path
from model_validation import validate_model, has_data

DEFAULT_PALETTE = ["#3569FD", "#10B981", "#F97316", "#8B5CF6", "#EF4444", "#06B6D4", "#F59E0B", "#64748B"]


def esc(value):
    return html.escape(str("" if value is None else value))


def palette(model):
    theme = model.get("theme") or {}
    return theme.get("palette") or DEFAULT_PALETTE


def primary(model):
    theme = model.get("theme") or {}
    return theme.get("primary") or DEFAULT_PALETTE[0]


def base_option(colors):
    return {
        "color": colors,
        "textStyle": {"fontFamily": "Inter, PingFang SC, Microsoft YaHei, Arial, sans-serif", "color": "#0F172A"},
        "tooltip": {
            "trigger": "axis",
            "renderMode": "richText",
            "backgroundColor": "#FFFFFF",
            "borderColor": "#E2E8F0",
            "borderWidth": 1,
            "textStyle": {"color": "#0F172A", "fontSize": 12},
            "extraCssText": "box-shadow:0 12px 28px rgba(15,23,42,.12);border-radius:8px;"
        },
        "legend": {
            "top": 0,
            "right": 0,
            "itemWidth": 10,
            "itemHeight": 10,
            "textStyle": {"color": "#475569", "fontSize": 12}
        },
        "grid": {"top": 42, "right": 24, "bottom": 28, "left": 12, "containLabel": True}
    }


def axis_common():
    return {
        "axisLine": {"lineStyle": {"color": "#CBD5E1"}},
        "axisTick": {"show": False},
        "axisLabel": {"color": "#475569", "fontSize": 12},
        "splitLine": {"lineStyle": {"color": "#E2E8F0", "type": "dashed"}}
    }


def category_axis(categories):
    axis = axis_common()
    axis.update({"type": "category", "data": categories})
    return axis


def value_axis(name=""):
    axis = axis_common()
    axis.update({"type": "value", "name": name, "nameTextStyle": {"color": "#64748B", "fontSize": 12}})
    return axis


def line_like(chart, colors, area=False):
    opt = base_option(colors)
    opt["xAxis"] = category_axis(chart.get("categories", []))
    opt["yAxis"] = value_axis((chart.get("series") or [{}])[0].get("unit", ""))
    series = []
    for idx, item in enumerate(chart.get("series", [])):
        s = {
            "name": item.get("name", ""),
            "type": "line",
            "smooth": True,
            "symbol": "circle",
            "symbolSize": 6,
            "data": item.get("data", []),
            "lineStyle": {"width": 3},
            "itemStyle": {"borderWidth": 2, "borderColor": "#FFFFFF"}
        }
        if area:
            s["areaStyle"] = {"opacity": 0.14}
            s["symbol"] = "none"
        series.append(s)
    opt["series"] = series
    return opt


def bar_like(chart, colors, horizontal=False, stacked=False):
    opt = base_option(colors)
    categories = chart.get("categories", [])
    unit = (chart.get("series") or [{}])[0].get("unit", "")
    if horizontal:
        opt["xAxis"] = value_axis(unit)
        opt["yAxis"] = category_axis(categories)
        opt["grid"]["left"] = 72
    else:
        opt["xAxis"] = category_axis(categories)
        opt["yAxis"] = value_axis(unit)
    series = []
    for item in chart.get("series", []):
        spec = {
            "name": item.get("name", ""),
            "type": "bar",
            "data": item.get("data", []),
            "barMaxWidth": 28,
            "itemStyle": {"borderRadius": [4, 4, 0, 0]}
        }
        if horizontal:
            spec["itemStyle"] = {"borderRadius": [0, 4, 4, 0]}
        if stacked:
            spec["stack"] = "total"
        series.append(spec)
    opt["series"] = series
    return opt


def bar_line(chart, colors):
    opt = base_option(colors)
    opt["xAxis"] = category_axis(chart.get("categories", []))
    opt["yAxis"] = [value_axis(""), value_axis("")]
    opt["yAxis"][1]["position"] = "right"
    opt["grid"]["right"] = 56
    series = []
    for item in chart.get("series", []):
        chart_type = item.get("type", "bar")
        spec = {
            "name": item.get("name", ""),
            "type": chart_type,
            "data": item.get("data", []),
            "yAxisIndex": item.get("yAxisIndex", 1 if item.get("unit") == "%" or chart_type == "line" else 0)
        }
        opt["yAxis"][spec["yAxisIndex"]]["name"] = item.get("unit", "")
        if chart_type == "bar":
            spec["barMaxWidth"] = 28
            spec["itemStyle"] = {"borderRadius": [4, 4, 0, 0]}
        else:
            spec["smooth"] = True
            spec["symbol"] = "circle"
            spec["symbolSize"] = 6
            spec["lineStyle"] = {"width": 3}
        series.append(spec)
    opt["series"] = series
    return opt


def pie_like(chart, colors, doughnut=False):
    opt = base_option(colors)
    opt["tooltip"]["trigger"] = "item"
    opt["tooltip"]["formatter"] = "{b}: {c} ({d}%)"
    opt["legend"] = {
        "orient": "vertical",
        "right": 8,
        "top": "center",
        "itemWidth": 10,
        "itemHeight": 10,
        "textStyle": {"color": "#475569", "fontSize": 12}
    }
    opt["series"] = [{
        "type": "pie",
        "radius": ["46%", "70%"] if doughnut else "68%",
        "center": ["40%", "52%"],
        "data": chart.get("data", []),
        "label": {"show": False},
        "itemStyle": {"borderColor": "#FFFFFF", "borderWidth": 2, "borderRadius": 4}
    }]
    return opt


def gauge(chart, colors):
    opt = base_option(colors)
    opt["tooltip"]["trigger"] = "item"
    opt["series"] = [{
        "type": "gauge",
        "startAngle": 210,
        "endAngle": -30,
        "min": 0,
        "max": 100,
        "progress": {"show": True, "width": 14},
        "axisLine": {"lineStyle": {"width": 14, "color": [[1, "#E2E8F0"]]}},
        "axisTick": {"show": False},
        "splitLine": {"show": False},
        "axisLabel": {"show": False},
        "pointer": {"show": False},
        "detail": {"valueAnimation": True, "fontSize": 28, "fontWeight": 700, "formatter": "{value}" + chart.get("unit", "")},
        "data": [{"name": chart.get("name", ""), "value": chart.get("value", 0)}]
    }]
    return opt


def scatter(chart, colors):
    opt = base_option(colors)
    opt["xAxis"] = value_axis(chart.get("xName", "X"))
    opt["yAxis"] = value_axis(chart.get("yName", "Y"))
    opt["series"] = [{
        "type": "scatter",
        "symbolSize": 14,
        "data": [{"name": item.get("name", ""), "value": item.get("value", [])} for item in chart.get("data", [])]
    }]
    return opt


def heatmap(chart, colors):
    opt = base_option(colors)
    opt["tooltip"]["position"] = "top"
    opt["grid"] = {"top": 42, "right": 18, "bottom": 80, "left": 54}
    opt["xAxis"] = {"type": "category", "data": chart.get("x", []), "splitArea": {"show": True}, "axisLabel": {"color": "#475569"}}
    opt["yAxis"] = {"type": "category", "data": chart.get("y", []), "splitArea": {"show": True}, "axisLabel": {"color": "#475569"}}
    values = [row[2] for row in chart.get("data", [])] or [0]
    opt["visualMap"] = {"min": min(values), "max": max(values), "calculable": True, "orient": "horizontal", "left": "center", "bottom": 0}
    opt["series"] = [{"type": "heatmap", "data": chart.get("data", []), "label": {"show": False}, "emphasis": {"itemStyle": {"shadowBlur": 8, "shadowColor": "rgba(15,23,42,.18)"}}}]
    return opt


def chart_option(chart, colors):
    t = chart.get("type", "line")
    if t == "line":
        return line_like(chart, colors)
    if t == "area":
        return line_like(chart, colors, area=True)
    if t == "bar":
        return bar_like(chart, colors)
    if t == "horizontal-bar":
        return bar_like(chart, colors, horizontal=True)
    if t == "grouped-bar":
        return bar_like(chart, colors)
    if t == "stacked-bar":
        return bar_like(chart, colors, stacked=True)
    if t == "bar-line":
        return bar_line(chart, colors)
    if t == "pie":
        return pie_like(chart, colors)
    if t == "doughnut":
        return pie_like(chart, colors, doughnut=True)
    if t == "gauge":
        return gauge(chart, colors)
    if t == "scatter":
        return scatter(chart, colors)
    if t == "heatmap":
        return heatmap(chart, colors)
    raise ValueError(f"不支持的图表类型: {t}")


def render_kpi(block):
    tone = block.get("tone", "neutral")
    return f"""
<article class="kpi-card tone-{esc(tone)}">
  <div class="kpi-title">{esc(block.get("title"))}</div>
  <div class="kpi-value"><span>{esc(block.get("value") if block.get("value") is not None else '暂无数据')}</span>{f'<em>{esc(block.get("unit"))}</em>' if block.get("unit") else ''}</div>
  <div class="kpi-delta">{esc(block.get("delta"))}</div>
</article>
"""


def render_chart(block, idx, colors, charts):
    chart_id = f"chart_{idx}"
    available = has_data(block['chart'])
    if available:
        charts.append({"id": chart_id, "option": chart_option(block['chart'], colors)})
    state = 'loading' if available else 'empty'
    message = '正在加载图表…' if available else ('暂无可展示占比（总量为 0）' if block['chart']['type'] in ('pie', 'doughnut') and block['chart']['data'] else '暂无数据')
    desc = f'<p class="card-desc">{esc(block.get("description"))}</p>' if block.get("description") else ""
    height = int(block.get("height", 300))
    return f"""
<article class="chart-card">
  <div class="card-head">
    <h3>{esc(block.get("title"))}</h3>
    {desc}
  </div>
  <div id="{chart_id}" class="chart" data-chart-state="{state}" style="height:{height}px"><p role="status">{message}</p></div>
</article>
"""


def render_blocks(blocks, layout, colors, charts, counter):
    cls = "blocks " + (layout or "auto")
    parts = [f'<section class="{cls}">']
    for block in blocks:
        counter[0] += 1
        if block.get("type") == "kpi":
            parts.append(render_kpi(block))
        elif block.get("type") == "chart-group":
            parts.append(f'<section class="group-card"><h2>{esc(block.get("title"))}</h2>')
            parts.append(render_blocks(block.get("blocks", []), block.get("layout", "grid-2"), colors, charts, counter))
            parts.append("</section>")
        else:
            parts.append(render_chart(block, counter[0], colors, charts))
    parts.append("</section>")
    return "\n".join(parts)


def build_html(model):
    validate_model(model)
    colors = palette(model)
    charts = []
    counter = [0]
    content = render_blocks(model.get("blocks", []), model.get("layout", "auto"), colors, charts, counter)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{esc(model.get("title", "ECharts Chart Blocks"))}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.4.3/echarts.min.js"></script>
<style>
:root {{
  --primary: {primary(model)};
  --bg: #F5F7FB;
  --card: #FFFFFF;
  --text: #0F172A;
  --muted: #64748B;
  --border: #E2E8F0;
}}
* {{ box-sizing: border-box; }}
body {{
  margin: 0;
  font-family: Inter, "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
  background: var(--bg);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
}}
.shell {{
  max-width: 1280px;
  margin: 0 auto;
  padding: 28px;
}}
.page-head {{
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 20px;
}}
h1 {{
  margin: 0;
  font-size: 26px;
  line-height: 34px;
  letter-spacing: 0;
}}
.subtitle {{
  margin: 6px 0 0;
  color: var(--muted);
  font-size: 14px;
}}
.blocks {{
  display: grid;
  gap: 16px;
}}
.blocks.auto {{ grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }}
.blocks.grid-1 {{ grid-template-columns: 1fr; }}
.blocks.grid-2 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
.blocks.grid-3 {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
.kpi-card, .chart-card, .group-card {{
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  box-shadow: 0 10px 28px rgba(15, 23, 42, .05);
}}
.kpi-card {{
  min-height: 126px;
  padding: 18px;
  position: relative;
  overflow: hidden;
}}
.kpi-card::after {{
  content: "";
  position: absolute;
  inset: auto -30px -42px auto;
  width: 120px;
  height: 120px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--primary) 12%, white);
}}
.kpi-title {{
  color: var(--muted);
  font-size: 14px;
  font-weight: 600;
}}
.kpi-value {{
  margin-top: 14px;
  display: flex;
  align-items: flex-end;
  gap: 5px;
}}
.kpi-value span {{
  font-size: 30px;
  line-height: 34px;
  font-weight: 800;
  letter-spacing: 0;
}}
.kpi-value em {{
  font-style: normal;
  font-size: 12px;
  color: var(--muted);
  transform: translateY(-3px);
}}
.kpi-delta {{
  margin-top: 10px;
  font-size: 13px;
  color: var(--muted);
}}
.tone-positive .kpi-delta {{ color: #047857; }}
.tone-negative .kpi-delta {{ color: #BE123C; }}
.tone-warning .kpi-delta {{ color: #C2410C; }}
.chart-card {{
  padding: 18px;
  min-width: 0;
}}
.card-head {{
  margin-bottom: 8px;
}}
.card-head h3, .group-card h2 {{
  margin: 0;
  font-size: 16px;
  line-height: 24px;
  font-weight: 750;
  letter-spacing: 0;
}}
.card-desc {{
  margin: 4px 0 0;
  color: var(--muted);
  font-size: 12px;
  line-height: 18px;
}}
.chart {{
  width: 100%;
}}
.group-card {{
  padding: 18px;
}}
.group-card > h2 {{
  margin-bottom: 14px;
}}
@media (max-width: 860px) {{
  .shell {{ padding: 18px; }}
  .blocks.grid-2, .blocks.grid-3 {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>
<main class="shell">
  <header class="page-head">
    <div>
      <h1>{esc(model.get("title", "ECharts Chart Blocks"))}</h1>
      <p class="subtitle">{esc(model.get("subtitle", ""))}</p>
    </div>
  </header>
  {content}
</main>
<script>
const CHARTS = {json.dumps(charts, ensure_ascii=False, allow_nan=False).replace('<', chr(92) + 'u003c').replace('>', chr(92) + 'u003e').replace('&', chr(92) + 'u0026')};
window.addEventListener("DOMContentLoaded", () => {{
  CHARTS.forEach((cfg) => {{
    const el = document.getElementById(cfg.id);
    if (!el) return;
    if (!window.echarts) {{
      el.dataset.chartState = 'error';
      el.textContent = '图表资源未能加载，请检查网络后刷新。';
      return;
    }}
    try {{
      el.textContent = '';
      const chart = echarts.init(el, null, {{ renderer: "canvas" }});
      chart.setOption(cfg.option);
      el.dataset.chartState = 'ready';
      window.addEventListener("resize", () => chart.resize());
    }} catch (error) {{
      el.dataset.chartState = 'error';
      el.textContent = '图表显示失败，请检查数据与图表配置。';
      console.error(error);
    }}
  }});
}});
</script>
</body>
</html>
"""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        model = json.loads(Path(args.input).read_text(encoding="utf-8"))
        rendered = build_html(model)
        Path(args.output).write_text(rendered, encoding="utf-8")
    except (OSError, ValueError, TypeError, OverflowError, RecursionError) as error:
        parser.exit(2, f"生成失败：{error}\n")
    print(args.output)


if __name__ == "__main__":
    main()
