import copy
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from render_chart_blocks import build_html


def model(chart):
    return {'blocks': [{'type': 'chart', 'title': '测试图表', 'chart': chart}]}


def line(kind='line'):
    return {'type': kind, 'categories': ['A', 'B'], 'series': [{'name': '金额', 'unit': '元', 'data': [0, 20]}]}


def options(html):
    return json.loads(re.search(r'const CHARTS = (.*);', html).group(1))


class RenderTests(unittest.TestCase):
    def test_original_sample_data_preserved(self):
        source = json.loads((ROOT / 'references/example_crm_blocks.json').read_text())
        text = build_html(source)
        actual = options(text)
        self.assertEqual(len(actual), 3)
        self.assertEqual(actual[0]['option']['series'][0]['data'], source['blocks'][3]['chart']['series'][0]['data'])
        self.assertEqual(actual[2]['option']['series'][0]['data'][0]['value'], 78)
        self.assertIn('演示数据', text)

    def test_all_twelve_types_preserve_numeric_data(self):
        charts = [line(t) for t in ['line', 'area', 'bar', 'horizontal-bar', 'grouped-bar', 'stacked-bar', 'bar-line']]
        charts += [{'type': t, 'data': [{'name': 'A', 'value': 20}]} for t in ['pie', 'doughnut']]
        charts += [{'type': 'gauge', 'value': 0}, {'type': 'scatter', 'data': [{'name': 'A', 'value': [0, 20]}]}, {'type': 'heatmap', 'x': ['A'], 'y': ['B'], 'data': [[0, 0, 20]]}]
        for chart in charts:
            with self.subTest(kind=chart['type']):
                result = options(build_html(model(chart)))
                self.assertEqual(len(result), 1)
                self.assertTrue(result[0]['option']['series'])

    def test_zero_and_missing_kpi_are_distinct(self):
        text = build_html({'blocks': [{'type': 'kpi', 'value': 0}, {'type': 'kpi', 'value': None}]})
        self.assertIn('<span>0</span>', text)
        self.assertIn('<span>暂无数据</span>', text)

    def test_empty_all_null_and_zero_share(self):
        charts = [{'type': 'line', 'categories': [], 'series': [{'data': []}]}, {'type': 'line', 'categories': ['A'], 'series': [{'data': [None]}]}, {'type': 'gauge', 'value': None}, {'type': 'pie', 'data': []}, {'type': 'pie', 'data': [{'value': 0}]}]
        for chart in charts:
            with self.subTest(chart=chart):
                text = build_html(model(chart))
                self.assertEqual(options(text), [])
                self.assertIn('data-chart-state="empty"', text)

    def test_gaps_not_imputed(self):
        chart = line()
        chart['series'][0]['data'] = [0, None]
        self.assertEqual(options(build_html(model(chart)))[0]['option']['series'][0]['data'], [0, None])

    def test_dual_axis_unit_and_assignment(self):
        chart = line('bar-line')
        chart['series'].append({'name': '利润率', 'type': 'line', 'data': [12, 14], 'unit': '%', 'yAxisIndex': 1})
        opt = options(build_html(model(chart)))[0]['option']
        self.assertEqual([s['yAxisIndex'] for s in opt['series']], [0, 1])
        self.assertEqual([a['name'] for a in opt['yAxis']], ['元', '%'])

    def test_invalid_inputs_rejected(self):
        bad = [None, {'blocks': []}, {'blocks': [{'type': 'unknown'}]}, model({'type': 'unknown'}), model({'type': 'gauge'}), model({'type': 'gauge', 'value': -1}), model({'type': 'pie', 'data': [{'value': -1}]}), model({'type': 'scatter', 'data': [{'value': [1]}]}), model({'type': 'heatmap', 'x': ['A'], 'y': ['B'], 'data': [[1, 0, 5]]})]
        for value in [True, float('nan'), float('inf'), '12']:
            chart = line()
            chart['series'][0]['data'][0] = value
            bad.append(model(chart))
        wrong_length = line()
        wrong_length['series'][0]['data'] = [1]
        bad.append(model(wrong_length))
        for extra in [{'layout': 'grid-9'}, {'theme': {'primary': 'red;display:none'}}, {'theme': {'palette': []}}]:
            bad.append({**model(line()), **extra})
        for item in bad:
            with self.subTest(item=item):
                with self.assertRaises(ValueError):
                    build_html(item)

    def test_mixed_units_same_axis_rejected(self):
        chart = line()
        chart['series'].append({'name': '比例', 'data': [10, 20], 'unit': '%'})
        with self.assertRaisesRegex(ValueError, '单位'):
            build_html(model(chart))

    def test_data_cannot_close_inline_script(self):
        chart = line()
        chart['categories'][0] = '</script><img src=x onerror=alert(1)>'
        text = build_html(model(chart))
        self.assertNotIn('</script><img', text)
        self.assertEqual(options(text)[0]['option']['xAxis']['data'][0], chart['categories'][0])
        self.assertEqual(options(text)[0]['option']['tooltip']['renderMode'], 'richText')

    def test_nested_group(self):
        text = build_html({'blocks': [{'type': 'chart-group', 'blocks': [{'type': 'kpi', 'value': 0}, model(line())['blocks'][0]]}]})
        self.assertEqual(len(options(text)), 1)
        self.assertIn('<span>0</span>', text)

    def test_cli_failure_preserves_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            src, dst = Path(tmp) / 'bad.json', Path(tmp) / 'out.html'
            dst.write_text('keep existing')
            for value in ['{', json.dumps(model({'type': 'invalid'}))]:
                src.write_text(value)
                result = subprocess.run([sys.executable, str(ROOT / 'scripts/render_chart_blocks.py'), str(src), '--output', str(dst)], capture_output=True, text=True)
                self.assertEqual(result.returncode, 2)
                self.assertIn('生成失败', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(dst.read_text(), 'keep existing')


if __name__ == '__main__':
    unittest.main()
