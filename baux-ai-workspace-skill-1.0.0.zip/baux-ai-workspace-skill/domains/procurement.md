# 业务域：采购管理

> **文档版本**：1.0.0（随 Skill 1.0.0 整理，原稿 2026-09）
> **定位**：采购业务示例，不是用户公司的已确认制度。  
> **适用范围**：采购订单管理、供应商管理、框架协议管理  
> **Skill 引用**：本文件配合 `prompts/generate-prd.md` 使用，在生成采购类页面的 PRD 时自动补填 §4 字段定义、§5 状态枚举、§6 权限与隔离 等章节。

---

## 一、业务对象总览

采购管理域包含三个核心业务对象：

| 对象 | 英文 Key | 说明 |
|---|---|---|
| **采购订单** | `PurchaseOrder` | 主实体；记录一次采购行为的全生命周期 |
| **供应商** | `Supplier` | 关联方；提供商品或服务的外部主体 |
| **框架协议** | `FrameworkAgreement` | 约束方；规定特定类别的采购上限与条款 |

三者关系：

```
采购订单  →  (N:1)  →  供应商
采购订单  →  (N:1)  →  框架协议（可选）
框架协议  →  (1:N)  →  采购订单
```

---

## 二、采购订单字段字典

### 核心字段

| 字段名 | Key | 类型 | 说明 | 约束 |
|---|---|---|---|---|
| 订单编号 | `po_number` | String | 格式 `PO-YYYYMM-NNNN`，系统自动生成 | 不可编辑；提交后唯一 |
| 供应商 | `supplier_id` / `supplier_name` | Ref / String | 从供应商库选择 | 必填；提交后锁定 |
| 采购类别 | `category` | Enum | 见下方 `category` 枚举表 | 必填 |
| 采购金额 | `amount` | Number | 人民币（元），精确到分 | 必填；> 0 |
| 含税标志 | `tax_included` | Boolean | true = 含税，false = 不含税 | 默认 true |
| 状态 | `status` | Enum | 见下方 `status` 枚举表 | 系统维护 |
| 申请人 | `applicant_id` | Ref(User) | 自动取登录用户 | 不可编辑 |
| 申请日期 | `apply_date` | Date | 提交时系统写入 | 不可编辑 |
| 关联框架协议 | `agreement_id` | Ref(FrameworkAgreement) | 可选；AI 辅助推荐 | 可空 |
| 用途说明 | `description` | Text | 自由文本，≤ 500 字 | 必填 |
| AI 风险标记 | `ai_flag` | Boolean | AI 检测到风险时标记为 true | 系统维护；不可手动编辑 |
| AI 风险说明 | `ai_risk_reason` | String | AI 给出的风险描述 | 系统维护 |
| 审批人 | `approver_id` | Ref(User) | 审批动作发生时写入 | 系统维护 |
| 审批时间 | `approved_at` | DateTime | 审批动作完成时写入 | 系统维护 |
| 驳回原因 | `reject_reason` | Text | 驳回时审批人填写 | 驳回时必填 |
| 创建时间 | `created_at` | DateTime | 系统自动 | 不可编辑 |
| 更新时间 | `updated_at` | DateTime | 系统自动 | 不可编辑 |

### `category` 枚举（采购类别）

| 枚举值 | 显示文字 | 说明 |
|---|---|---|
| `office_supplies` | 办公耗材 | 文具、纸张、耗材类 |
| `equipment` | 设备采购 | IT 设备、办公设备、生产设备 |
| `software` | 软件服务 | SaaS/License/云服务 |
| `facility` | 设施维保 | 装修、维修、物业类 |
| `marketing` | 市场推广 | 广告、活动、设计外包 |
| `travel` | 差旅服务 | 机票、酒店、租车（对公） |
| `consulting` | 咨询服务 | 法律、财务、管理咨询 |
| `other` | 其他 | 不归入以上类别时使用 |

**边界待确认**：原稿此处写“超过 ¥5,000”，§六写“≥ ¥5,000”。示例暂按 §六的 ≥ 表达；真实业务必须确认等于阈值时的行为，不能当作已确认制度。

---

## 三、状态枚举（采购订单生命周期）

```
草稿 ──→ 待审批 ──→ 已完成
  ↑               ↘
  └─── 已驳回 ←───┘
```

| 状态 | `status` 值 | 语义色 | Badge 样式 | 可触发的操作 |
|---|---|---|---|---|
| 草稿 | `draft` | `--color-neutral` (灰) | badge-draft | 编辑、提交审批、删除 |
| 待审批 | `pending` | `--color-warning` (橙) | badge-pending | 撤回（申请人）、审批通过、驳回（审批人） |
| 已完成 | `completed` | `--color-success` (绿) | badge-done | 查看、导出 |
| 已驳回 | `rejected` | `--color-danger` (红) | badge-rejected | 查看、复制为草稿 |

**状态流转规则**：
- `draft` → `pending`：申请人点击"提交审批"；系统校验必填字段全部填写
- `pending` → `draft`：申请人点击"撤回"；仅限 `pending` 且审批人未开始审批
- `pending` → `completed`：审批人点击"审批通过"；**Irreversible 操作**
- `pending` → `rejected`：审批人点击"驳回"；需填写 `reject_reason`；**Irreversible 操作**
- `rejected` → `draft`：系统复制一条新草稿（不修改原记录）

---

## 四、角色与操作矩阵

### 角色定义

| 角色 | `role` 值 | 数据范围 | 说明 |
|---|---|---|---|
| 采购专员 | `procurement_staff` | 本人提交的订单 | 发起、编辑自己的订单 |
| 采购主管 | `procurement_manager` | 所在部门全量订单 | 审批权限；可查看下属全部订单 |
| 财务管理员 | `finance_admin` | 全公司只读 | 用于对账和导出；无审批权 |
| 系统管理员 | `sys_admin` | 全公司全权限 | 维护供应商库、框架协议、配置阈值 |

### 操作权限矩阵

| 操作 | 采购专员 | 采购主管 | 财务管理员 | 系统管理员 |
|---|---|---|---|---|
| 查看列表（本人） | ✅ | ✅ | ✅ | ✅ |
| 查看列表（部门） | ❌ | ✅ | ✅ | ✅ |
| 新增订单 | ✅ | ✅ | ❌ | ✅ |
| 编辑草稿 | ✅（本人） | ✅（本人） | ❌ | ✅ |
| 提交审批 | ✅（本人） | ✅（本人） | ❌ | ✅ |
| 撤回待审批 | ✅（本人） | ✅（本人） | ❌ | ✅ |
| 审批通过 | ❌ | ✅ | ❌ | ✅ |
| 驳回 | ❌ | ✅ | ❌ | ✅ |
| 删除草稿 | ✅（本人） | ✅（部门） | ❌ | ✅ |
| 导出 | ✅（本人） | ✅（部门） | ✅（全量） | ✅ |
| 维护供应商库 | ❌ | ❌ | ❌ | ✅ |
| 维护框架协议 | ❌ | ✅ | ❌ | ✅ |
| 配置 AI 阈值 | ❌ | ❌ | ❌ | ✅ |

**权限渲染规则**（遵守 `principles/ai-trust.md` + `patterns/customer-list-page.md`）：
- **隐藏优于禁用**：无权限的操作按钮直接隐藏
- 按上方示例权限矩阵，审批操作可对 `procurement_manager` 与 `sys_admin` 显示；管理员是否应有审批业务权属于项目待确认规则
- 行级权限：采购专员只看到自己的行，无权限的行不渲染（不显示"无权限"占位）

---

## 五、业务操作清单与 Human Review 级别

基于 `principles/ai-trust.md` §Human Review 三级分类：

| 操作 | 操作主体 | Review 级别 | 机制 | 按钮文字 |
|---|---|---|---|---|
| 查看订单列表 | 任意角色 | Read | 无 | — |
| 查看订单详情 | 任意角色 | Read | 无 | — |
| 新增草稿 | 申请人 | Reversible | Toast + 10s 撤销 | "保存草稿" |
| 编辑草稿 | 申请人 | Reversible | Toast + 10s 撤销 | "保存修改" |
| 提交审批 | 申请人 | Reversible | Toast + 10s 撤销 | "提交审批" |
| 撤回待审批 | 申请人 | Reversible | Toast + 10s 撤销 | "撤回" |
| 审批通过 | 审批人 | **Irreversible** | Confirm Dialog | "**确认审批通过**" |
| 驳回 | 审批人 | **Irreversible** | Confirm Dialog（含原因输入框） | "**确认驳回**" |
| 删除草稿 | 申请人/主管 | **Irreversible** | Confirm Dialog | "**确认删除**" |
| 导出 | 有权限角色 | Read | 无（直接下载） | "导出" |
| 批量导出 | 有权限角色 | Reversible | Toast（提示导出任务已加入队列） | "批量导出" |
| 创建框架协议申请 | 主管 | Reversible | Toast + 10s 撤销 | "创建协议申请" |

### Confirm Dialog 模板（审批通过）

```
┌─────────────────────────────────────┐
│  确认审批通过？                      │
│                                     │
│  订单：PO-202409-0032               │
│  供应商：北京鑫达办公用品有限公司    │
│  金额：¥ 12,800.00（含税）          │
│  申请人：王小明                     │
│                                     │
│  审批通过后不可撤销，订单将直接进入  │
│  已完成状态并通知供应商。            │
│                                     │
│       [取消]  [确认审批通过]        │
└─────────────────────────────────────┘
```

### Confirm Dialog 模板（驳回）

```
┌─────────────────────────────────────┐
│  驳回此采购订单？                   │
│                                     │
│  订单：PO-202409-0032               │
│                                     │
│  驳回原因（必填）：                 │
│  [                              ]   │
│  [                              ]   │
│                                     │
│  驳回后申请人将收到通知，可重新提交。│
│                                     │
│       [取消]  [确认驳回]            │
└─────────────────────────────────────┘
```

---

## 六、业务隔离规则

1. **数据隔离**：采购专员只能看到自己提交的订单；采购主管只能看到所在部门的订单。跨部门数据通过财务管理员角色统一处理，不开放给业务人员。

2. **金额阈值**：
   - `amount` < ¥ 5,000：无需额外审批层级
   - ¥ 5,000 ≤ `amount` < ¥ 50,000：需 `procurement_manager` 审批
   - `amount` ≥ ¥ 50,000：需 `procurement_manager` 审批 + 财务复核（流程另行配置）

3. **类别约束**：
   - `travel` 类别必须在提交前上传出行单据附件
   - `consulting` 类别金额 ≥ ¥ 10,000 时需关联合同附件
   - `other` 类别金额 ≥ ¥ 5,000 时触发 AI 风险标记

4. **框架协议约束**：
   - 选择的 `agreement_id` 须处于有效期内
   - 关联协议后，`amount` 不能超过该协议的剩余可用额度
   - 超额时系统阻止提交并提示"已超协议剩余额度 ¥ X"

5. **供应商约束**：
   - 只能选择状态为 `active` 的供应商
   - 已列入黑名单（`status: blacklisted`）的供应商选择时系统弹出阻断提示

---

## 七、AI 能力边界（采购域）

AI Copilot 在采购管理页可以提供以下能力（均需遵守 `principles/ai-trust.md` 三原则）：

### AI 可以做的（Read 级，无需 Human Review）

| AI 能力 | 触发条件 | Citation 来源 | Confidence |
|---|---|---|---|
| 检测超阈值异常 | `amount` 超过历史同类订单均值 2 倍 | 采购历史记录 | 中 🔍 |
| 推荐框架协议 | 提交时匹配 `category` + `supplier_id` | 框架协议库 | 高（无标记）|
| 识别沉默供应商 | 某供应商 90 天内无新订单 | 订单历史 | 高 |
| 检测重复采购风险 | 30 天内同供应商同类别 ≥ 3 笔 | 订单历史 | 中 🔍 |
| 预测审批周期 | 基于历史同类型审批时长 | 审批记录 | 低 ⚠️ |

### AI 辅助后需 Human Review 的操作

| AI 建议的操作 | Review 级别 | 触发机制 |
|---|---|---|
| 为高风险订单创建跟进任务 | Reversible | Toast + 10s 撤销 |
| 建议创建框架协议申请 | Reversible | Toast + 10s 撤销 |
| 批量标记异常订单 | Reversible | Toast + 10s 撤销 |
| AI 建议驳回某订单 | **Irreversible** | Confirm Dialog（审批人确认） |

### AI 不能做的（硬边界）

- ❌ AI **不能代替审批人**执行"审批通过"或"驳回"操作
- ❌ AI **不能修改** `amount`、`supplier_id` 等核心字段
- ❌ AI **不能直接发送**通知给外部供应商
- ❌ AI **不能绕过**框架协议额度约束自行填写 `agreement_id`
- ❌ AI **建议的驳回理由**必须由审批人手动确认后才能写入 `reject_reason`

### AI 风险标记（`ai_flag`）展示规则

```
表格行高亮：border-left: 3px solid var(--ai-purple)
行内 Badge：⚠️ AI 风险  (bg: --ai-surface, color: --ai-purple)
Citation：📄 采购历史记录 · 风险分析模块
Confidence：中 🔍（"根据历史数据推断"）
```

---

## 八、供应商对象字段字典（辅助）

| 字段名 | Key | 类型 | 说明 |
|---|---|---|---|
| 供应商编号 | `supplier_code` | String | `SUP-NNNN`，系统生成 |
| 供应商名称 | `supplier_name` | String | 营业执照名称 |
| 简称 | `supplier_short_name` | String | 用于列表显示 |
| 联系人 | `contact_name` | String | 主要对接人 |
| 联系电话 | `contact_phone` | String | — |
| 状态 | `status` | Enum | `active` / `inactive` / `blacklisted` |
| 合作类别 | `categories` | Array\<Enum\> | 供应该供应商可服务的类别 |
| 入库日期 | `onboard_date` | Date | 首次入库时间 |

---

## 九、框架协议对象字段字典（辅助）

| 字段名 | Key | 类型 | 说明 |
|---|---|---|---|
| 协议编号 | `agreement_code` | String | `FA-YYYYMM-NNN`，系统生成 |
| 协议名称 | `agreement_name` | String | 自由文本 |
| 关联供应商 | `supplier_id` | Ref | — |
| 适用类别 | `category` | Enum | 同 `PurchaseOrder.category` |
| 协议总额 | `total_amount` | Number | 协议期内可用总额度 |
| 已用额度 | `used_amount` | Number | 系统累计 | 
| 剩余额度 | `remaining_amount` | Number | `total_amount - used_amount`，只读 |
| 生效日期 | `start_date` | Date | — |
| 到期日期 | `end_date` | Date | — |
| 状态 | `status` | Enum | `active` / `expired` / `terminated` |

---

## 十、与 Skill 其他文件的衔接

| 场景 | 读取文件 |
|---|---|
| 采购类页面原型生成 | 本文件 + `patterns/customer-list-page.md` + `patterns/ai-copilot-sidebar.md` |
| 采购域 PRD 生成 | 本文件 + `prompts/generate-prd.md` + `templates/prd-template.md` |
| AI Trust 合规审查 | 本文件（§七 AI 能力边界）+ `principles/ai-trust.md` |
| 状态枚举 Badge 渲染 | 本文件（§三）+ `foundations/design-tokens.md` |
| 权限控制渲染 | 本文件（§四）+ `patterns/customer-list-page.md` §权限对界面的影响 |

---

> **维护说明**：本文件由产品团队维护，每次业务规则变更后同步更新。AI 生成页面时，§二字段字典和§三状态枚举为主要引用源，§七 AI 能力边界为强制合规检查项。
