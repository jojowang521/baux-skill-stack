# Table

## 场景

设计师小序问：AI 生成的表格看起来"没毛病"，但为什么就是不像真实产品？

小智回答：因为它没做**字段类型对齐**、**主字段视觉突出**、**操作列约定**、**状态用 Badge**、**空态设计**这些"看起来没那么重要，但缺一个就露馅"的细节。

表格是 B 端界面的地基。地基一歪，上面全歪。

---

## 表格的六个区域

一张完整的 B 端表格包含六个可能存在的区域：

```
┌────────────────────────────────────────────────────┐
│  ☑ 已选 3 项   [批量导出] [批量分派]  [取消]      │  ① 批量操作条（选中后出现）
├────────────────────────────────────────────────────┤
│  ☐  客户名称  编号   金额↕   状态   联系人  操作 │  ② 表头
├────────────────────────────────────────────────────┤
│  ☑  阿里巴巴  C001   ¥120,000  ●活跃  张三   ⋯   │  ③ 数据行
│  ☐  腾讯       C002   ¥ 85,000  ●沉默  李四   ⋯   │
│  ☐  字节跳动   C003   ¥240,000  ●活跃  王五   ⋯   │
├────────────────────────────────────────────────────┤
│                                              (空态) │  ④ 空态（无数据时）
├────────────────────────────────────────────────────┤
│                                              (加载) │  ⑤ 加载态
├────────────────────────────────────────────────────┤
│  共 128 条              [<]  1 2 3 ... 13  [>]     │  ⑥ 分页
```

**规则**：批量操作条（①）在有选中项时才出现，不选中时**不占位**。

---

## 字段对齐规则

不同类型字段的对齐方式，**没有商量余地**：

| 字段类型 | 对齐 | 举例 |
|---|---|---|
| 文本 | 左对齐 | 客户名称、联系人、备注 |
| 编号/ID | 左对齐 | 客户编号 C001 |
| 数字（可比较） | **右对齐** | 金额、数量、百分比 |
| 日期时间 | 左对齐 | 2025-06-25 |
| 状态 | 左对齐（用 Badge） | 活跃/沉默 |
| 操作 | **右对齐**（固定右侧） | ⋯ 或 [编辑] |

**为什么金额必须右对齐**？因为用户需要**竖向比较数字大小**。左对齐的数字 `120000` 和 `85000` 视觉上前者反而"看起来小"（起点相同，末位错开）。

---

## 主字段（第一列）

第一列是**主字段**——用户扫视表格时第一眼锁定的信息。规则：

- 主字段用 `text-foreground` + `font-medium`，比其他列略重
- 主字段是可点击的（点击进入详情页），hover 时 `text-brand-primary`
- 主字段前面**不要**堆图标（除非有明确语义，如企业类型标识）

**如果有勾选框**，勾选框放在主字段的**左侧**：`☐ 阿里巴巴`

---

## 状态字段

**用 Badge，不用纯文字**。

```
● 活跃    使用 --success，浅底色 + 深文字
● 沉默    使用 --muted，中性
● 待跟进   使用 --warning
● 已流失   使用 --danger
```

**规则**：

- Badge 前面的圆点是**必须的**——它让色盲用户也能通过位置和形状感知差异
- Badge 尺寸不要过大，与文字同高
- 一个字段里的 Badge 颜色不要超过 4 种

---

## 操作列

**唯一约定**：操作列**固定在最右侧**，且**永远存在**（即使某行没权限操作也保留列宽，操作按钮变为禁用或消失）。

**两种表现形式**：

### 形式一：常驻按钮（推荐用于高频操作）

```
| 编辑 | 更多 ⋯ |
```

- 只暴露 1-2 个最高频操作
- 其余进"更多"菜单

### 形式二：Hover 显现 + 更多菜单

```
Hover 前：              ⋯
Hover 后：  编辑 | ⋯
```

- 更简洁，但需要用户 hover 才发现
- **移动端不适用**

### 规则

- 危险操作（删除、终止）**永远**放在"更多"菜单里，**不常驻**
- 危险操作**必须二次确认**（Dialog，不是 Toast）
- 无权限时，操作按钮**隐藏**（不是禁用）——除非需要告知用户"存在此操作但没权限"，此时禁用 + Tooltip

---

## 表头

- 表头文字：`text-muted` + `text-sm` + `font-medium`，比数据行**弱**
- 可排序字段：文字后面加 `↕` 图标，hover 时变深，排序中显示 `↑` 或 `↓`
- 表头背景：`bg-surface`（与数据行 `bg-background` 形成微弱分层）
- 表头**不要**加下拉筛选（筛选放在表格上方的筛选区）

---

## 行高与密度

三档：

- **紧凑（32-36px）**：数据量大、字段多，用于数据分析型场景
- **默认（44px）**：客户列表、订单列表等主流业务列表
- **宽松（52px）**：低频列表、每行有多行文字（如包含备注）

**同一产品保持一致**，不要一个页面 44、一个页面 52。

---

## 空态

四种空态，视觉表达要**不同**：

| 情境 | 表达 | 主要 CTA |
|---|---|---|
| 从来没有数据 | "还没有客户，添加你的第一个客户" | [新增客户] |
| 有数据但被筛选掉 | "当前筛选条件下没有匹配的客户" | [清除筛选] |
| 搜索无结果 | "没有找到匹配 '张三' 的客户" | [清除搜索] |
| 权限不足 | "你没有查看客户列表的权限" | [申请权限] |

**关键**：**每种空态的引导操作不同**。不要用一个"没有数据"打发所有场景。

---

## 加载态

- **首次加载**：骨架屏，显示表头 + 5 行灰色矩形占位
- **翻页/筛选**：表格顶部一根 2px 进度条，数据行保留旧数据（配合半透明蒙层）
- **刷新按钮**：图标旋转，其他部分不变

**不要**：整个表格区域显示一个巨大的 spinner。

---

## shadcn 结构示意

```tsx
<div className="rounded-md border">
  {/* 批量操作条 - 仅在有选中时出现 */}
  {selected.length > 0 && (
    <div className="flex items-center gap-2 px-4 py-2 border-b bg-surface-2">
      <span className="text-sm">已选 {selected.length} 项</span>
      <Button size="sm" variant="outline">批量导出</Button>
      <Button size="sm" variant="ghost" onClick={clearSelection}>取消</Button>
    </div>
  )}

  <Table>
    <TableHeader>
      <TableRow>
        <TableHead className="w-10"><Checkbox /></TableHead>
        <TableHead>客户名称</TableHead>
        <TableHead>编号</TableHead>
        <TableHead className="text-right">金额</TableHead>
        <TableHead>状态</TableHead>
        <TableHead>联系人</TableHead>
        <TableHead className="text-right w-20">操作</TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      {rows.map(row => (
        <TableRow key={row.id}>
          <TableCell><Checkbox /></TableCell>
          <TableCell className="font-medium">
            <Link href={`/customers/${row.id}`} className="hover:text-brand-primary">
              {row.name}
            </Link>
          </TableCell>
          <TableCell className="text-muted-foreground">{row.code}</TableCell>
          <TableCell className="text-right tabular-nums">¥{row.amount.toLocaleString()}</TableCell>
          <TableCell>
            <Badge variant={statusVariant[row.status]}>
              <span className="mr-1">●</span>{statusLabel[row.status]}
            </Badge>
          </TableCell>
          <TableCell>{row.contact}</TableCell>
          <TableCell className="text-right">
            <DropdownMenu>...</DropdownMenu>
          </TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</div>
```

**注意 `tabular-nums`**——它让所有数字宽度一致，右对齐时不会跳动。这是很多 AI 生成代码会漏的细节。

---

## 反例

- ❌ 金额左对齐（无法竖向比较）
- ❌ 状态用纯文字"活跃"没有 Badge（弱化了状态感）
- ❌ 删除按钮和编辑按钮并列常驻（高频误操作）
- ❌ 空态只显示"暂无数据"（没有引导下一步）
- ❌ 加载态整屏 spinner（用户失去上下文）
- ❌ 表格宽度不够时数字被截断（应该允许横向滚动或缩短字段名）
