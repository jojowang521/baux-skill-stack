# Pagination

## 场景

设计师小序问：分页不就是几个页码吗，为什么还要专门约定？

小智回答：因为分页要同时告诉用户四件事——**当前在哪一页**、**总共有多少**、**能不能跳转**、**每页看几条**。任何一个信息缺失，用户都会感到"这个表格好像有点笨"。

分页的复杂度不在样式，在于**信息密度和布局节奏**。

---

## 位置

**唯一约定**：分页位于**表格下方，右对齐**。

左侧显示"共 N 条"，右侧显示页码 + 每页条数选择。

```
┌────────────────────────────────────────────────────┐
│ 表格                                                │
├────────────────────────────────────────────────────┤
│ 共 128 条        [< 上一页]  1 2 3 ...13  [下一页 >]  每页 20 ▾ │
└────────────────────────────────────────────────────┘
```

**不要**：

- ❌ 分页放在表格上方（用户看完数据后自然向下寻找）
- ❌ 分页居中或左对齐（视觉重量失衡）
- ❌ 只显示页码，不显示总数（用户不知道数据规模）

---

## 组成元素

| 元素 | 必需？ | 位置 |
|---|---|---|
| 总条数 | ✅ 必需 | 最左 |
| 上一页 / 下一页 | ✅ 必需 | 页码两侧 |
| 页码 | ✅ 必需 | 中间 |
| 跳转输入框 | 可选 | 页码右侧 |
| 每页条数选择 | ✅ 必需 | 最右 |

---

## 页码显示规则

**总页数 ≤ 7 页**：全部显示

```
[<]  1  2  3  4  5  6  7  [>]
```

**总页数 > 7 页**：首末页 + 当前页附近 + 省略号

```
当前在第 1 页：   [<]  1  2  3  ...  13  [>]
当前在第 5 页：   [<]  1  ...  4  5  6  ...  13  [>]
当前在第 13 页：  [<]  1  ...  11  12  13  [>]
```

**规则**：

- 当前页高亮：`bg-brand-primary` + `text-brand-primary-fg`
- 未激活页码：`text-foreground`，hover 时 `bg-surface-2`
- 省略号不可点击
- 页码按钮尺寸：与 `Button size="sm"` 一致（h-8 w-8）

---

## 上一页 / 下一页

- 用文字 + 图标：`[← 上一页]` `[下一页 →]`（不要只用箭头，可读性差）
- 在第一页时，"上一页"**禁用**（不隐藏），保持布局稳定
- 在最后一页时，"下一页"禁用
- 快捷键（可选）：`← / →` 键翻页（表格获得焦点时）

---

## 每页条数选择

**默认选项**：`10 / 20 / 50 / 100`

**规则**：

- 默认值：**20**（B 端标准）
- 切换时，回到第 1 页（重要！否则用户在第 5 页切成每页 100，会跳到不存在的位置）
- 用 shadcn Select，不要用原生 `<select>`
- 显示格式：`每页 20 ▾`（不是"20 / 每页"，前置数字是错误的阅读顺序）

---

## 跳转输入框（可选）

数据量大（>500 条 / >20 页）时，添加跳转框：

```
[< 上一页]  1  ...  6 7 8  ...  25  [下一页 >]   跳至 [__] 页
```

**规则**：

- 输入框只接受数字
- 回车触发跳转
- 输入超出范围（如输入 100 但只有 25 页）时，Toast 提示"页码超出范围"，不要静默失败

---

## 总数展示

- 格式：`共 128 条`（不是 `Total: 128`）
- 数据量大时用千分位：`共 12,842 条`
- 有筛选时，显示筛选后总数：`共 42 条`
- **不要**在总数旁边显示"耗时 0.03s"这种技术细节

---

## 数据量为 0 时

**分页整体隐藏**（不显示"共 0 条 [< 1 >]"）。空态由表格区表达。

---

## URL 同步

**强规则**：当前页码和每页条数**必须同步到 URL query**：

```
/customers?page=3&size=20&search=alibaba
```

**原因**：

- 用户刷新页面时不应回到第 1 页
- 用户复制链接给同事，同事看到的是同一页数据
- 用户回退浏览器，应该回到上一页而不是重新加载列表

这是 B 端产品的**基本要求**，但 AI 生成时经常忽略。

---

## shadcn 结构示意

```tsx
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight } from "lucide-react"

export function Pagination({ total, page, size, onPageChange, onSizeChange }) {
  const totalPages = Math.ceil(total / size)
  const pages = calcPages(page, totalPages)  // 返回 [1, "...", 5, 6, 7, "...", 13]

  if (total === 0) return null

  return (
    <div className="flex items-center justify-between px-4 py-3 border-t">
      <div className="text-sm text-muted-foreground">
        共 {total.toLocaleString()} 条
      </div>

      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" disabled={page === 1} onClick={() => onPageChange(page - 1)}>
          <ChevronLeft className="h-4 w-4 mr-1" />
          上一页
        </Button>

        {pages.map((p, i) =>
          p === "..." ? (
            <span key={i} className="px-2 text-muted-foreground">...</span>
          ) : (
            <Button
              key={i}
              variant={p === page ? "default" : "ghost"}
              size="sm"
              className="h-8 w-8 p-0"
              onClick={() => onPageChange(p)}
            >
              {p}
            </Button>
          )
        )}

        <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => onPageChange(page + 1)}>
          下一页
          <ChevronRight className="h-4 w-4 ml-1" />
        </Button>

        <Select value={String(size)} onValueChange={(v) => onSizeChange(Number(v))}>
          <SelectTrigger className="w-[110px] h-8">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {[10, 20, 50, 100].map(n => (
              <SelectItem key={n} value={String(n)}>每页 {n}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
```

---

## 反例

- ❌ 只有页码，没有总数（用户不知道数据规模）
- ❌ 分页居中放置（B 端主流约定是右对齐）
- ❌ 切换每页条数时保留原页码（跳到空页面）
- ❌ 页码状态不同步到 URL（刷新丢失位置）
- ❌ 首页时"上一页"消失（布局跳动）
- ❌ 加载中直接冻结整个分页组件，不显示反馈
