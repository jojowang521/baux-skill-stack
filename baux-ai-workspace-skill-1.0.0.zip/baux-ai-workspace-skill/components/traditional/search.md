# Search

## 场景

设计师小序问：为什么 shadcn 有 Input，还要单独写 Search 规则？

小智回答：因为 B 端列表页的 Search 不只是"一个带放大镜图标的输入框"。它有明确的**位置约定**、**触发时机**、**清除逻辑**、**多字段搜索的取舍**。这些约定 shadcn 不管，但真实产品必须管。

---

## 使用场景

- **列表页顶部**：全字段模糊搜索
- **筛选区内**：单字段精确搜索（配合下拉/日期）
- **命令面板 Cmd+K**：全站导航搜索

本文件聚焦第一种：**列表页的搜索输入**。

---

## 位置

**唯一约定**：列表页搜索框位于**页面标题下方的操作区左侧**。

```
┌─────────────────────────────────────────────────┐
│  客户管理                                        │  ← 页面标题
├─────────────────────────────────────────────────┤
│  [🔍 搜索客户名称/编号/联系人]     [筛选] [新增] │  ← 操作区
├─────────────────────────────────────────────────┤
│  表格                                           │
```

**不要**：

- ❌ 把搜索框放在表格上方独立一整行
- ❌ 把搜索框放在页面标题右侧（那里是主 CTA 的位置）
- ❌ 把搜索框放在表格头里

---

## 尺寸与占位符

- **宽度**：280px（默认）/ 360px（搜索范围复杂时）
- **高度**：与同行其他 Button 一致，默认 36px（`h-9`）
- **占位符**：明确告诉用户能搜什么字段，不要写"请输入"
  - ✅ `搜索客户名称、编号、联系人`
  - ❌ `请输入搜索关键词`

---

## 交互规则

### 触发时机

**默认使用防抖搜索（Debounce）**，不要要求用户按回车：

- 输入停止 300ms 后触发搜索
- 输入内容少于 2 个字符时不触发（避免全表查询）
- 触发时，表格进入 Loading 状态（顶部进度条），不要清空表格

**回车键**：立即触发搜索（跳过防抖）。

### 清除

- 输入框内有内容时，右侧显示 `×` 清除按钮
- 点击 `×`：清空输入 + 重置表格到无搜索状态
- 快捷键：`Esc` 也可以清除（焦点在输入框时）

### 空结果

搜索无结果时，**表格区**显示空态：

```
🔍
没有找到匹配 "[搜索词]" 的客户
[清除搜索]
```

**不要**：

- ❌ 表格区完全空白，只在别处提示"无结果"
- ❌ 空态里不放"清除搜索"操作（用户需要一步返回全量）

---

## shadcn 代码模板

```tsx
import { Input } from "@/components/ui/input"
import { Search, X } from "lucide-react"
import { useState, useEffect } from "react"
import { useDebounce } from "@/hooks/use-debounce"

export function CustomerSearch({ onSearch }: { onSearch: (q: string) => void }) {
  const [value, setValue] = useState("")
  const debounced = useDebounce(value, 300)

  useEffect(() => {
    if (debounced.length === 0 || debounced.length >= 2) {
      onSearch(debounced)
    }
  }, [debounced])

  return (
    <div className="relative w-[280px]">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      <Input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="搜索客户名称、编号、联系人"
        className="pl-9 pr-9"
      />
      {value && (
        <button
          onClick={() => setValue("")}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          aria-label="清除搜索"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  )
}
```

---

## 与 AI 的关系

**当页面存在 AI Copilot Sidebar 时**：

- 搜索框的语义仍然是"精确匹配字段"，**不要**把它改成"自然语言搜索"
- 自然语言搜索（"帮我找出最近三个月没跟进的大客户"）是 Copilot 的能力，不是 Search 的能力
- 二者并存：Search 用于快速定位已知客户，Copilot 用于探索性查询

这个边界很重要——**如果模糊化，用户会不知道该往哪里输入**。

---

## 反例

- ❌ 搜索框宽度 100%，撑满一整行（视觉重量失衡）
- ❌ 搜索时清空表格（用户失去上下文）
- ❌ 占位符写"请输入"（浪费一次告知机会）
- ❌ 只支持回车触发（增加用户操作成本）
- ❌ 搜索无结果时表格完全消失（用户不知道该怎么退出搜索）
