# AI Citation

## 场景

设计师小序问：为什么每条 AI 输出都要标"依据 XX"？看起来啰嗦。

小智回答：因为**没有引用的 AI 输出，本质上是"看起来很自信的猜测"**。B 端产品里 AI 说的每一句话，可能都会成为用户做决策的依据。他决定要不要给这个客户打电话、要不要通过这份合同、要不要签这单——如果 AI 没告诉他"我为什么这么说"，用户凭什么信？

Citation 不是啰嗦，是 **AI Trust 的第一根柱子**。

---

## Citation 的三种形态

按显示密度分：

| 形态 | 用途 | 典型位置 |
|---|---|---|
| **Inline Citation** | 内嵌在正文里的角标 | AI 消息正文中 |
| **Source Row** | 消息底部的来源行 | AI 消息底部、Suggestion Card 内 |
| **Source Panel** | 独立可展开的来源面板 | 复杂回答的详细溯源 |

三种形态可以并用（正文角标 → 底部 Source Row 展开 → 点击进入 Source Panel）。

---

## Inline Citation（角标）

正文中插入引用角标：

```
阿里巴巴过去 45 天没有跟进记录[¹]，且过去 3 个月商机金额下降 30%[²]。
```

**规则**：

- 角标用**上标数字**：`[¹]` `[²]` `[³]`
- 颜色：`text-ai-accent`
- 可点击：点击弹出 Popover 显示这一条的来源详情
- 可 Hover：显示 Tooltip 预览来源名 + 数据摘要

**使用场景**：

- 需要精确追溯**某一句话**的来源
- 一条消息里有**多个不同来源**混合使用
- 高精度场景（合同分析、财务判断）

**不适用**：

- 简短对话（"你好" / "好的"）
- 只有一个数据来源的整段结论

---

## Source Row（底部来源行）

消息或卡片底部一行灰色文字，列出所有来源：

```
📄 客户跟进记录 · CRM 商机模块 · 3 条数据
```

**规则**：

- 位置：紧贴内容下方
- 字号：`text-xs`
- 颜色：`text-muted`
- 图标：`📄` 或 lucide 的 `FileText`
- 多个来源用 `·` 分隔
- 整行可点击展开 Source Panel

**这是最常用的形态**——大多数 AI 消息和 Suggestion Card 都应该带 Source Row。

---

## Source Panel（详细溯源面板）

点击 Source Row 后展开的详细面板：

```
┌─ 数据来源（3 项）───────────────────┐
│                                     │
│  📄 客户跟进记录                     │
│     阿里巴巴 · 2025-05-10 最后跟进   │
│     [查看原记录 →]                   │
│                                     │
│  📊 CRM 商机模块                     │
│     阿里巴巴 · 近 3 个月 5 条商机     │
│     总金额 ¥85,000（同期下降 30%）   │
│     [查看商机列表 →]                 │
│                                     │
│  📈 客户分层规则                     │
│     规则 v2.1 · 活跃客户定义         │
│     [查看规则说明 →]                 │
│                                     │
└─────────────────────────────────────┘
```

**规则**：

- 展开方式：**在消息下方就地展开**，不要弹 Modal
- 每条来源包含：图标、名称、上下文摘要、跳转链接
- 跳转链接**必须**能打开原始记录（新标签页或右侧 Drawer）
- 收起按钮：右上角 `▲` 或 `收起`

---

## 什么内容必须有 Citation？

**必须**：

- ✅ 具体数字（金额、天数、次数、百分比）
- ✅ 具体事件（谁做了什么，什么时候）
- ✅ 状态判断（活跃/沉默/流失/高价值）
- ✅ 业务建议（"建议本周跟进"→ 依据是什么）

**不必须**：

- 通用建议（"客户维护要及时" — 常识，不需要引用）
- 交互性对话（"好的" / "还有其他问题吗" — 无实质结论）
- 用户明确要求"直接给结论不用解释"时（尊重用户）

**边界判断**：如果 AI 的这句话被用户信任并采取行动，事后可能被追问"你怎么得出这个结论的"，就必须有 Citation。

---

## Citation 数据结构

来源应包含以下字段：

```typescript
type Citation = {
  id: string
  type: "record" | "table" | "document" | "rule" | "external"
  name: string             // 显示名："客户跟进记录"
  context: string          // 上下文摘要："阿里巴巴 · 2025-05-10 最后跟进"
  href?: string            // 可跳转链接
  confidence?: number      // 0-1，用于表达 AI 对此来源的置信度
  timestamp?: string       // 数据的时效时间戳
}
```

**关于 confidence**：详见 `principles/ai-trust.md` 的 Confidence 部分。

---

## 与置信度（Confidence）的关系

Citation 是**来源**，Confidence 是**AI 对来源的把握程度**。两者可以叠加：

- **高置信度 + 明确来源** → 常规 Citation 表达
- **低置信度 + 明确来源** → Citation 前加 `~` 或标注 `AI 推断，请核实`
- **无来源 + AI 生成** → **不允许出现**（应该改写为"我需要更多信息"）

---

## 无来源时的表达

AI 无法给出可靠来源时，**必须明确告知**，不要伪造：

```
✅ 好的表达：
"我在现有数据中没有找到相关记录。建议你手动核实
最近的沟通记录，或者告诉我更多背景。"

❌ 不好的表达：
"根据历史数据分析，建议..."（但没有 Citation）
```

**这是 Trust 的底线**——用户宁可 AI 说"我不知道"，也不要 AI 假装知道。

---

## 视觉细节

- Citation 图标（`📄` / `FileText`）大小：`h-3.5 w-3.5`
- Inline Citation 角标：`text-[10px]` `align-super`
- Source Row 与正文间距：`mt-2`
- Source Panel 展开动效：`slide-down` 200ms
- Citation 链接 hover 时：`text-ai-accent` + `underline`

---

## shadcn 结构示意

```tsx
// Source Row 形态
export function CitationRow({ sources }: { sources: Citation[] }) {
  const [expanded, setExpanded] = useState(false)

  if (sources.length === 0) return null

  return (
    <div className="flex flex-col gap-2">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-ai-accent"
      >
        <FileText className="h-3.5 w-3.5" />
        <span>{sources.map(s => s.name).join(" · ")}</span>
        <ChevronDown className={cn("h-3 w-3 transition-transform", expanded && "rotate-180")} />
      </button>

      {expanded && (
        <div className="flex flex-col gap-3 rounded-md bg-background border p-3">
          <div className="text-xs font-medium text-muted-foreground">
            数据来源（{sources.length} 项）
          </div>
          {sources.map(source => (
            <div key={source.id} className="flex flex-col gap-1">
              <div className="flex items-center gap-1.5 text-sm font-medium">
                <SourceIcon type={source.type} className="h-3.5 w-3.5 text-ai-accent" />
                {source.name}
              </div>
              <div className="text-xs text-muted-foreground pl-5">
                {source.context}
              </div>
              {source.href && (
                <a
                  href={source.href}
                  className="text-xs text-ai-accent hover:underline pl-5"
                >
                  查看原记录 →
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
```

---

## 反例

- ❌ AI 给出具体数字但不带引用（"金额下降 30%" 从哪儿看的？）
- ❌ Citation 只写"数据库"（没有具体的表、记录）
- ❌ Citation 无法点击跳转（用户无法核实）
- ❌ 用户点击 Citation 跳转到 404（比没有还糟）
- ❌ 弹 Modal 显示来源（打断阅读节奏，应该就地展开）
- ❌ 编造来源（"根据行业报告显示..."但没有报告名）
