# AI Suggestion

## 场景

设计师小序问：AI 主动给出的"建议"，怎么才不像广告推送？

小智回答：C 端的推送是"我想让你看"，B 端的 AI 建议是"我猜你需要"。**位置**、**时机**、**可忽略性**、**采纳的成本**这四件事决定了它是助力还是干扰。

一句话：**建议应该像同事在你耳边小声说话，不像销售在你面前挥手。**

---

## 三种建议形态

按主动性从低到高排：

| 形态 | 触发方式 | 视觉重量 | 使用场景 |
|---|---|---|---|
| **Inline Hint** | 用户操作后被动出现 | 极轻 | 表单填写时的智能补全 |
| **Suggestion Card** | 用户进入某状态后出现 | 中 | Copilot Sidebar 里的主动建议 |
| **Proactive Toast** | AI 检测到异常主动通知 | 重 | 关键异常（不要滥用） |

本文件聚焦第二种：**Suggestion Card**——这是 Copilot Sidebar 里最常见的形态。

---

## Suggestion Card 结构

```
┌─ Suggestion ────────────────────────────────┐
│ 💡 建议                              [× 忽略] │  ← Header
├─────────────────────────────────────────────┤
│ 阿里巴巴过去 45 天没有跟进记录，属于活跃客户 │
│ 中沉默时间最长的一个。建议本周内主动联系。   │  ← Body
│                                             │
│ 📄 依据：客户跟进记录 · CRM 商机模块         │  ← Citation
│                                             │
│ [创建跟进任务] [稍后再说]                    │  ← Actions
└─────────────────────────────────────────────┘
```

**视觉规则**：

- 底色：`bg-ai-surface`
- 左侧强调条：2px `bg-ai-accent`
- 圆角：`rounded-md`
- 内边距：`p-4`
- 与前后卡片的间距：`gap-3`

---

## 五个必备要素

一张合格的 Suggestion Card **必须**包含以下所有要素。缺一，用户就没法信任它。

### 1. 类型标签（Header）

告诉用户这是什么类型的建议：

- 💡 建议 — 探索性建议
- ⚠️ 提醒 — 有时效性的关注
- 🎯 机会 — 业务机会（如高价值客户）
- ⚡ 优化 — 效率优化（如批量处理）

标签用 emoji + 短文字。**不要**用长句子做 Header。

### 2. 结论（Body）

**一句话说清"AI 觉得你应该做什么"**。规则：

- 不超过 2 行
- 用**动作导向**的表达（"建议本周联系"，不是"该客户处于沉默期"）
- 涉及具体数据/时间时，用**加粗**：`过去 **45 天** 没有跟进`

### 3. 依据（Citation）

**必须有**。这是 AI Trust 三原则里的 Source（详见 `principles/ai-trust.md`）。

- 一行文字，`text-xs`，`text-muted`
- 可点击，跳转到原始数据
- 多个来源用 `·` 分隔

**没有 Citation 的 Suggestion Card 视为不合格。**

### 4. 主 Action（可点击执行）

**必须有明确动词**：

- ✅ `创建跟进任务` / `发送邮件` / `分派给张三` / `导出报告`
- ❌ `确定` / `处理` / `去看看`

**规则**：

- 主 Action 用 `size="sm"` `variant="default"`
- 高风险操作（发送邮件、修改数据、通知外部）**必须**点击后弹 Confirm Dialog
- 采纳后卡片消失（详见 `foundations/ai-motion.md` 的采纳动效）

### 5. 忽略路径

**必须给用户"忽略"的出口**。两种形式二选一：

- Header 右上角的 `×` 按钮（推荐，克制）
- 次要按钮 `稍后再说` / `已知道了`

**关键**：忽略后，同一条建议**不要在短时间内再次弹出**（否则变成骚扰）。至少 24 小时内不再重复出现。

---

## Header 类型的语义边界

四种类型不要混用：

| 类型 | 特征 | 用户预期 |
|---|---|---|
| 💡 建议 | 可选、可延后、无时效 | "我可以看看，也可以不看" |
| ⚠️ 提醒 | 有明确时效、错过有代价 | "这个我不能拖" |
| 🎯 机会 | 有价值增量、时间敏感 | "这个可能是好事" |
| ⚡ 优化 | 提高效率、不紧急 | "有更好的做法" |

**反例**：把常规建议标为⚠️提醒（狼来了，用户很快就会全部忽略所有卡片）。

---

## 出现时机

**三个允许的触发点**：

1. **用户打开 Sidebar 时**：显示 1-3 张最相关的建议
2. **用户在主内容区做出关键操作后**：如选中一个客户，Copilot 生成针对该客户的建议
3. **AI 定时扫描发现有价值的机会**：每次会话最多主动弹出 1 张，不要连发

**禁止的触发点**：

- ❌ 用户滚动表格时弹卡片（干扰浏览）
- ❌ 用户正在输入搜索/填表单时弹卡片（打断输入）
- ❌ 频率超过每分钟 1 张（骚扰）

---

## 同时出现多张时

Sidebar 里同一时刻显示多张 Suggestion Card：

- **数量上限：3 张**。超过 3 张显示"查看更多建议 (+N)"折叠区
- **排序**：按类型优先级 ⚠️ > 🎯 > 💡 > ⚡
- **依次出现**：`stagger` 80ms（详见 `foundations/ai-motion.md`）

---

## 采纳后的表达

用户点了"创建跟进任务"之后：

1. 卡片轻微上抬 4px + 淡出（200ms）
2. **主内容区对应位置**出现同样的结果（如客户列表里该行状态变为"待跟进"）
3. Toast 提示：`已为阿里巴巴创建跟进任务`
4. Toast 带一个 `查看` 或 `撤销` 按钮（详见 Human Review 原则）

**关键**：让用户看到"AI 的建议"→"我的行动"→"实际结果"这个闭环。

---

## 忽略后的表达

用户点了 `× 忽略`：

1. 卡片直接淡出（150ms）
2. **不弹 Toast**（忽略是隐性行为，不需要打扰确认）
3. 后续 24 小时内不再弹出同一条建议

---

## shadcn 结构示意

```tsx
export function SuggestionCard({ suggestion, onAccept, onDismiss }: Props) {
  return (
    <div className="rounded-md bg-ai-surface border-l-2 border-ai-accent p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-ai-foreground">
          {typeLabel[suggestion.type]}
        </span>
        <button
          onClick={onDismiss}
          className="text-muted-foreground hover:text-foreground"
          aria-label="忽略此建议"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <p className="text-sm text-foreground leading-relaxed">
        {suggestion.body}
      </p>

      <Citation sources={suggestion.sources} />

      <div className="flex items-center gap-2">
        <Button size="sm" onClick={() => onAccept(suggestion)}>
          {suggestion.actionLabel}
        </Button>
        <Button size="sm" variant="ghost" onClick={onDismiss}>
          稍后再说
        </Button>
      </div>
    </div>
  )
}
```

---

## 反例

- ❌ 建议卡片没有 Citation（用户不知道为什么 AI 这么说）
- ❌ 主 Action 写"确定"（用户不知道点了会发生什么）
- ❌ 没有忽略路径（用户被迫处理每一条）
- ❌ 忽略后 5 分钟又弹出（骚扰）
- ❌ 同时弹 6 张卡片（信息过载）
- ❌ 高风险操作点击后直接执行不确认（Trust 崩塌）
