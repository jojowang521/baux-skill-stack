# AI Chat

## 场景

设计师小序问：AI 对话消息不就是两种气泡——用户一个、AI 一个吗？

小智回答：如果只是这样，那和 C 端聊天软件有什么区别？B 端 AI 对话的**每一条消息**都可能触发一次业务操作（生成报告、更新客户状态、发送邮件），所以消息的组成不只是"文字"，还有**来源引用**、**操作按钮**、**结构化内容嵌入**、**可编辑与可撤销**。

AI Chat 是 AI Native 界面的**主入口**。

---

## 消息的两种角色

只区分两种角色：**用户** 和 **AI**。不要引入"系统消息"作为第三种气泡（系统消息应该作为轻量的分隔线或 muted 文字出现在消息流里，不占用气泡）。

---

## 用户消息

**视觉规则**：

- 右对齐
- 底色：`bg-brand-primary-soft`（品牌色的极浅版本）
- 圆角：`rounded-md`（`--radius-md` = 8px）
- 最大宽度：Sidebar 内容宽度的 85%
- 字号：`text-md` (15px)

**内容**：

- 支持多行文本
- 支持附件（图标 + 文件名 + 大小）
- 支持 @ 引用（如 @阿里巴巴客户）
- **不支持**流式（用户消息一次性显示）

---

## AI 消息 ★ 核心

AI 消息不是一个气泡，是一个**结构化容器**，可能包含多个子块：

```
┌ AI ────────────────────────────────────────┐
│                                            │
│  Header（可选）：正在分析近 30 天的跟进记录  │  ← 状态说明
│                                            │
│  正文文本（流式）：                          │  ← 主内容
│  阿里巴巴过去 30 天有 3 次商机接触...        │
│                                            │
│  ┌ 结构化嵌入（可选） ────────────────┐    │  ← 结构化数据
│  │  📊 跟进频率对比图                 │    │
│  └───────────────────────────────────┘    │
│                                            │
│  📄 引用：客户跟进记录 · 2025-06-10         │  ← 引用来源
│  📄 引用：CRM 商机模块 · 3 条记录            │
│                                            │
│  🎯 建议：为该客户创建一个跟进任务           │  ← 可执行建议
│                                            │
│  [复制] [重试] [👍] [👎]                    │  ← 操作栏
└────────────────────────────────────────────┘
```

**视觉规则**：

- 左对齐
- 底色：`bg-ai-surface`（浅紫）
- 左边框：2px `bg-ai-accent`（AI 强调色竖条）
- 圆角：`rounded-md`
- 无最大宽度限制（AI 内容通常更长，且可能含表格/图表）

---

## 五种可能的子块

### 1. Header（状态说明，可选）

用于长任务，说明 AI 当前在做什么：

```
🔄 正在检索 30 天内的跟进记录...
✅ 已检索到 12 条记录，正在分析
```

字号 `text-xs`，`text-muted`，紧贴气泡顶部。任务完成后可淡出或保留（保留更透明）。

### 2. 正文文本

- 流式输出（详见 `foundations/ai-motion.md`）
- 支持 Markdown 渲染（**加粗**、`代码`、列表）
- **不支持**表格（用结构化嵌入代替）
- **不支持**大段代码块（超过 20 行折叠展示，点击展开）

### 3. 结构化嵌入

当 AI 需要展示**结构化数据**（图表、小表格、数据卡片）时，嵌入独立卡片：

- 卡片底色：`bg-background`（比 AI 底色更浅，形成层级）
- 内部用 shadcn 组件（Card、Chart、mini Table）
- 圆角略小：`rounded-sm`
- 结构化内容**不逐字符流式**（整块出现）

**示例场景**：

- 客户跟进频率的小图表
- 3-5 行的关键数据表
- 客户画像卡片

**边界**：

- 超过 10 行的表格 → 不嵌入气泡，作为独立主内容展示（"我为你生成了一份客户名单"+ 独立表格区）
- 长报告 → 生成一个可点击打开的文档链接

### 4. 引用来源（Citation）

**每条 AI 消息，只要引用了数据，必须显示来源。** 详见 `components/ai-native/ai-citation.md`。

### 5. 可执行建议（Action Suggestion）

AI 提出可以直接执行的建议时，以按钮形态嵌入：

```
🎯 为阿里巴巴创建跟进任务  [创建] [稍后]
```

**规则**：

- 建议按钮**必须**有明确的动词（"创建"、"发送"、"分派"），不要"确定"
- 高风险操作（发邮件、修改数据、通知外部）**必须**弹出 Confirm Dialog，不允许一键执行
- 详见 `principles/ai-trust.md` 的 Human Review 部分

### 6. 操作栏

消息完成流式输出后，底部出现：

```
[📋 复制]  [🔄 重试]  [👍]  [👎]
```

- 位置：底部，右对齐
- 淡入 200ms 出现
- 图标 + 文字（`text-xs`）
- Hover 时显示 Tooltip 说明

---

## 消息间距

- 同一角色连续消息：间距 `space-2`（8px）
- 不同角色切换：间距 `space-4`（16px）
- 消息流顶部/底部与容器边界：`space-4`

---

## 时间戳

**默认不显示**每条消息的时间戳（噪音）。仅在以下情况显示：

- 消息发送时间距上一条超过 5 分钟 → 中间显示分隔文字 `刚刚` / `10 分钟前` / `今天 14:32`
- 用户 hover 消息 → 右上角 Tooltip 显示精确时间

---

## 长内容处理

- 超过 6 行的 AI 消息，末尾出现"展开全文 ▾"（默认收起前 6 行）
- 代码块超过 20 行，折叠为"查看 42 行代码 ▾"
- 图表/表格超过 8 行数据，"查看全部 42 条 →"（新开面板）

---

## 反例

- ❌ AI 消息不带引用，只是给结论（无法建立信任，详见 ai-trust.md）
- ❌ AI 建议按钮写"确定"（用户不知道会发生什么）
- ❌ 用户消息和 AI 消息用同一种气泡样式（无法快速区分）
- ❌ 每条消息都显示时间戳（视觉噪音）
- ❌ 长表格塞进气泡里（气泡横向撑爆）
- ❌ 流式输出到一半突然"整体重排"（用户视觉跳动，不安）

---

## shadcn 消息结构示意

```tsx
export function AiMessage({ message }: { message: AiMessageData }) {
  return (
    <div className="flex flex-col gap-2 rounded-md bg-ai-surface border-l-2 border-ai-accent p-4">
      {message.header && (
        <div className="text-xs text-muted-foreground">{message.header}</div>
      )}

      <div className="prose prose-sm max-w-none text-ai-foreground">
        <StreamingText text={message.content} />
      </div>

      {message.embeds?.map(embed => (
        <div key={embed.id} className="rounded-sm bg-background border p-3">
          <EmbedRenderer embed={embed} />
        </div>
      ))}

      {message.citations?.length > 0 && (
        <div className="flex flex-col gap-1">
          {message.citations.map(c => <Citation key={c.id} {...c} />)}
        </div>
      )}

      {message.suggestions?.map(s => (
        <SuggestionAction key={s.id} suggestion={s} />
      ))}

      {message.done && (
        <div className="flex justify-end gap-1 mt-1">
          <MessageAction icon={Copy} label="复制" />
          <MessageAction icon={RefreshCw} label="重试" />
          <MessageAction icon={ThumbsUp} label="有用" />
          <MessageAction icon={ThumbsDown} label="不好" />
        </div>
      )}
    </div>
  )
}
```
