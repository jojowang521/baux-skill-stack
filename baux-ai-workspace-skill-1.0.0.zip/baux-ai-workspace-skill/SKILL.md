---
name: baux-ai-workspace-skill
description: 规划、生成、评审和增量迭代带 AI Copilot 的 B 端原型，并从原型证据同步 PRD。内置客户列表与侧边助手模式、AI 来源/置信表达/人工把关规则及采购域示例；不提供真实 AI 后端或完整生产系统。
metadata:
  version: 1.0.0
---

# BAUX AI Native Workspace

将传统 B 端操作、AI 建议与可追溯依据放在同一个工作流中。原生模式聚焦客户列表 + AI Copilot Sidebar；采购域是示例知识库，非通用企业制度。

## 输入与输出

输入：业务需求、任务模式、已有原型/项目、角色权限、业务字段、历史决策；只加载与当前工作有关的材料。
输出：与复杂度相称的分析和计划、可演示原型或评审意见、验证记录、决策变更；需要时附 PRD 草稿。不得将演示数据或合理假设变成真实业务事实。

## 按任务路由

| 任务 | 读取 |
|---|---|
| 新建/大改版 | [需求分析](prompts/analyze-and-plan.md)、[交付流程](workflows/prototype-delivery.md) |
| 局部优化/追加需求 | [增量流程](workflows/prototype-iteration.md)，先识别受影响范围 |
| 仅评审 | [评审流程](workflows/prototype-review.md)，不自动重写代码 |
| PRD 同步 | [同步规则](prompts/generate-prd.md)、[PRD 模板](templates/prd-template.md) |

原型生成前先形成必要分析和计划；简单修改可只写简短影响说明。沿用已确认的项目现状与决策，非阻塞缺口用 `[合理假设]` 推进，只有核心业务、权限或不可逆操作缺失信息才询问。

## 规则加载

- 客户页：[客户列表模式](patterns/customer-list-page.md)，以及其引用的搜索、表格、分页规则。
- AI 助手：[侧栏模式](patterns/ai-copilot-sidebar.md)、[AI Trust](principles/ai-trust.md)，按需读 components/ai-native。
- 采购：[采购域](domains/procurement.md)。其中金额边界、角色例外和通知行为须按实际项目确认。
- 视觉：[Token](foundations/design-tokens.md)、[动效](foundations/ai-motion.md)；视觉参考不能覆盖业务与 Trust。
- 新项目初始化：[环境说明](foundations/setup.md)。现有项目优先复用；包内代码片段是结构示意，不能当作完整已测试组件。

## 不可丢失的边界

1. 来源使用 `[用户提供]`、`[项目现状]`、`[业务域规则]`、`[BAUX规则]`、`[合理假设]`、`[待确认]`；不伪造来源或确认状态。
2. AI 具体事实/数字/判断要有可打开的依据；通用回复无需硬造 Citation。置信标签不是经过统计校准的准确率。
3. 低置信建议先核查来源，不提供直接业务写入。可撤销必须有实际回滚实现；消息已送达不因 UI 显示撤销而被收回。
4. 关键操作显示对象、范围、执行者与内容，按真实风险设计人工确认；原型按钮不代表已获外部发送授权。
5. 权限同时作用于列表、详情、计数、搜索、AI 上下文、引用与动作。前端隐藏只演示体验，生产环境必须后端鉴权。
6. 选中上下文变化时清除旧回复与动作，避免使用旧客户的建议；动作再次校验对象与权限。操作改变任务字段，不应擅自改变客户生命周期状态。
7. 超出内置模式的设计要披露扩展范围；本 Skill 不提供采购系统、全屏 Agent 工作台或模型调用服务。

## 样板与验收

[离线客户工作台](assets/demo/index.html) 为 HTML/CSS/JavaScript 演示，无依赖安装；它验证交互模式，未声称使用真实 shadcn/React、真实模型或生产权限。演示数据、分析计划、决策和 PRD 草稿均在 assets/demo。

生成后按 [验证 Prompt](prompts/validate-prototype.md) 和 [验证模板](templates/validation-report.md) 执行可运行性、状态权限、AI Trust 与核心流程检查；无法执行的项目写“未验证”。修复本次范围内问题后更新 [决策记录](templates/decision-log.md)。团队确认前，PRD 始终为草稿。

演示对原版控件、分页和侧栏默认值的适配见 [实现范围](references/implementation-scope.md)。

本包验证范围与遗留项见 [1.0.0 验证记录](references/validation-1.0.0.md)。版本号与成熟度独立；原有 0.6 基线不改写。

Publisher：BAUX。Author：JOJO。保留 [原包许可](references/license.md)。
