# Prompt: 生成客户列表页

## 用法

把下面的提示词整段复制给 AI（Cursor、Claude Code、v0、TRAE 等），AI 会按 Skill 规则生成。

如果你的 AI 已加载本 Skill（在项目上下文里），可以直接说：**"按 BAUX Skill 生成客户列表页"**，AI 会自动查找并遵守规则。

---

## 完整提示词

````
基于 BAUX AI Native Workspace Design Skill，为 CRM 系统生成一个客户列表页。

【强制工作流】
在生成任何代码前：
1. 读取 `prompts/analyze-and-plan.md`
2. 按 `templates/requirement-analysis.md` 输出《需求分析》
3. 按 `templates/prototype-plan.md` 输出《原型规划》
4. 使用 `[用户提供]`、`[项目现状]`、`[业务域规则]`、`[BAUX规则]`、`[合理假设]`、`[待确认]` 标记关键结论
5. 规划门禁通过后，再生成原型

如果这是对已有页面的追加修改，改用 `workflows/prototype-iteration.md`，先输出变更影响分析，只修改受影响范围。

请严格遵守以下规则（引用自 Skill 内的规则文件）：

【页面结构】
参见 patterns/customer-list-page.md：
- 六个区域：面包屑（可选）、页面标题栏、筛选/搜索区、批量操作条（选中时出现）、表格、分页
- 页面标题栏：左侧 h1 标题 "客户管理"，右侧主 CTA "+ 新增客户"（品牌色）+ 次要按钮
- 无面包屑（假设从侧边栏直接进入）

【搜索】
参见 components/traditional/search.md：
- 宽度 280px，位于筛选区左侧
- 占位符明确："搜索客户名称、编号、联系人"
- 防抖 300ms，回车立即触发
- 右侧清除按钮（有值时出现）
- 搜索状态同步到 URL

【筛选】
参见 patterns/customer-list-page.md：
- 常驻筛选控制 3 个以内（推荐：状态、负责人、级别）
- 更多筛选放"更多筛选 ▾"
- 有活跃筛选时显示"清除全部"
- 选中的筛选以 Chip 形式显示

【表格】
参见 components/traditional/table.md：
- 字段配置：☐ 勾选 | 客户名称 | 编号 | 金额 | 状态 | 负责人 | 最后跟进 | 操作
- 客户名称：加粗、可点击（进入详情页）
- 金额：**右对齐** + tabular-nums + 千分位（¥120,000）
- 状态：Badge + 圆点，语义色（活跃=success、沉默=muted、待跟进=warning、流失=danger）
- 操作列：固定右侧、hover 时显现或常驻"⋯"更多菜单
- 删除操作：**放在"更多"菜单里**，必须 Confirm Dialog
- 默认行高 44px

【批量操作】
- 选中至少 1 项时，表格顶部出现批量操作条
- 显示："已选 N 项" + 批量操作按钮 + "取消选择"
- 批量删除必须 Confirm

【分页】
参见 components/traditional/pagination.md：
- 右对齐
- 左侧显示"共 128 条"
- 页码规则：≤7 页全显示，>7 页首末页 + 当前页附近
- 每页条数选择器：10 / 20 / 50 / 100（默认 20）
- 切换每页条数时回到第 1 页
- URL 同步 page / size 参数

【AI Copilot 联动】
参见 patterns/ai-copilot-sidebar.md：
- 主内容和右侧 Copilot Sidebar 并列（不覆盖）
- 用户勾选行 → Sidebar 上下文栏更新
- Copilot 建议采纳 → 主内容表格实时反映

【空态设计】
四种空态各有独立 CTA：
- 无数据："添加你的第一个客户"
- 筛选后无结果："清除筛选"
- 搜索无结果："清除搜索"
- 无权限："申请权限"

【权限】
- 无权限的按钮/操作：隐藏（不禁用），除非需要告知"存在此操作但无权限"
- 无查看权限：整个页面显示无权限说明

【技术栈】
- React + TypeScript
- shadcn/ui 组件（Button, Input, Table, Badge, DropdownMenu, Select, Dialog, Checkbox）
- Tailwind CSS
- lucide-react 图标
- 假数据即可（用 128 条客户示例，包含不同状态）

【文件结构】
- pages/customers/index.tsx — 页面主文件
- components/customers/CustomerTable.tsx — 表格
- components/customers/CustomerFilters.tsx — 筛选
- components/customers/CustomerPagination.tsx — 分页
- components/customers/BatchActionBar.tsx — 批量操作

生成前请先核对 BAUX Skill 里 `patterns/customer-list-page.md` 末尾的检查清单。
生成后读取 `prompts/validate-prototype.md`，按 `templates/validation-report.md` 完成系统验证；再用 `templates/decision-log.md` 记录关键决策、假设、待确认项和 PRD 影响。
````

---

## 简化版（当你已经加载了 Skill）

如果你的 AI Agent 已经加载了 BAUX Skill 作为 context，可以用简化版：

```
按 BAUX Skill 的 patterns/customer-list-page.md 生成客户列表页。
技术栈 React + shadcn。假数据 128 条。
先按 prompts/analyze-and-plan.md 输出需求分析和原型规划，门禁通过后再生成。
生成后按 prompts/validate-prototype.md 验证并输出决策记录。
```

---

## 生成后的补充检查 Prompt

生成完成后，可以让 AI 自查：

```
请用 BAUX Skill 的 examples/bad-stacked-components.md 里列出的 17 条常见问题，
逐条核对你刚刚生成的代码。如果发现问题，列出具体位置并给出修复方案。
```

这个提示词用于补充反例检查，不能替代 `prompts/validate-prototype.md` 的完整系统验证。

---

## 常见追加需求

生成完基础版后，你可能想追加这些需求：

**加载态**：
```
补充：首次加载时用骨架屏（表头 + 5 行占位）；筛选/搜索时表格顶部显示 2px 进度条，数据行保留旧数据。
```

**导出功能**：
```
"导出"按钮的行为：
- 无筛选时：导出全部数据
- 有筛选时：Dropdown 让用户选择"导出当前页" / "导出筛选结果 (128 条)" / "导出全部"
```

**行内编辑**（进阶）：
```
补充：负责人字段支持行内编辑——hover 时显示"✏️"图标，点击后变为下拉选择器。
选中新值 → Toast 提示"已修改，10 秒内可撤销"（符合 Human Review 原则）。
```
