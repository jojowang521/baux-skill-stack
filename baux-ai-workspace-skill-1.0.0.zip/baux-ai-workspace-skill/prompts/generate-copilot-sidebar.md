# Prompt: 生成 AI Copilot Sidebar

## 用法

把下面的提示词整段复制给 AI（Cursor、Claude Code、v0、TRAE 等），AI 会按 Skill 规则生成。

如果你的 AI 已加载本 Skill，可直接说：**"按 BAUX Skill 生成 AI Copilot Sidebar"**。

---

## 完整提示词

````
基于 BAUX AI Native Workspace Design Skill，生成一个 AI Copilot Sidebar 组件，
用于附加到客户列表页右侧。

【强制工作流】
在生成任何代码前：
1. 读取 `prompts/analyze-and-plan.md`
2. 按 `templates/requirement-analysis.md` 输出《需求分析》
3. 按 `templates/prototype-plan.md` 输出《原型规划》
4. 使用 `[用户提供]`、`[项目现状]`、`[业务域规则]`、`[BAUX规则]`、`[合理假设]`、`[待确认]` 标记关键结论
5. 规划门禁通过后，再生成原型

如果这是对已有 Sidebar 的追加修改，改用 `workflows/prototype-iteration.md`，先输出变更影响分析，只修改受影响范围。

请严格遵守以下规则（引用自 Skill 内的规则文件）：

【定位与场景】
- 这是 Copilot Sidebar，不是 Chat Workspace
- 附属于主内容（客户列表页），提供页面相关的 AI 能力
- 与主内容并列存在（不覆盖）

【三种状态】
参见 patterns/ai-copilot-sidebar.md：
- 收起（Collapsed）：40px 宽的窄条，显示 AI 图标 + 新建议红点 + 快捷键提示
- 默认展开（Expanded）：380px 宽
- 宽展开（Wide）：520px 宽（用户可拖）
- 状态记忆到 localStorage
- 首次进入产品：默认展开

【区域结构（展开状态）】
从上到下六个区域：

① Header（固定，56px 高）
   - 左：🤖 图标 + "AI 助手" + 副标题"基于当前页面的智能建议"
   - 右：折叠按钮 ▸、关闭按钮 ×、更多菜单 ⋯
   - 底部 1px 分隔线

② 上下文栏（条件出现）
   - 触发：主内容有选中/进入某记录时
   - 内容：📌 + "当前页面：客户列表" + 上下文数据"已选中 3 位客户"
   - 底色：bg-ai-surface

③ 主动建议区
   - 数量上限 3 张，超出显示"查看更多 (+N)"
   - 按类型优先级排序：⚠️提醒 > 🎯机会 > 💡建议 > ⚡优化
   - 每张 Suggestion Card 包含：类型标签、结论、Citation、主 Action、忽略路径
   - 出现动效：stagger 80ms 依次出现

④ 对话消息区
   - 用户消息右对齐（bg-brand-primary-soft）
   - AI 消息左对齐（bg-ai-surface + 左侧 2px ai-accent 竖条）
   - 自动滚动到最新
   - 用户上滚查看历史时，右下角出现 ↓ 新消息 按钮

⑤ 输入区（固定底部）
   - 单行输入自动扩展到多行，最多 5 行
   - Enter 发送，Shift+Enter 换行
   - 支持 @ 引用（@客户、@订单）
   - AI 生成中：输入框禁用，发送按钮变为"停止"

⑥ 提示 chips（首次/对话为空时）
   - 3 个页面相关的示例问题
   - 用户开始对话后消失，不再回来

【Suggestion Card 详细规则】
参见 components/ai-native/ai-suggestion.md：
- 底色 bg-ai-surface + 左侧 2px 竖条
- 圆角 rounded-md
- 五要素：类型标签、结论正文、Citation、主 Action（明确动词）、忽略路径（× 或"稍后"）
- 主 Action 用 shadcn Button size="sm"
- 高风险操作点击后弹 Confirm Dialog
- 采纳后卡片轻微上抬 4px + 淡出（200ms）

【AI 消息详细规则】
参见 components/ai-native/ai-chat.md：
- 流式输出（每 30-80ms 一个 token，末尾闪烁光标）
- 结构化内容（表格/图表）整块出现，不逐字符
- 消息底部操作栏：复制、重试、👍、👎（完成后 200ms 淡入）
- 每条消息含具体数据 → 必须带 Citation

【Citation 规则】
参见 components/ai-native/ai-citation.md：
- 每条 AI 输出如含具体数据/事件/判断，必须显示 Citation
- 形态：Source Row（消息底部一行灰色 "📄 客户跟进记录 · 商机模块"）
- 点击可展开 Source Panel（就地展开，不弹 Modal）
- 每个来源含图标、名称、上下文摘要、"查看原记录 →"链接

【AI Trust 三原则】
参见 principles/ai-trust.md，本 Sidebar 必须同时满足：
- Source: 每条建议和消息带 Citation
- Confidence: 用 🎯/⚠️/💡/⚡ 类型标签和"根据..."前缀表达把握程度
- Human Review:
  * Reversible 操作（创建任务、修改备注）→ Toast + 10s 撤销
  * Irreversible 操作（发送邮件、通知客户）→ 弹 Confirm Dialog + 明确动词按钮

【与主内容的联动】
- Sidebar 感知主内容：选中变化、页面切换、进入详情
- Sidebar 影响主内容：建议采纳后主内容表格实时反映
- Citation 点击 → 主内容打开对应记录（右侧 Drawer）

【技术栈】
- React + TypeScript
- shadcn/ui（Card, Button, ScrollArea, Textarea, DropdownMenu, Dialog, Toast/Sonner）
- Tailwind CSS
- lucide-react 图标
- localStorage 记忆折叠/宽度状态

【AI 专属色】
参见 foundations/design-tokens.md：
- --ai-surface: hsl(250, 100%, 98%)  浅紫底色
- --ai-accent: hsl(262, 83%, 58%)   紫色强调色
- Sidebar 整体氛围可用 bg-background 或 bg-ai-surface（保持克制）
- 建议卡片、AI 消息用 bg-ai-surface + 左侧 border-l-2 border-ai-accent

【假数据要求】
生成 2 张主动建议卡片示例：
1. 🎯 机会 - 沉默客户识别："选中的 3 位客户中，腾讯集团处于沉默期已 45 天...
   Citation: 客户跟进记录 · 商机模块。Action: 优先联系腾讯"
2. ⚡ 优化 - 负载均衡："3 位客户负责人分布不均，张三负责 2 位...
   Citation: 员工负载表。Action: 重新分派"

对话区留空。
提示 chips：找出高价值沉默客户 / 分析张三负责的客户 / 导出本月新增客户

【文件结构】
- components/copilot/CopilotSidebar.tsx  — 主组件
- components/copilot/SidebarHeader.tsx    — Header
- components/copilot/ContextBar.tsx       — 上下文栏
- components/copilot/SuggestionCard.tsx   — 建议卡片
- components/copilot/MessageList.tsx      — 对话消息
- components/copilot/AiMessage.tsx        — AI 消息组件
- components/copilot/Citation.tsx         — 引用组件
- components/copilot/InputArea.tsx        — 输入区
- components/copilot/CollapsedSidebar.tsx — 收起状态

生成前请核对 BAUX Skill 里 `patterns/ai-copilot-sidebar.md` 末尾的检查清单。
生成后读取 `prompts/validate-prototype.md`，按 `templates/validation-report.md` 完成系统验证；再用 `templates/decision-log.md` 记录关键决策、假设、待确认项和 PRD 影响。
````

---

## 简化版（当你已经加载了 Skill）

```
按 BAUX Skill 的 patterns/ai-copilot-sidebar.md 生成 AI Copilot Sidebar 组件。
技术栈 React + shadcn。
包含 2 张示例建议卡片。
先按 prompts/analyze-and-plan.md 输出需求分析和原型规划，门禁通过后再生成。
生成后按 prompts/validate-prototype.md 验证并输出决策记录。
```

---

## 组合 Prompt（客户列表页 + Copilot Sidebar 一起生成）

```
基于 BAUX Skill，生成一个完整的客户管理页面，包含：

生成代码前，先按 `prompts/analyze-and-plan.md` 输出需求分析与原型规划；如为已有页面的修改，先执行增量影响分析。

1. 主内容区：客户列表页（按 patterns/customer-list-page.md）
2. 右侧：AI Copilot Sidebar（按 patterns/ai-copilot-sidebar.md）
3. 二者通过 Context Provider 实现联动：
   - 用户在表格中勾选客户 → Sidebar 上下文栏更新 + 建议重新生成
   - Sidebar 建议采纳 → 表格对应行状态变化 + Toast 撤销窗口

技术栈：React + TypeScript + shadcn/ui + Tailwind + lucide-react。
使用 128 条假数据。
参考 examples/good-customer-list-with-copilot.md 的完整场景描述。
生成前用两个 Pattern 文件的检查清单核对；生成后按 `prompts/validate-prototype.md` 做系统验证并输出决策记录。
```

---

## 补充 AI Trust 检查 Prompt

```
请用 BAUX Skill 的 principles/ai-trust.md 里的检查清单，逐条核对刚生成的
Copilot Sidebar 代码：
- 每条 AI 输出有 Citation 吗？
- 置信度是否通过视觉/文字体现？
- 关键动作是否有 Review 机制？
- 用户能否判断并否决 AI 的建议？

列出不满足的地方，并给出修复方案。
```

该检查仅覆盖 AI Trust，不能替代 `prompts/validate-prototype.md` 的业务、状态权限、交互和工程验证。
