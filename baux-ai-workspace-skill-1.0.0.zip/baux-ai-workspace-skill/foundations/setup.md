# Setup · 环境配置与 shadcn 安装

## 场景

设计师小序问：拿到这套 Skill，第一步做什么？

小智回答：先判断是在新建独立原型，还是修改现有项目。新项目可以按本文件初始化 React + shadcn；现有项目应先读取当前技术栈、设计系统和组件，不要为了使用 Skill 自动替换或重复安装。无论哪种情况，都需要把 Skill 的入口和工作流文件加载进 AI 工具。

> 本文件里的安装命令只适用于新建原型，或用户明确同意补充依赖的项目。修改现有项目时，安装依赖和调整配置前应先确认必要性与影响范围。

---

> 版本说明：下方版本及安装命令来自原包历史示例，未在本轮重新验证；不代表当前最低兼容要求。实际初始化请按项目锁文件与对应框架官方要求核对。离线样板 `assets/demo/index.html` 不需要这些依赖。

## 前置要求

| 工具 | 最低版本 | 说明 |
|---|---|---|
| Node.js | 18.0+ | 运行环境，建议用 LTS 版本 |
| 包管理器 | npm 9+ / pnpm 8+ / yarn 1.22+ | 三选一，推荐 pnpm（更快） |
| 框架 | Next.js 14+ 或 Vite + React 18+ | shadcn 官方支持的框架 |

验证 Node.js 版本：

```bash
node -v   # 应显示 v18.x.x 或更高
npm -v    # 应显示 9.x.x 或更高
```

---

## 第一步：初始化项目

如果还没有项目，先创建一个：

**Next.js（推荐）**

```bash
npx create-next-app@latest my-project \
  --typescript \
  --tailwind \
  --eslint \
  --app \
  --src-dir \
  --import-alias "@/*"

cd my-project
```

**Vite + React**

```bash
npm create vite@latest my-project -- --template react-ts
cd my-project
npm install
```

---

## 第二步：安装并初始化 shadcn

shadcn 不是传统意义上的 npm 包——它把组件源码直接复制进你的项目，代码归你所有，可以随意修改。

运行初始化命令：

```bash
npx shadcn@latest init
```

初始化过程中会有几个选项，按以下配置选择：

```
✔ Which style would you like to use? › Default
✔ Which color would you like to use as base color? › Slate
✔ Would you like to use CSS variables for colors? › Yes
```

**为什么选 CSS variables？**

因为 Skill Forge Visual Guide 的色板（`#5B5FEF`、`#8B5CF6` 等）是通过覆盖 CSS 变量来应用的。选 Yes 之后，你可以直接把 `references/skill-forge-visual-guide.md` 里的色值粘贴进 `globals.css`，立刻生效。

---

## 第三步：安装本 Skill 用到的组件

BAUX AI Workspace Skill MVP 场景（客户列表页 + AI Copilot Sidebar）用到以下 shadcn 组件，一次性安装：

```bash
npx shadcn@latest add button
npx shadcn@latest add input
npx shadcn@latest add table
npx shadcn@latest add badge
npx shadcn@latest add checkbox
npx shadcn@latest add select
npx shadcn@latest add dropdown-menu
npx shadcn@latest add dialog
npx shadcn@latest add sheet
npx shadcn@latest add textarea
npx shadcn@latest add toast
npx shadcn@latest add tooltip
npx shadcn@latest add scroll-area
npx shadcn@latest add separator
```

或者一行安装全部：

```bash
npx shadcn@latest add button input table badge checkbox select dropdown-menu dialog sheet textarea toast tooltip scroll-area separator
```

安装完成后，组件源码会出现在 `src/components/ui/` 目录下。AI 工具读取项目时，会自动获取这些组件的完整实现、类型定义和属性说明。

**这是 Skill 能稳定运行的关键**——AI 不需要凭记忆猜 shadcn 的 Button 怎么写，直接从你的项目里读真实的代码。

---

## 第四步：安装图标库

Skill 里所有图标示例使用 lucide-react：

```bash
npm install lucide-react
```

用法示例：

```tsx
import { Search, Plus, ChevronDown } from "lucide-react"

<Search className="w-4 h-4 text-muted-foreground" />
```

---

## 第五步：应用 Skill Forge 视觉方向（可选）

如果你想使用 `references/skill-forge-visual-guide.md` 里定义的视觉风格，把以下 CSS 变量粘贴进 `src/app/globals.css`（覆盖 shadcn 的默认值）：

```css
@layer base {
  :root {
    /* Primary - Indigo */
    --primary: 238 66% 64%;           /* #5B5FEF */
    --primary-foreground: 0 0% 100%;

    /* Background */
    --background: 210 40% 98%;        /* #F8FAFC */
    --card: 0 0% 100%;                /* #FFFFFF */

    /* Border */
    --border: 220 13% 91%;            /* #E5E7EB */

    /* Text */
    --foreground: 222 47% 11%;        /* #1F2937 */
    --muted-foreground: 215 16% 47%;  /* #6B7280 */

    /* AI Purple - 用于 AI 专属元素 */
    --ai: 262 83% 58%;                /* #8B5CF6 */
    --ai-soft: 270 100% 97%;          /* #F3E8FF */
  }

  .dark {
    --primary: 239 68% 67%;           /* #6366F2 */
    --background: 222 47% 6%;         /* #0F1117 */
    --card: 225 22% 13%;              /* #1A1D27 */
    --border: 228 17% 24%;            /* #2D3148 */
    --foreground: 220 27% 97%;        /* #F1F3F9 */
    --muted-foreground: 220 9% 60%;   /* #8B92A5 */
    --ai: 263 89% 76%;                /* #A78BFA */
    --ai-soft: 259 38% 16%;           /* #1E1A35 */
  }
}
```

如果你有自己的品牌色，直接替换对应的值即可——Skill 里的规则不变，只有皮肤在变。

---

## 第六步：把 Skill 加载进 AI 工具

Skill 写好规则、shadcn 装好组件，最后一步是让 AI 工具能读到这套规则。

### Cursor

在项目根目录创建 `.cursorrules` 文件，内容如下：

```
请在生成任何 B 端界面代码之前，先读取以下 Skill 文件：
- SKILL.md（入口，了解 Skill 定位）
- prompts/analyze-and-plan.md（先分析规划，再生成）
- workflows/prototype-delivery.md（新建原型）
- workflows/prototype-iteration.md（追加需求）
- foundations/design-tokens.md（视觉基础）
- patterns/customer-list-page.md（客户列表页规则）
- patterns/ai-copilot-sidebar.md（Copilot Sidebar 规则）
- principles/ai-trust.md（AI Trust 三原则，最重要）
- examples/bad-stacked-components.md（反例，生成前必看）
- prompts/validate-prototype.md（生成后系统验证）

所有生成的代码必须遵守 principles/ai-trust.md 里的三原则。
每次创建或修改原型前必须先输出需求分析和原型规划；生成后必须验证并更新决策记录。
```

或者使用 Cursor 的 Rules 功能（Settings → Rules for AI），把上面的内容粘贴进去。

### Claude Code

在项目根目录创建 `CLAUDE.md`，Claude Code 会自动读取：

```markdown
# BAUX AI Workspace Skill

生成任何 B 端界面时，请遵守 BAUX AI Workspace Skill 的规则。

核心文件：
- `SKILL.md` — 入口
- `prompts/analyze-and-plan.md` — 生成前分析与规划
- `workflows/` — 新建、增量和评审路由
- `principles/ai-trust.md` — 灵魂，必须遵守
- `patterns/` — 页面级规则
- `examples/bad-stacked-components.md` — 生成前用反例清单自查
- `prompts/validate-prototype.md` — 生成后的系统验证

创建或修改原型前先输出需求分析与原型规划；追加需求执行增量影响分析；生成后输出验证报告和决策记录。
```

### v0 / TRAE / 其他 AI 工具

把 `prompts/analyze-and-plan.md` 与对应的生成 Prompt 一起提供给 AI；原型完成后再提供 `prompts/validate-prototype.md`。不要只复制组件规则而跳过工作流。

---

## 完成验证

安装完成后，可以用以下方式验证 Skill 是否正常工作：

**方式一：直接问 AI**

```
按 BAUX AI Workspace Skill 的规则，给我生成一个客户列表页的骨架代码。
生成前先输出需求分析和原型规划；门禁通过后再生成。
生成后执行系统验证，并输出决策记录、假设和待确认项。
```

**方式二：用 prompts/ 里的完整提示词**

复制 `prompts/generate-customer-list.md` 里的完整提示词，直接发给 AI，看生成结果是否：

- [ ] 先输出任务模式、需求分析和原型规划
- [ ] 关键结论使用来源标记
- [ ] 金额右对齐 + 千分位 + `tabular-nums`
- [ ] 状态用 Badge + 圆点
- [ ] AI 建议卡有 Citation
- [ ] Irreversible 操作有 Confirm Dialog
- [ ] Copilot 有上下文栏感知选中状态
- [ ] 生成后输出系统验证结果和决策记录

**如果以上都通过，Skill 配置成功。**

---

## 常见问题

**Q：shadcn 安装时报错 "Cannot find module"**

确认 Node.js 版本 ≥ 18，且项目已初始化 `package.json`（运行 `npm init` 或从框架模板创建）。

**Q：CSS 变量改了但界面颜色没变**

确认 `globals.css` 已在项目入口文件（`layout.tsx` 或 `main.tsx`）里 import。

**Q：AI 生成的代码没有遵守 Skill 规则**

检查 Skill 文件是否在 AI 工具的 context 里。Cursor 用户确认 `.cursorrules` 文件在项目根目录；Claude Code 用户确认 `CLAUDE.md` 存在。

**Q：想用 Ant Design 而不是 shadcn**

Skill 的规则层（Pattern / Principle）不依赖 shadcn，可以直接使用。只需要把 `components/` 里的代码示例从 shadcn 替换成 Ant Design 的等价组件即可。`principles/ai-trust.md` 里的三原则，任何技术栈都适用。
