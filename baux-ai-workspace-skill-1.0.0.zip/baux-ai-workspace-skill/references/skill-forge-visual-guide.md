# Skill Forge Visual Guide

## 关于这份文档

**Skill Forge** 是 BAUX 旗下的第二个可执行产品,定位为"专业、克制、可解释、可演进的 AI Skill 工作台"。这份文档是 Skill Forge 的完整设计规范,同时作为 **BAUX AI Workspace Skill 的推荐默认视觉方向**收录在这里。

换句话说:

- **BAUX AI Workspace Skill**(本 Skill)—— 定义 AI 生成 B 端界面时**该怎么组织**(规则本体)
- **Skill Forge Visual Guide**(本文档)—— 定义 AI 生成 B 端界面时**该怎么表达**(视觉本体)

两者都是 BAUX 品牌下的可执行资产,精神一致:

| Skill Forge 关键词 | BAUX Skill 对应原则 |
|---|---|
| **Structured** | Pattern 层的清晰页面结构约定 |
| **Calm** | 克制的视觉、少饱和度、少装饰 |
| **Intelligent** | AI Native 组件(Chat / Suggestion / Citation)的表达 |
| **Traceable** | AI Trust 三原则里的 Source(来源) |

一句话:**Skill Forge 的视觉语言把 BAUX Skill 的"Trust"翻译成了"可以看得见的克制专业"。**

---

## 何时使用这份 Guide

- ✅ 使用 BAUX AI Workspace Skill 且**没有自有品牌规范**时,作为默认视觉方向
- ✅ 项目定位是**"专业 AI 工作台"、"设计工具"、"团队协作平台"**时优先参考
- ✅ 需要让 AI 生成的 B 端界面看起来**像 Linear / Figma Dev Mode / Notion AI**
- ⚠️ 项目已有强品牌规范(如客户自己的设计系统),按客户规范优先,本 Guide 仅供交叉参考

---

## 如何阅读这份 Guide

- **Section 7 (Visual Style)**:核心视觉 tokens——颜色、字体、圆角。AI 生成代码时直接引用
- **Section 8 (Component Guidelines)**:通用组件规范——Skill Card / Extraction Card / AI Insight Panel 等
- **Section 9-10 (Interaction / Motion)**:交互原则和动效指引
- **Section 11 (Content Tone)**:文案调性
- **Section 1-6 (Product Positioning + Screen Specs)**:Skill Forge 特定的产品规格,仅供参考,不影响 BAUX Skill 的其他 Pattern

---

## 与 BAUX Skill 其他文件的关系

| BAUX Skill 文件 | 与本 Guide 的关系 |
|---|---|
| `foundations/design-tokens.md` | 定义**语义化 tokens**(brand / ai / muted / semantic),本 Guide 提供**具体色值** |
| `foundations/ai-motion.md` | 与本 Guide Section 10 (Motion) 一致,可交叉参考 |
| `principles/ai-trust.md` | 与本 Guide Section 9.1-9.4 (Explain / Human Control / Progress / AI Usage Visible) 直接对应 |
| `components/ai-native/*` | 本 Guide 8.1-8.7 提供了更具体的组件视觉参考 |
| `patterns/*` | 本 Guide Section 6 是 Skill Forge 特定 Pattern,与 BAUX Skill 现有 Pattern 并列 |

---

## Skill Forge Design Guide 原文

---

### 1. Product UI Positioning

Skill Forge is an AI Product & Design Skill Workspace built for product managers, product designers, UX/UI designers, design system teams, and product leaders.

The UI should not feel like a traditional knowledge base, prompt manager, or generic AI chat tool. It should feel like a professional workspace where team knowledge is transformed into structured, explainable, reusable, and evolving AI Skills.

The core design positioning is:

A structured, calm, intelligent, and traceable AI Skill Workspace for product and design teams.

In Chinese:

一个专业、克制、可解释、可演进的 AI Skill 工作台。

The UI should communicate three ideas clearly:

1. Team knowledge can be structured.
2. Structured knowledge can become executable AI Skills.
3. Skills can be used, reviewed, and continuously improved inside the workflow.

### 2. Design Keywords

The visual and interaction style should follow these keywords:

- Structured
- Calm
- Intelligent
- Traceable
- Professional
- Design-team friendly
- Workspace-like
- Trustworthy
- Editable
- Evolvable

The product should feel closer to:

- Notion's information structure
- Linear's calm professional SaaS style
- Figma Dev Mode's design-tool clarity
- AI Workspace's intelligent interaction layer

It should not feel like:

- A traditional document repository
- A prompt library
- A chatbot wrapper
- A cyberpunk AI tool
- A heavy enterprise admin system

### 3. Core UI Concept

Skill Forge uses a three-column workspace structure.

```
┌─────────────────────────────────────────────────────────────┐
│ Top Bar: Skill Forge / Project / Use in TRAE / User          │
├───────────────┬───────────────────────────┬─────────────────┤
│ Left Sidebar  │ Main Workspace             │ Right Panel      │
│               │                            │                 │
│ Knowledge     │ AI Parsing / Skill Canvas  │ Skill Details    │
│ Skill Library │ Workflow Preview           │ Rules / Version  │
│ TRAE Bridge   │ Review Result              │ Suggestions      │
└───────────────┴───────────────────────────┴─────────────────┘
```

**Left Sidebar** — Navigation and asset organization. Primary sections: Projects, Knowledge Sources, Skill Library, TRAE Integration, Evolution Log.

**Main Workspace** — Center of the product experience. Used for uploading team knowledge, viewing AI parsing results, generating Skills, editing Skill drafts, launching Skills into TRAE, reviewing product and design outputs.

**Right Panel** — Explainability and control. Used for AI insights, confidence score, source references, missing information, suggested improvements, validation rules, version history. This panel is important because Skill Forge should not feel like a black-box AI system.

### 4. Information Architecture

```
Workspace
├── Projects
│   ├── ERP Payment Module
│   ├── Purchase Approval
│   ├── Contract Management
│   └── Inventory Transfer
│
├── Knowledge Sources
│   ├── PRD / Product Roadmap / Design System
│   ├── Design Guideline / Case Study
│   ├── Review Notes / User Feedback
│
├── Skill Library
│   ├── Product Skill / Design Skill
│   ├── Review Skill / Workflow Skill / Agent Skill
│
├── TRAE Integration
│   ├── Use in TRAE / Loaded Skills
│   ├── Active Workflow / Agent Context
│
└── Evolution Log
    ├── Version History / New Pattern Detected
    ├── Feedback Imported / Rule Updated
```

### 5. Demo Page Structure

Nine core screens (short version: six):

```
1. Project Overview
2. Knowledge Upload
3. AI Knowledge Analysis
4. Generated Skills
5. Skill Detail / Editor
6. Use in TRAE
7. TRAE AI Workspace
8. Skill Review
9. Skill Evolution Log
```

### 6. Page Design Specifications

*(详见原文 Section 6.1 - 6.9, 涵盖每个屏幕的目的、布局、示例内容、设计要点。此处不重复展开,AI 生成 Skill Forge 相关 UI 时按需引用。)*

Key screens include:

- **6.1 Project Overview** — Project title, context, knowledge coverage, current Skill status, primary CTA "Create Skill from Team Knowledge"
- **6.2 Knowledge Upload** — Drag-and-drop area, uploaded source list, automatic classification, Skill type selection
- **6.3 AI Knowledge Analysis** — Knowledge → Pattern → Workflow → Validation Rules extraction canvas
- **6.4 Generated Skills** — Side-by-side Skill cards with status (Draft / Ready to Use / Updated / Needs Review)
- **6.5 Skill Detail / Editor** — Three-part layout: Left nav / Center content / Right AI Insight panel
- **6.6 Use in TRAE** — Bridge to TRAE workspace with selected skills and context preview
- **6.7 TRAE AI Workspace** — Loaded Skills panel showing "Using Payment Product Skill / Using Design Skill"
- **6.8 Skill Review** — Overall score, passed items, issues found with related rules
- **6.9 Skill Evolution Log** — New feedback imported, AI detected patterns, proposed updates, version history

### 7. Visual Style ★ 核心

#### 7.1 Overall Visual Direction

The UI should be clean, calm, and structured.

Use:

- Light background
- White cards
- Subtle borders
- Clear information hierarchy
- Small AI highlights
- Minimal gradients
- Professional typography

Avoid: excessive shadows, neon effects, heavy glassmorphism, or overly decorative AI visuals.

#### 7.2 Color Tokens

**Primary Colors**

```css
--color-primary: #5B5FEF;
--color-primary-hover: #4F46E5;
--color-primary-soft: #EEF2FF;

--color-ai: #8B5CF6;
--color-ai-soft: #F3E8FF;

--color-navy: #111827;
```

**Text Colors**

```css
--color-text-primary: #1F2937;
--color-text-secondary: #6B7280;
--color-text-tertiary: #9CA3AF;
--color-text-inverse: #FFFFFF;
```

**Background Colors**

```css
--color-bg-page: #F8FAFC;
--color-bg-card: #FFFFFF;
--color-bg-sidebar: #FFFFFF;
--color-bg-muted: #F3F4F6;
```

**Border Colors**

```css
--color-border-default: #E5E7EB;
--color-border-strong: #D1D5DB;
--color-border-active: #C7D2FE;
```

**Functional Colors**

```css
--color-success: #16A34A;
--color-success-soft: #DCFCE7;

--color-warning: #F59E0B;
--color-warning-soft: #FEF3C7;

--color-error: #DC2626;
--color-error-soft: #FEE2E2;

--color-info: #2563EB;
--color-info-soft: #DBEAFE;
```

**Gradient** — Use gradient **only** for selected AI or Skill generation moments.

```css
--gradient-ai: linear-gradient(135deg, #5B5FEF 0%, #8B5CF6 100%);
```

Gradient should be used sparingly on:

- Create Skill CTA
- AI Parsing status
- Skill Ready state
- Use in TRAE button
- Skill Evolution update moment

#### 7.3 Typography

**Recommended Fonts**

English: Inter / SF Pro / Geist
Chinese: PingFang SC / HarmonyOS Sans / Source Han Sans

**Font Scale**

```css
--font-page-title:    24px / 28px;
--font-section-title: 16px / 20px;
--font-card-title:    14px / 18px;
--font-body:          14px / 20px;
--font-meta:          12px / 16px;
--font-tag:           12px / 16px;
```

**Typography Rules**

- Page titles should be clear and calm.
- Section titles should use medium weight.
- Body text should be easy to scan.
- Metadata should be visually lighter.
- AI-generated content should be readable and editable, not decorative.

### 8. Component Guidelines

#### 8.1 Skill Card

Structure:
```
Product Skill
Payment Product Skill

12 Knowledge Items
8 Workflow Nodes
16 Validation Rules

Status: Ready to Use
[ Open Skill ] [ Use in TRAE ]
```

Style:
```css
border-radius: 12px;
border: 1px solid #E5E7EB;
background: #FFFFFF;
box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
```

States: Default / Hover / Selected / Draft / Ready to Use / Needs Review / Updated

#### 8.2 Knowledge Source Card

Shows uploaded files and their extracted knowledge type. States: Uploaded / Parsing / Parsed / Needs Review / Failed.

#### 8.3 Extraction Card

Displays AI-extracted Knowledge, Pattern, Workflow, or Validation Rule.

Required fields: Type, Title, Extracted content, **Source reference**, **Confidence**, Status.

**Design principle**: Extraction cards should emphasize **traceability**. Source reference and confidence score should always be visible.

#### 8.4 Validation Rule Card

Severity levels: Low / Medium / High / Critical.

#### 8.5 AI Insight Panel

Provides explainability and guidance. Should stay visually light but always accessible.

Example structure:
```
AI Insight

Confidence: 87%

Missing Information (3 items)

Suggested Improvements (5 items)

Source Coverage
- PRD              Strong
- Design System    Strong
- Review Notes     Medium
- Case Study       Weak
```

#### 8.6 Evolution Timeline

Vertical timeline. Each version item includes: Version number, Change summary, Source of update, Date, Updated Skill area.

#### 8.7 Status Tag

Style rules: Use pill shape / soft background colors / short text / avoid overly bright colors.

Examples: Ready to Use / Draft / Parsing / Parsed / Needs Review / Updated / Strong / Weak / Confirmed.

#### 8.8 CTA Button

Primary buttons should use the primary indigo color.
AI-related primary buttons may use the AI gradient.

```css
background: linear-gradient(135deg, #5B5FEF 0%, #8B5CF6 100%);
color: #FFFFFF;
border-radius: 8px;
height: 36px;
padding: 0 14px;
```

### 9. Interaction Principles

#### 9.1 Explain Before Automating

Whenever AI generates or changes something, the UI should show: what was generated, where it came from, how confident the system is, what the user can edit.

#### 9.2 Keep Human Control Visible

Skill Forge should never feel like a black-box auto-generation tool. Important actions should support Review / Edit / Confirm / Save / Version update.

#### 9.3 Show Progress as Structure, Not Loading

Avoid generic loading screens. When AI parses documents, show progressive structure:

```
Extracting Knowledge
Detecting Patterns
Building Workflow
Creating Validation Rules
Generating Skill Draft
```

#### 9.4 Make AI Usage Visible

When TRAE uses Skills, show which Skills are being used:

```
Using Payment Product Skill
Using Payment Design Skill
Using ERP Design System Skill
```

### 10. Motion and Micro-interactions

Motion should be subtle and purposeful.

Recommended motion moments: file upload completed, knowledge extracted, Skill generated, Skill status changed to Ready to Use, Use in TRAE transition, review issue detected, Skill updated to new version.

Avoid large decorative AI animations.

**Motion Style**

```
Duration: 160ms - 280ms
Easing:   ease-out
Movement: subtle fade, slide, or scale
```

### 11. Content Tone

The product language should be clear, professional, and action-oriented.

**Use phrases like**:
- Create Skill from Team Knowledge
- AI Knowledge Analysis
- Generated Skills
- Open Skill
- Use in TRAE
- Review with Skill
- New Pattern Detected
- Update Skill
- Skill updated to v1.1

**Avoid** overly magical or vague AI language like:
- Magic Generate / AI Brain / Super Prompt / One-click Intelligence

The product should sound trustworthy and useful, not exaggerated.

### 12. Demo Visual Highlights

Five key moments:

1. **Documents Become Structure** — Documents → Knowledge/Pattern/Workflow/Rule → Skill
2. **Skill Ready to Use** — Reusable asset feeling
3. **Use in TRAE** — Skill enters actual work environment
4. **Review with Skill** — Skill can evaluate work, not only generate work
5. **Skill Evolution** — Team experience continuously improves AI capability

### 13. Accessibility Requirements

- **Color**: Do not rely on color alone. Use text labels with status colors. Ensure sufficient contrast.
- **Text**: Body text ≥ 14px. Metadata may use 12px but should remain readable.
- **Keyboard**: Important actions reachable by keyboard: Upload / Open Skill / Save Skill / Use in TRAE / Review / Update Skill.
- **Focus**: Interactive elements should have visible focus states.

### 14. Design System Summary

**Layout**: Top Bar / Left Sidebar / Main Workspace / Right Insight Panel

**Core Components**: Skill Card / Knowledge Source Card / Extraction Card / Validation Rule Card / AI Insight Panel / Evolution Timeline / Status Tag / CTA Button / Review Issue Card / Loaded Skill Badge

**Core States**: Uploaded / Parsing / Parsed / Draft / Ready to Use / Needs Review / Confirmed / Updated / Strong / Weak / Failed

**Primary Colors**:
- Primary Indigo: `#5B5FEF`
- AI Purple: `#8B5CF6`
- Page Background: `#F8FAFC`
- Card Background: `#FFFFFF`
- Text Primary: `#1F2937`
- Text Secondary: `#6B7280`
- Border: `#E5E7EB`

### 15. Final Design Direction

Skill Forge should feel like a professional AI Skill operating system for product and design teams.

The final product feeling should be:

> Calm like a workspace.
> Clear like a design tool.
> Intelligent like an AI agent system.
> Trustworthy like team infrastructure.

---

## 与 BAUX Skill 联合使用示例

生成一个使用本 Guide 视觉的界面时,AI 应该同时遵守:

- **本 Guide 的 Section 7.2** → 具体色值(Primary `#5B5FEF`、AI `#8B5CF6`、bg `#F8FAFC`)
- **本 Guide 的 Section 8** → 组件视觉规范(Skill Card 12px 圆角、pill 状态标签、AI Insight Panel 结构)
- **BAUX Skill `principles/ai-trust.md`** → AI Trust 三原则(Source / Confidence / Human Review)
- **BAUX Skill `patterns/*`** → 页面级组织规则(即使是 Skill Forge 场景,金额右对齐、Copilot 上下文栏、Citation 必带等规则依然适用)

**当二者冲突时的优先级**:

1. **BAUX Skill 的 `principles/ai-trust.md`** —— 最高优先级(灵魂不能被视觉改动)
2. **BAUX Skill 的 `patterns/*` 和 `components/*`** —— 结构性规则优先于视觉规则
3. **本 Guide 的 tokens 和组件规范** —— 在结构确定后指导视觉表达

一句话:**BAUX Skill 管"该怎么组织",Skill Forge Guide 管"该怎么好看"。**
