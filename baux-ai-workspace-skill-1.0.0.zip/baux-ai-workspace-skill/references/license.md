# 原包许可与署名

Publisher：BAUX；Author：JOJO。以下条款原样保留，非标准开源许可证，未推断额外授权。

## License

- ✅ 团队/公司内部使用、修改、二次开发 — 无需授权
- ✅ 用于 AI 生成实际产品代码 — 无需授权
- ✅ 引用 Skill 内的规则和结构 — 需注明“引自 BAUX AI Native Workspace Design Skill”
- ❌ 直接商用重新分发（改包装售卖）— 需联系授权

---

*BAUX · Build AI Native B2B Experiences.*
