"""Compile the bundled token preset to CSS without third-party packages."""
import argparse
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def compile_tokens(directory):
    values = {}
    def put(name, value):
        if not re.fullmatch(r'[a-z0-9-]+', name):
            raise ValueError(f'非法变量名: {name}')
        if not isinstance(value, str) or not value.strip() or any(c in value for c in '{};<>\\\n\r') or '/*' in value or 'url(' in value.lower():
            raise ValueError(f'非法 CSS 值: {name}')
        values[name] = value
    def read(name):
        return json.loads((directory / name).read_text(encoding='utf-8'))
    colors = read('colors.json')
    for group, prefix in [('brand','brand'),('functional','func'),('text','text'),('background','bg'),('border','border')]:
        for key, item in colors[group].items(): put(f'{prefix}-{key}', item['value'])
    spacing = read('spacing.json')
    for key, value in spacing['scale'].items(): put('space-'+key,value)
    for key, value in spacing['semantic'].items(): put(key,value)
    radius = read('radius-shadow.json')
    for group in ['radius','shadow']:
        for key, item in radius[group].items(): put(f'{group}-{key}', item['value'])
    typography = read('typography.json')
    put('font-family',typography['font-family'])
    for key, item in typography['scale'].items():
        for prop in ['size','line-height','weight']: put(f'type-{key}-{prop}',item[prop])
    return '/* Generated from tokens/*.json; run scripts/build_tokens.py after editing. */\n:root {\n'+''.join(f'  --{k}: {v};\n' for k,v in values.items())+'}\n'

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tokens-dir',type=Path,default=ROOT/'tokens')
    parser.add_argument('--output',type=Path,default=ROOT/'assets/demo/tokens.css')
    args=parser.parse_args()
    try:
        content=compile_tokens(args.tokens_dir)
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(content,encoding='utf-8')
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as exc:
        parser.exit(2,f'Token 编译失败：{exc}\n')
    print(args.output)

if __name__=='__main__': main()
