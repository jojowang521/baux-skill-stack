# Token 接入

原包 JSON 保留为本包演示预设；不宣称这些数值均是官方规则。JSON 是源文件，CSS 是构建产物，浏览器直接读取 CSS。

在 Skill 根目录运行：

```bash
python3 scripts/build_tokens.py
python3 -m unittest discover -s tests -v
```

修改 tokens/ 后重新编译，再刷新页面。脚本需要 Python 3.9+ 标准库；默认更新 assets/demo/tokens.css。可用 --tokens-dir 和 --output 指定隔离路径，不修改已安装目录或其他项目。

映射：颜色 brand.* → --brand-*，functional.* → --func-*，background.* → --bg-*，text.* → --text-*，border.* → --border-*；spacing.scale → --space-*，semantic → --对应键；圆角/阴影 → --radius-* / --shadow-*；字体 → --font-family、--type-{层级}-{size/line-height/weight}。

品牌关联色均为显式值，没有自动亮 15% 等算法。修改 primary 后应同时评估 hover、active、bg、文本链接和焦点色；只修改一个值只影响引用该变量的样式。边框宽度、布局列数等结构尺寸可在 CSS 中保留，不必强行全部 Token 化。

本包示例用原生 HTML/CSS/JavaScript，不导入 Ant Design。接入已有组件库时按目标库的主题接口映射，不能把 CSS 变量名当作 antd Token 名称。
