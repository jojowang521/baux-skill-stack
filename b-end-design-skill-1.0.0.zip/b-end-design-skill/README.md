# B 端页面设计与原型 1.0.0

完整目录名 b-end-design-skill，入口 SKILL.md。沿用目标宿主的 Skill 安装方式；本次未修改已安装目录，也未发布。

## 演示

打开 assets/demo/index.html，体验列表、表单、详情。示例为原生 HTML/CSS/JavaScript，仅使用包内文件，无 CDN 或第三方运行依赖。也可在 assets/demo 启动本地静态服务。数据只保存在当前页面内存，刷新恢复，不提交到服务器。

输入与数据、站点截图、展示元数据随演示提供。demo-data.json 与 demo-data.js 是同一份数据的两种包装；修改时同步更新，页面读取 JS 以支持直接打开文件。

修改 tokens/ 后运行 python3 scripts/build_tokens.py，重新生成共用 CSS。Python 仅用于编译 Token 和测试，打开演示不需要 Python。

## 来源与范围

来源为 b-end-design-skill.zip，原始六包基线保留在第一批交付包。原包无规范化英文入口名，本版采用包名 b-end-design-skill；原包未声明版本，本轮统一 1.0.0。作者、Skill 许可与仓库未声明，未推断或新增授权。

本包是可调整的页面模式与本地演示，不是通用业务引擎。验证边界见 references/validation-report.md。
