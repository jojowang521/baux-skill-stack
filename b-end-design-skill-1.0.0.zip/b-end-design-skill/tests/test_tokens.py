import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_tokens import compile_tokens
class TokensTests(unittest.TestCase):
    def test_bundled_css_matches_source(self):
        self.assertEqual(compile_tokens(ROOT/'tokens'),(ROOT/'assets/demo/tokens.css').read_text())
    def test_brand_change_propagates(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'tokens'; shutil.copytree(ROOT/'tokens',path)
            data=json.loads((path/'colors.json').read_text()); data['brand']['primary']['value']='#005A9C'
            (path/'colors.json').write_text(json.dumps(data))
            self.assertIn('--brand-primary: #005A9C;',compile_tokens(path))
    def test_invalid_value_does_not_overwrite_output(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'tokens'; shutil.copytree(ROOT/'tokens',path)
            data=json.loads((path/'colors.json').read_text()); data['brand']['primary']['value']='red; } body {'
            (path/'colors.json').write_text(json.dumps(data))
            target=Path(temp)/'tokens.css'; target.write_text('existing')
            result=subprocess.run([sys.executable,str(ROOT/'scripts/build_tokens.py'),'--tokens-dir',str(path),'--output',str(target)],capture_output=True)
            self.assertEqual(result.returncode,2); self.assertEqual(target.read_text(),'existing')
    def test_missing_group_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'tokens'; shutil.copytree(ROOT/'tokens',path)
            (path/'colors.json').write_text('{}')
            with self.assertRaises(KeyError): compile_tokens(path)
if __name__=='__main__': unittest.main()
