# 来源与证据范围

核对日期：2026-10-09。本轮官方开发文档网页未能读取正文，改查微信小程序官方 GitHub 的 API 类型与注释。仓库 master 会变化，后续应用需再次按基础库与当前文档确认。

## 已核验的技术事实

[微信官方 API 类型与注释](https://github.com/wechat-miniprogram/api-typings/blob/master/types/wx/lib.wx.api.d.ts)：

- WindowInfo 提供以 px 计的窗口/屏幕/状态栏信息；safeArea 在部分设备可能缺失。
- getMenuButtonBoundingClientRect 返回胶囊位置，以屏幕左上角为原点；不能把常量当测量结果。
- SetTabBarItemOption 的 81px 是图片资源建议尺寸，不是 81rpx 的显示标准。
- 存在 hideTabBar 接口，原包“禁止动态隐藏”不是通用 API 限制。
- requirePrivacyAuthorize 可触发隐私弹窗逻辑，注释包含 onLoad 示例和同意/拒绝分支；因此“启动弹窗一律违规”的技术断言不成立。此证据不替代具体产品流程的审核条款。

以上仅简述接口事实，未复刻完整官方文档。

## 资料入口与未核验项

- [app.json 配置](https://developers.weixin.qq.com/miniprogram/dev/reference/configuration/app.html)：原生 tabBar 数量等配置限制，本轮正文未读取，保留待复核状态，不据旧包给出审核结论。
- [窗口信息](https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getWindowInfo.html)、[胶囊坐标](https://developers.weixin.qq.com/miniprogram/dev/api/ui/menu/wx.getMenuButtonBoundingClientRect.html)：正文未读取；本轮技术结论采用上述官方仓库。
- [隐私协议开发指南](https://developers.weixin.qq.com/miniprogram/dev/framework/user-privacy/PrivacyAuthorize.html)：业务合规需要按实际能力重新查证，本轮不声称全面核验。
- [原生 Icon](https://developers.weixin.qq.com/miniprogram/dev/component/icon.html)：本轮正文未读取；组件属性与品牌 Logo 使用限制分开核验，不继承原包一刀切禁止项。
- [腾讯 WeUI](https://github.com/Tencent/weui)：已读取项目说明，作为组件资源入口；不把其网页样式尺寸当全部小程序原生组件标准。

原包字体、圆角、留白和触控数值缺少可追溯条款，本版作为演示建议或移除。浏览器截图仅证明该原型渲染，不证明微信审核通过。
