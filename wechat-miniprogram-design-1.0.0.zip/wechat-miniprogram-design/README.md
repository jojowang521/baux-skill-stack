# 微信小程序设计与适配 1.0.0

入口 SKILL.md，完整目录名 wechat-miniprogram-design。本次未安装或对外发布。

打开 assets/demo/index.html 体验服务首页、工单、表单与详情；gallery.html 提供三屏站点展示。全部为包内 HTML/CSS/JavaScript，无 CDN；示例数据只保存在单个页面内存，刷新恢复。gallery 内三个预览彼此独立。

浏览器容器以 375px 为演示宽度；顶部和底部空间为模拟参数，底部默认 34px，可用 URL 参数 safe=0 检查无底部留白的情况。此值不是平台通用常量。页面未调用 wx API，没有微信授权、支付或真机能力。

原包 wechat-miniprogram-design-skill.zip 未声明 Skill 版本，目标统一为 1.0.0。原始基线保留；修复前后的文件名映射在 references/filename-mapping.json。作者、Skill 许可证及仓库未声明，本轮不推断授权。

来源核验有边界，见 references/sources.md；交互、视口与评测状态见 references/validation-report.md。演示输入和预览图随包提供。
