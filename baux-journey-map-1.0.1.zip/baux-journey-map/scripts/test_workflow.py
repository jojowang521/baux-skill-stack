#!/usr/bin/env python3
"""Behavioral checks for evidence constraints and portable rendering; stdlib only."""
import io
import json
import re
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from render_map import render
from validate_map import ROOT, validate, walk


def load(name="procurement-system.journey.json"):
    return json.loads((ROOT / "data" / name).read_text(encoding="utf-8"))


def brief_fixture():
    data = load()
    data["provenance"]["input_type"] = "brief_only"
    data["task"]["map_state"] = "hypothesis"
    data["stages"] = data["stages"][:1]
    data["branches"] = []
    data["presentation"]["highlighted_stage_ids"] = []
    data["sources"][0].update(type="user_brief", role="user_request", path="brief.txt")
    for obj, _ in walk(data):
        if "evidence_status" in obj:
            obj["evidence_status"] = "design_hypothesis"
        for ref in obj.get("source_refs", []):
            ref.pop("excerpt", None)
            ref["locator"] = "需求第1段"
    data["stages"][0]["emotion"].update(caption=None, caption_kind="not_recorded", score=None, visual_interpretation={"label": None, "status": "not_recorded"})
    return data


class WorkflowTests(unittest.TestCase):
    def test_reference_map_and_simulated_material_are_valid(self):
        self.assertTrue(validate(load("sales-system.journey.json"))["valid"])
        self.assertTrue(validate(load(), ROOT / "data", True)["valid"])

    def test_brief_without_invented_observation_or_emotion_is_valid(self):
        self.assertTrue(validate(brief_fixture())["valid"])

    def test_simulated_observation_cannot_become_real(self):
        data = load()
        data["stages"][0]["activities"][0]["evidence_status"] = "observed"
        self.assertFalse(validate(data)["valid"])

    def test_input_type_change_does_not_hide_simulated_sources(self):
        data = load()
        data["provenance"]["input_type"] = "research_material"
        data["stages"][0]["activities"][0]["evidence_status"] = "reported"
        self.assertFalse(validate(data)["valid"])

    def test_real_claim_requires_source(self):
        data = load()
        data["provenance"]["input_type"] = "research_material"
        data["sources"][0]["role"] = "interview"
        item = data["stages"][0]["activities"][0]
        item.update(evidence_status="reported", source_refs=[])
        self.assertFalse(validate(data)["valid"])

    def test_unresolved_reference_is_rejected(self):
        data = load()
        data["stages"][0]["activities"][0]["source_refs"][0]["source_id"] = "missing"
        self.assertFalse(validate(data)["valid"])

    def test_missing_status_in_new_data_is_rejected(self):
        data = load()
        del data["stages"][0]["pain_points"][0]["evidence_status"]
        self.assertFalse(validate(data)["valid"])

    def test_duplicate_ids_and_orders_are_rejected(self):
        for field in ("id", "order"):
            data = load()
            data["stages"][1][field] = data["stages"][0][field]
            self.assertFalse(validate(data)["valid"])

    def test_broken_branch_and_pain_links_are_rejected(self):
        data = load()
        data["branches"][0]["to_stage_id"] = "missing"
        self.assertFalse(validate(data)["valid"])
        data = load()
        data["stages"][0]["pain_opportunity_relation"]["explicit_item_links"] = [{"pain_id": "missing", "opportunity_id": "missing", "source_refs": []}]
        self.assertFalse(validate(data)["valid"])

    def test_generated_opportunity_is_not_a_fact(self):
        data = load()
        data["stages"][0]["opportunities"][0]["evidence_status"] = "simulated_observation"
        self.assertFalse(validate(data)["valid"])

    def test_missing_emotion_cannot_have_a_score(self):
        data = load()
        data["stages"][4]["emotion"]["score"] = 4
        self.assertFalse(validate(data)["valid"])

    def test_score_requires_valid_scale_and_range(self):
        data = load()
        data["stages"][0]["emotion"]["score"] = 4
        self.assertFalse(validate(data)["valid"])
        data["presentation"]["emotion_axis"]["numeric_scale"] = {"min": 1, "max": 5, "higher_is_better": True, "label": "测试量表"}
        self.assertTrue(validate(data)["valid"])
        data["stages"][0]["emotion"]["score"] = 9
        self.assertFalse(validate(data)["valid"])
        data["stages"][0]["emotion"]["score"] = float("nan")
        self.assertFalse(validate(data)["valid"])

    def test_brief_cannot_invent_numeric_scores(self):
        data = brief_fixture()
        data["stages"][0]["emotion"].update(score=4, visual_interpretation={"label": "愉悦", "status": "hypothesis"})
        data["presentation"]["emotion_axis"]["numeric_scale"] = {"min": 1, "max": 5, "higher_is_better": True, "label": "测试量表"}
        self.assertFalse(validate(data)["valid"])

    def test_quote_must_match_excerpt_and_keep_simulated_label(self):
        data = load()
        data["stages"][0]["emotion"]["caption"] = "这句原话不存在"
        self.assertFalse(validate(data)["valid"])
        data = load()
        data["stages"][0]["emotion"]["caption_kind"] = "participant_quote"
        self.assertFalse(validate(data)["valid"])

    def test_source_checker_detects_changed_excerpt(self):
        data = load()
        data["stages"][0]["activities"][0]["source_refs"][0]["excerpt"] = "不存在的原文"
        self.assertFalse(validate(data, ROOT / "data", True)["valid"])

    def test_missing_source_warns_without_claiming_verification(self):
        data = load()
        data["sources"][0]["path"] = "/does-not-exist/source.txt"
        result = validate(data, ROOT / "data", True)
        self.assertTrue(result["valid"])
        self.assertTrue(result["warnings"])

    def test_unknown_row_is_not_silently_dropped(self):
        data = load()
        data["presentation"]["rows"][0]["key"] = "unsupported"
        self.assertFalse(validate(data)["valid"])

    def test_payload_cannot_escape_script_element(self):
        data = load()
        data["overview"]["title"] = '</script><script>window.UNSAFE=true</script> & "'
        with tempfile.TemporaryDirectory() as directory:
            src, dest = Path(directory) / "map.json", Path(directory) / "map.html"
            src.write_text(json.dumps(data, ensure_ascii=False))
            with redirect_stdout(io.StringIO()):
                render(src, dest)
            html = dest.read_text()
            payload = re.search(r'<script id="journey-data" type="application/json">(.*?)</script>', html, re.S).group(1)
            self.assertEqual(json.loads(payload), data)
            self.assertNotIn(data["overview"]["title"], html)

    def test_invalid_data_does_not_overwrite_existing_html(self):
        data = load()
        data["stages"] = []
        with tempfile.TemporaryDirectory() as directory:
            src, dest = Path(directory) / "map.json", Path(directory) / "map.html"
            src.write_text(json.dumps(data))
            dest.write_text("existing output")
            with self.assertRaises(ValueError):
                render(src, dest)
            self.assertEqual(dest.read_text(), "existing output")

    def test_render_does_not_overwrite_source_json(self):
        with tempfile.TemporaryDirectory() as directory:
            src = Path(directory) / "map.json"
            text = json.dumps(load())
            src.write_text(text)
            with self.assertRaises(ValueError):
                render(src, src)
            self.assertEqual(src.read_text(), text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
