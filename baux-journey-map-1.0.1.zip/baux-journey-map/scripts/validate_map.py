#!/usr/bin/env python3
"""Validate the bundled journey contract and evidence invariants; stdlib only."""
import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT_TYPES = {"research_material", "structured_notes", "existing_map_image", "brief_only", "simulated_research_material"}
STATUSES = {"observed", "reported", "analyst_inference", "design_hypothesis", "reference_transcription", "simulated_observation", "analysis_from_simulated_material"}
ROWS = {"summary", "stages", "user_goals", "activities", "touchpoints", "emotion", "pain_points_and_opportunities"}
LEVELS = {"愉悦", "偏愉悦", "中性", "中性附近", "偏低落", "低落"}


def walk(value, path="$"):
    if isinstance(value, dict):
        yield value, path
        for key, child in value.items():
            yield from walk(child, f"{path}.{key}")
    elif isinstance(value, list):
        for i, child in enumerate(value):
            yield from walk(child, f"{path}[{i}]")


def schema_errors(value, rule, path, errors):
    predicates = {
        "object": lambda v: isinstance(v, dict), "array": lambda v: isinstance(v, list),
        "string": lambda v: isinstance(v, str), "null": lambda v: v is None,
        "number": lambda v: type(v) in (int, float) and math.isfinite(v),
        "integer": lambda v: type(v) is int, "boolean": lambda v: type(v) is bool,
    }
    kinds = rule.get("type", [])
    if isinstance(kinds, str):
        kinds = [kinds]
    if kinds and not any(predicates[k](value) for k in kinds):
        errors.append(f"{path}: 类型必须为 {kinds}")
        return
    if "enum" in rule and value not in rule["enum"]:
        errors.append(f"{path}: 不支持的取值 {value!r}")
    if isinstance(value, dict):
        for key in rule.get("required", []):
            if key not in value:
                errors.append(f"{path}.{key}: 缺少必填字段")
        for key, child_rule in rule.get("properties", {}).items():
            if key in value:
                schema_errors(value[key], child_rule, f"{path}.{key}", errors)
    elif isinstance(value, list):
        if len(value) < rule.get("minItems", 0):
            errors.append(f"{path}: 条目不足")
        for i, child in enumerate(value):
            schema_errors(child, rule.get("items", {}), f"{path}[{i}]", errors)
    elif isinstance(value, str):
        if len(value) < rule.get("minLength", 0):
            errors.append(f"{path}: 文本为空")
    elif type(value) in (int, float):
        for key, valid in [("minimum", lambda x: value >= x), ("maximum", lambda x: value <= x)]:
            if key in rule and not valid(rule[key]):
                errors.append(f"{path}: 超出数值范围")


def validate(data, base_dir=None, check_sources=False):
    errors, warnings = [], []
    schema = json.loads((ROOT / "data/journey-map.schema.json").read_text(encoding="utf-8"))
    schema_errors(data, schema, "$", errors)
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings}
    sources = {s["id"]: s for s in data["sources"]}
    stages = {s["id"]: s for s in data["stages"]}
    seen = set()
    for value, path in walk(data):
        if "id" in value:
            if not value["id"] or value["id"] in seen:
                errors.append(f"{path}.id: ID 为空或重复")
            seen.add(value["id"])
        for ref in value.get("source_refs", []):
            if ref["source_id"] not in sources:
                errors.append(f"{path}: 引用了不存在的来源 {ref['source_id']}")
            if not ref["locator"].strip():
                errors.append(f"{path}: 来源定位为空")

    mode = data["provenance"]["input_type"]
    if mode not in INPUT_TYPES:
        errors.append("provenance.input_type: 未知输入类型")
    if data["schema_version"] not in {"0.1.0", "0.2.0", "0.3.0"}:
        errors.append("schema_version: 不支持的版本")
    modern = data["schema_version"] == "0.3.0"
    if modern and "task" not in data:
        errors.append("task: 新版本必须注明角色、场景和旅程范围")
    if mode in {"brief_only", "simulated_research_material"} and data["provenance"]["research_validation_status"] != "not_verified":
        errors.append("假设或模拟材料不能标记为研究已验证")
    if mode == "brief_only" and data.get("task", {}).get("map_state") != "hypothesis":
        errors.append("一句话需求生成的地图必须使用 hypothesis 状态")
    if mode == "simulated_research_material" and any(s["role"] != "simulated_research_material" for s in sources.values()):
        errors.append("模拟入口的来源必须保留 simulated_research_material 标记")
    if data.get("task", {}).get("primary_role") != data["summary"]["persona"]["role"] and "task" in data:
        errors.append("task.primary_role 与用户画像角色不一致")

    orders = [s["order"] for s in data["stages"]]
    if len(set(orders)) != len(orders):
        errors.append("stages.order: 阶段顺序重复")
    for stage in data["stages"]:
        if not stage["source_refs"]:
            warnings.append(f"{stage['id']}: 阶段缺少来源，需说明划分依据")
        for key in ("activities", "pain_points", "opportunities"):
            for item in stage[key]:
                status = item.get("evidence_status")
                if status is None and not modern:
                    warnings.append(f"{item['id']}: 旧数据未标记证据状态")
                    continue
                if status not in STATUSES:
                    errors.append(f"{item['id']}: 缺少或未知 evidence_status")
                refs = item["source_refs"]
                ref_sources = [sources[r["source_id"]] for r in refs if r["source_id"] in sources]
                simulated = any(s["role"] == "simulated_research_material" for s in ref_sources)
                brief = any(s["type"] == "user_brief" for s in ref_sources)
                reference = any(s["role"] == "reference_map" for s in ref_sources)
                if not refs and status != "design_hypothesis":
                    errors.append(f"{item['id']}: 该证据状态需要来源")
                if not refs and status == "design_hypothesis":
                    warnings.append(f"{item['id']}: 设计假设没有引用依据")
                if status in {"observed", "reported"} and (mode in {"brief_only", "simulated_research_material", "existing_map_image"} or simulated or brief or reference):
                    errors.append(f"{item['id']}: 假设、模拟或地图转录不能冒充真实观察/报告")
                if simulated and status not in {"simulated_observation", "analysis_from_simulated_material", "design_hypothesis"}:
                    errors.append(f"{item['id']}: 模拟来源必须保留模拟状态")
                if key == "opportunities" and status not in {"design_hypothesis", "reference_transcription"}:
                    errors.append(f"{item['id']}: 机会点必须标记为设计假设或原图转录")
        pain_ids = {x["id"] for x in stage["pain_points"]}
        opportunity_ids = {x["id"] for x in stage["opportunities"]}
        for link in stage["pain_opportunity_relation"]["explicit_item_links"]:
            if link["pain_id"] not in pain_ids or link["opportunity_id"] not in opportunity_ids:
                errors.append(f"{stage['id']}: 痛点/机会关联不存在或不属于该阶段")

        emotion = stage["emotion"]
        interpretation = emotion["visual_interpretation"]
        label, score = interpretation["label"], emotion["score"]
        if label is not None and label not in LEVELS:
            errors.append(f"{stage['id']}: 不支持的定性情绪标签")
        if (label is not None or score is not None) and not emotion["source_refs"]:
            errors.append(f"{stage['id']}: 情绪结论缺少依据")
        if interpretation["status"] == "not_recorded" and (label is not None or score is not None):
            errors.append(f"{stage['id']}: 未记录情绪却填写了标签/评分")
        if mode == "brief_only" and (label is not None or score is not None) and interpretation["status"] != "hypothesis":
            errors.append(f"{stage['id']}: 无研究材料的情绪必须留空或标为假设")
        if mode == "brief_only" and score is not None:
            errors.append(f"{stage['id']}: 不得依据一句话需求生成量化情绪评分")
        if score is not None and any(sources.get(r["source_id"], {}).get("type") == "user_brief" for r in emotion["source_refs"]):
            errors.append(f"{stage['id']}: 用户需求不能作为量化情绪评分的证据")
        if emotion["caption_kind"] in {"participant_quote", "simulated_participant_quote"}:
            excerpts = [r.get("excerpt", "") for r in emotion["source_refs"]]
            if not emotion["caption"] or not any(emotion["caption"] in text for text in excerpts):
                errors.append(f"{stage['id']}: 引语必须是所引材料摘录中的原文")
            if emotion["caption_kind"] == "participant_quote":
                inappropriate = any(sources.get(r["source_id"], {}).get("role") in {"simulated_research_material", "reference_map"} or sources.get(r["source_id"], {}).get("type") == "user_brief" for r in emotion["source_refs"])
                if mode in {"brief_only", "simulated_research_material", "existing_map_image"} or inappropriate:
                    errors.append(f"{stage['id']}: 模拟、需求或参考地图文字不是核实过的真实访谈原话")

    scale = data["presentation"]["emotion_axis"]["numeric_scale"]
    if scale is not None and scale["min"] >= scale["max"]:
        errors.append("emotion_axis.numeric_scale: min 必须小于 max")
    for stage in data["stages"]:
        score = stage["emotion"]["score"]
        if score is not None and (scale is None or not scale["min"] <= score <= scale["max"]):
            errors.append(f"{stage['id']}: 情绪评分缺少量表或超出量表范围")
    keys = [r["key"] for r in data["presentation"]["rows"]]
    if len(set(keys)) != len(keys) or any(k not in ROWS for k in keys):
        errors.append("presentation.rows: 行重复或使用了未实现的模块")
    for sid in data["presentation"]["highlighted_stage_ids"]:
        if sid not in stages:
            errors.append(f"presentation: 强调阶段 {sid} 不存在")
    for branch in data.get("branches", []):
        if branch["from_stage_id"] not in stages or branch["to_stage_id"] not in stages:
            errors.append(f"{branch['id']}: 返回路径引用了不存在的阶段")
    if not data["sources"]:
        errors.append("sources: 至少需要用户需求或材料作为来源")
    if check_sources:
        check_text_sources(data, sources, Path(base_dir or "."), errors, warnings)
    return {"valid": not errors, "errors": errors, "warnings": sorted(set(warnings)), "counts": {"stages": len(stages), "activities": sum(len(s["activities"]) for s in stages.values()), "pain_points": sum(len(s["pain_points"]) for s in stages.values()), "opportunities": sum(len(s["opportunities"]) for s in stages.values())}}


def check_text_sources(data, sources, base_dir, errors, warnings):
    texts = {}
    for sid, source in sources.items():
        path = Path(source["path"])
        path = path if path.is_absolute() else base_dir / path
        if not path.is_file():
            warnings.append(f"{sid}: 来源原件不可用，未核验摘录")
        elif path.suffix.lower() not in {".txt", ".md", ".csv", ".json"}:
            warnings.append(f"{sid}: 非文本来源，需要人工核验")
        else:
            try:
                texts[sid] = path.read_text(encoding="utf-8")
            except (OSError, UnicodeError):
                warnings.append(f"{sid}: 无法读取 UTF-8 文本，需要人工核验")
    checked = set()
    for value, _ in walk(data):
        for ref in value.get("source_refs", []):
            key = (ref["source_id"], ref.get("excerpt"))
            if key in checked:
                continue
            checked.add(key)
            if key[0] in texts and key[1] and key[1] not in texts[key[0]]:
                errors.append(f"{key[0]} · {ref['locator']}: 摘录未在来源原文中找到")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--check-sources", action="store_true")
    args = parser.parse_args()
    try:
        data = json.loads(args.source.read_text(encoding="utf-8"))
        report = validate(data, args.source.parent, args.check_sources)
    except (OSError, ValueError) as error:
        report = {"valid": False, "errors": [str(error)], "warnings": []}
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["valid"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
