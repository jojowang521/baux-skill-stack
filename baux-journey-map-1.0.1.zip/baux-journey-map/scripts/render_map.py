#!/usr/bin/env python3
"""Render a journey JSON into a portable, offline HTML file.

Usage: python3 scripts/render_map.py data/sales-system.journey.json -o output/sales-system.html
"""
import argparse
import json
from pathlib import Path
from validate_map import validate


def render(source: Path, destination: Path) -> None:
    if source.resolve() == destination.resolve():
        raise ValueError("HTML 输出路径不能覆盖输入 JSON。")
    data = json.loads(source.read_text(encoding="utf-8"))
    report = validate(data, source.parent)
    if not report["valid"]:
        raise ValueError("数据校验未通过：\n" + "\n".join(report["errors"]))
    for warning in report["warnings"]:
        print(f"提示：{warning}")
    stages = data.get("stages", [])
    if not stages:
        raise ValueError("至少需要一个阶段。")
    ids = [stage["id"] for stage in stages]
    if len(ids) != len(set(ids)):
        raise ValueError("阶段 ID 不能重复。")
    orders = [stage["order"] for stage in stages]
    if len(orders) != len(set(orders)):
        raise ValueError("阶段顺序不能重复。")
    template = Path(__file__).resolve().parents[1] / "assets" / "journey-template.html"
    payload = json.dumps(data, ensure_ascii=False).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    html = template.read_text(encoding="utf-8").replace("__JOURNEY_DATA__", payload)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(html, encoding="utf-8")
    print(f"已生成：{destination.resolve()}（{len(stages)} 个阶段）")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("-o", "--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        render(args.source, args.output)
    except (OSError, ValueError) as error:
        parser.exit(2, f"{error}\n")
