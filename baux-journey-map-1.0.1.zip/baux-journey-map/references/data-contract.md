# 数据契约 v0.3

完整结构见 `../data/journey-map.schema.json`，现成可运行样例见 `../data/`。数组长度不固定，可只启用有用的展示行。字段名称继续兼容 v0.1/v0.2；新建数据使用 v0.3.0。

## 顶层

| 字段 | 含义 |
| --- | --- |
| schema_version / map_id / language | 版本、稳定标识、语言；默认 zh-CN |
| task | 主角色、场景、起终点、分析目的、地图状态、已采用假设 |
| provenance | 输入类型、内容状态、研究验证状态、说明和规范化规则 |
| sources | 来源 ID、类型、显示文件名、路径、角色、定位方法 |
| overview | 标题、副标题、地图类型、愿景；愿景是编辑性表述或设计假设 |
| summary | 角色、总体目标、使用情境、核心问题、改善方向 |
| stages | 阶段数组，按唯一的正整数 order 排序 |
| branches | 可选的阶段返回路径，含条件、方向及来源 |
| presentation | 展示行、强调阶段、情绪轴；不作为研究事实 |
| missing_information | 缺失信息或待确认项，不用空白补造结论 |

`task.map_state` 可为 `current_state`、`future_state`、`hypothesis`。`task` 包含 `primary_role`、`scenario`、`start`、`end`、`purpose`、`assumptions`（字符串数组）。

`provenance.input_type`：`research_material`、`structured_notes`、`existing_map_image`、`brief_only`、`simulated_research_material`。研究验证状态填写 `not_verified` 或 `source_grounded`；后者只表示已核对来源，不表示研究覆盖所有人或独立实证验证。

## 阶段与状态

每阶段需要 `id`、`order`、`name`、`source_refs`、`user_goal`、`activities`、`touchpoints`、`emotion`、`pain_points`、`opportunities`、`pain_opportunity_relation`。没有行为或痛点可用空数组；没有目标用 null。

行为、痛点、机会条目包含 `id`、`text`、`source_refs`、`evidence_status`。状态语义：

| 状态 | 用途 |
| --- | --- |
| observed | 真实观察材料中记录的行为/现象 |
| reported | 真实受访者或反馈者的报告；不是独立证实 |
| analyst_inference | 根据来源归纳的分析判断 |
| design_hypothesis | 待验证的拟议方案或假设 |
| reference_transcription | 忠实转录已有地图/稿件 |
| simulated_observation | 合成材料中的行为或陈述 |
| analysis_from_simulated_material | 从模拟材料归纳的判断 |

机会点使用 `design_hypothesis`；复刻已有地图的机会可用 `reference_transcription`。一句话需求的行为/痛点使用 `analyst_inference` 或 `design_hypothesis`。没有来源不能使用 `observed` 或 `reported`。

`goal_status` 对推断目标使用 `analyst_inference` 或 `analyst_inference_from_simulated_material`；没有目标可不填。

## 来源引用

`source_refs` 中每项包含 `source_id`、`locator`，可包含 `excerpt`（逐字摘录）。引用可指向材料编号、段落、页码或时间戳，不允许虚构位置。来源文件路径相对于当前数据文件目录解析；读取文本检查仅限显式列出的来源，不沿文档链接寻找其他私有文件。

纯用户需求可作为 `sources.type: user_brief`，输入文字保存为任务目录下文本文件，并引用段落。它是构造假设的依据，不是行为发生的证据。模拟来源的 role 使用 `simulated_research_material`，图片转录来源使用 `reference_map`。

对多个材料共同支持的判断，引用多个来源；真实与模拟材料混合时，真实结论只能由真实材料支持。必要时拆成独立地图。

## 情绪

`emotion` 包含 `caption`（文字或 null）、`caption_kind`、`score`（数字或 null）、`visual_interpretation`、`source_refs`。

`caption_kind`：`participant_quote`（真实原话）、`simulated_participant_quote`、`map_caption_not_verified_participant_quote`、`analyst_summary`、`not_recorded`。真实原话需要可核对的摘录；摘要不加引号伪装原话。

为保持现有模型兼容，定性解释仍使用 `visual_interpretation` 字段；`label` 支持“愉悦、偏愉悦、中性、中性附近、偏低落、低落”或 null。`status` 可用 `inferred_from_chart`、`inferred_from_reported_text`、`inferred_from_simulated_text`、`hypothesis`、`not_recorded`。情绪为假设时，应在页面可见地标明；默认无资料就留空。

若有源材料明确的数值，`presentation.emotion_axis.numeric_scale` 必须包含 `min`、`max`、`higher_is_better`、`label`（量表名称），范围满足 min < max；每个非空 score 都需来源。数值点按量表绘制；缺失数值不混用定性坐标。质性解释仍可保留在详情，但不代替数值。

## 展示与关系

`presentation.rows[].key` 支持 `summary`、`stages`、`user_goals`、`activities`、`touchpoints`、`emotion`、`pain_points_and_opportunities`。不要用未知 key；要增加模块应同步实现模板。

强调阶段只表示视觉强调；解释写在 `highlight_meaning`，不能凭颜色声称业务优先级。

`branches` 引用已有阶段 ID，主图显示“含返回路径”，详情显示条件及去向。返回路径不是完整流程图替代品。

`pain_opportunity_relation.explicit_item_links` 为空表示未逐条建立关系。非空项包含 `pain_id`、`opportunity_id`、`source_refs`；可附 `basis` 区分原文关系与分析者假设。跨阶段关系应在相关阶段说明，不可引用不存在的条目。

## 校验边界

校验器覆盖本仓库 Schema 用到的类型、必填、枚举、数组长度与数值边界，以及 ID、引用、证据状态、情绪和路径的语义约束；不是通用 JSON Schema 引擎。文本检查只核实摘录是否出现在来源文件中，不能判定概括、因果或研究方法是否正确。每次输出仍需人工审核。
