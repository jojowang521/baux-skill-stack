# 体验验收回归检查

这个包由 `dispatch.mjs` 从迭代台账生成，给研发在修复后自己回归。

## 用法
1. `npm install`（会装 playwright；首次需 `npx playwright install chromium`）
2. 打开 `selectors.json`，按每个槽位的中文说明填真实选择器（优先 `[data-testid='…']`）。没填的检查会显示“未执行”，不会算通过。
3. 打开 `regression.config.json`，给 `pages` 里每个页面名填本地访问路径或完整 HTTP(S) 测试网址，`{variant}` 会被 `--variant` 的值替换。
4. `node run.mjs` 或 `node run.mjs --variant fixed`；`--only F-020` 只跑一个问题；`--repeat` 连跑三次确认结果稳定。
5. 结果在 `reports/`，有 JSON、HTML 和截图。

## 结果含义
- passed：符合验收标准；failed：页面明确违反标准；notRun：选择器或页面地址没配；error：检查本身没跑完（不算通过也不算失败）。
- 退出码：0 全部通过；1 有失败或执行错误；2 有未执行项。

## 边界
自动检查只证明“这条验收标准在这次运行里成立”。通过不等于已验收，是否关单仍由设计、产品回验决定。

## 报告有效范围

真实环境请在 `target.version` 填提交号或部署版本，或运行 `node run.mjs --target-version <版本>`。演示可用 `--variant fixed` 标记变体。报告记录被测版本、规则指纹及修复轮次；版本信息由运行人提供，不自动证明环境身份。

报告中少了同一问题的某项检查，会记为未执行。旧轮次、旧规则和旧版无契约报告不能作为本轮验收依据。修复被退回或方案变化后，须更新分发包并重新回归。
