import test from 'node:test';
import assert from 'node:assert/strict';
import { resolvePageUrl, reportExitCode, summarize, selectorWarning, stable } from './semantics.mjs';
test('失败、执行错误、未执行都不会以 0 退出', () => {
  for (const [summary, want] of [[{ failed: 0, error: 0, notRun: 0 }, 0], [{ failed: 1, error: 0, notRun: 0 }, 1], [{ failed: 0, error: 1, notRun: 0 }, 1], [{ failed: 0, error: 0, notRun: 1 }, 2], [{ failed: 1, error: 0, notRun: 1 }, 1]]) assert.equal(reportExitCode({ summary }), want);
});
test('汇总按状态计数', () => {
  const s = summarize([{ status: 'passed' }, { status: 'failed' }, { status: 'notRun' }, { status: 'error' }]);
  assert.deepEqual([s.passed, s.failed, s.notRun, s.error, s.passRate], [1, 1, 1, 1, 0.25]);
});
test('框架生成的类名会被提醒', () => {
  assert.ok(selectorWarning('.ant-btn-primary'));
  assert.ok(selectorWarning('.css-1x2y3z'));
  assert.equal(selectorWarning("[data-testid='save-btn']"), null);
});
test('重复运行结果一致才算稳定', () => {
  const run = status => ({ results: [{ ruleId: 'a', status, expected: 'e', actual: 'x' }] });
  assert.equal(stable([run('passed'), run('passed')]), true);
  assert.equal(stable([run('passed'), run('failed')]), false);
});


test('页面地址：相对路径与绝对 HTTP(S) 地址分别解析', () => {
  assert.equal(resolvePageUrl('/app.html#orders', 'http://127.0.0.1:1234'), 'http://127.0.0.1:1234/app.html#orders');
  assert.equal(resolvePageUrl('app.html?v={variant}', 'http://127.0.0.1:1234', 'a b'), 'http://127.0.0.1:1234/app.html?v=a%20b');
  assert.equal(resolvePageUrl('https://test.example.com/app.html#orders', 'http://127.0.0.1:1234'), 'https://test.example.com/app.html#orders');
  assert.equal(resolvePageUrl('http://127.0.0.1:9999/app.html', 'http://127.0.0.1:1234'), 'http://127.0.0.1:9999/app.html');
  assert.throws(() => resolvePageUrl('javascript:alert(1)', 'http://127.0.0.1:1234'), /http/);
});
