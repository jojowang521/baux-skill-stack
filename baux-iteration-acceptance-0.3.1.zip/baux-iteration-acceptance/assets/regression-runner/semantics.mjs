// 状态语义沿用 page-quality-validator：
//   passed 通过；failed 页面明确违反预期；notRun 前置条件没配齐，不计为通过；error 执行本身出了问题，不计为通过也不计为失败。
export const reportExitCode = report => { const s = report.summary; return s.error || s.failed ? 1 : s.notRun ? 2 : 0; };
export function summarize(results) {
  const summary = { totalRules: results.length, passed: 0, failed: 0, notRun: 0, error: 0, passRate: 0 };
  for (const result of results) summary[result.status] += 1;
  summary.passRate = summary.totalRules ? summary.passed / summary.totalRules : 0;
  return summary;
}
const SUSPECT = [/\.ant-/, /\.css-[a-z0-9]+/i, /\.el-/, /\.Mui[A-Z]/, /\.[a-z]+_[a-z0-9]{5,}(\s|$|\.)/i];
/** 框架生成的类名容易随版本变化，提醒改用 data-testid 或语义角色。 */
export const selectorWarning = selector => SUSPECT.some(pattern => pattern.test(selector)) ? `选择器 ${selector} 像是框架自动生成的类名，建议改用 data-testid` : null;
export const stable = reports => {
  const key = report => report.results.map(r => `${r.ruleId}|${r.status}|${r.expected}|${r.actual}`).join('\n');
  return reports.every(report => key(report) === key(reports[0]));
};

/** Resolve local routes and absolute HTTP(S) test environments without concatenating URLs. */
export function resolvePageUrl(template, baseUrl, variant = '') {
  const url = new URL(String(template).replaceAll('{variant}', encodeURIComponent(variant)), baseUrl + '/');
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('页面地址仅支持 http(s) 或本地相对路径');
  return url.href;
}
