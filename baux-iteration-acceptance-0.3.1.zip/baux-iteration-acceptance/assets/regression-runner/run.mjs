// 回归运行器：执行 rules.json 里由“验收标准”生成的自动检查。
// 用法：node run.mjs [--variant 名称] [--only F-020] [--out 报告名] [--repeat]
// 退出码：0 全部通过；1 有失败或执行错误；2 有未执行项（选择器或页面地址没配齐）。
import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { extname, join, normalize, relative, resolve, sep } from 'node:path';
import { chromium } from 'playwright';
import { compareValues, parseNum } from './lib.mjs';
import { reportExitCode, selectorWarning, stable, summarize, resolvePageUrl } from './semantics.mjs';

const root = import.meta.dirname;
const readJson = async name => JSON.parse(await readFile(resolve(root, name), 'utf8'));
const args = process.argv.slice(2);
const opt = name => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const variant = opt('--variant') ?? ''; const only = opt('--only'); const outName = opt('--out') ?? 'regression-report';
const config = await readJson('regression.config.json'); const selectorsFile = await readJson('selectors.json'); const rulesFile = await readJson('rules.json');
const rules = rulesFile.rules.filter(rule => !only || rule.id.startsWith(only));
const targetVersion = String(opt('--target-version') ?? config.target?.version ?? (variant ? `variant:${variant}` : '')).trim();
if (!targetVersion) { console.error('请填写 target.version 或 --target-version；模拟示例可使用 --variant'); process.exit(2); }
if (!rules.length) { console.error('没有匹配的回归检查，请核对 --only 与 rules.json'); process.exit(2); }
const reportDir = resolve(root, 'reports');
const viewport = config.viewport ?? { width: 1440, height: 900 };
const timeoutMs = config.timeoutMs ?? 8000; const stepTimeoutMs = config.stepTimeoutMs ?? 3000;
const settleMs = config.settleMs ?? 600; const mockDelayMs = config.mockDelayMs ?? 800;
const contentTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };
const sleep = ms => new Promise(done => setTimeout(done, ms));
const filled = value => typeof value === 'string' && value.trim().length > 0;

function serve(directory) {
  const staticRoot = resolve(directory);
  const server = createServer(async (request, response) => {
    let pathname; try { pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://localhost').pathname); } catch { return void response.writeHead(400).end(); }
    const path = normalize(join(staticRoot, pathname));
    if (!path.startsWith(`${staticRoot}${sep}`)) return void response.writeHead(403).end();
    let body; try { body = await readFile(path); } catch { return void response.writeHead(404).end(); }
    response.writeHead(200, { 'content-type': contentTypes[extname(path)] ?? 'application/octet-stream' }).end(body);
  });
  return new Promise((ok, fail) => { server.once('error', fail); server.listen(0, '127.0.0.1', () => ok(server)); });
}

class ExpectFailed extends Error {}

async function execute(browser, rule, baseUrl, runId) {
  const started = Date.now(); const spec = rule.spec ?? {};
  const result = { ruleId: rule.id, round: rule.round, fingerprint: rule.fingerprint, findingId: rule.findingId, acceptance: rule.acceptance, name: `${rule.title}：${rule.acceptanceText}`, severity: rule.severity, kind: rule.kind, status: 'error', expected: rule.expectedText, actual: '', durationMs: 0, evidence: {} };
  const slotMap = selectorsFile[rule.id] ?? {};
  const missing = Object.keys(rule.slots).filter(name => !filled(slotMap[name]));
  const template = config.pages?.[rule.page];
  if (missing.length || !filled(template)) {
    result.status = 'notRun';
    result.actual = missing.length ? `未配置选择器：${missing.map(name => `${name}（${rule.slots[name]}）`).join('、')}` : `页面「${rule.page}」没有配置访问地址`;
    return result;
  }
  let url;
  try { url = resolvePageUrl(template, baseUrl, variant); } catch (error) { result.errorMessage = error.message; result.actual = '页面地址无效'; return result; }
  result.evidence.url = url; result.evidence.selectors = slotMap;
  const warnings = Object.values(slotMap).map(selectorWarning).filter(Boolean); if (warnings.length) result.evidence.selectorWarnings = warnings;
  const context = await browser.newContext({ viewport, reducedMotion: spec.reducedMotion ? 'reduce' : 'no-preference' });
  const page = await context.newPage(); const requests = []; page.on('request', request => requests.push(request.url()));
  const sel = name => slotMap[name]; const hint = name => rule.slots[name] ?? name;
  const first = name => page.locator(sel(name)).first();
  try {
    for (const pattern of rule.mock ?? []) await page.route(`**${pattern}*`, async route => { await sleep(mockDelayMs); await route.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' }); });
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: timeoutMs });

    if (rule.kind === 'style' || rule.kind === 'transition') {
      const target = first('$target');
      try { await target.waitFor({ state: 'attached', timeout: stepTimeoutMs }); } catch { throw new Error(`选择器没有匹配到「${hint('$target')}」，请检查 selectors.json`); }
      if (spec.state === 'hover') { await target.hover(); await sleep(settleMs); }
      if (spec.state === 'focus') { await target.focus(); await sleep(settleMs); }
      const handles = rule.kind === 'style' && spec.all ? await page.locator(sel('$target')).all() : [target];
      const dimension = rule.dimension; const lines = []; let failed = 0;
      for (const [index, handle] of handles.entries()) {
        let actual;
        if (rule.kind === 'style') actual = await handle.evaluate((el, property) => { if (property === 'height' || property === 'width') return Math.round(el.getBoundingClientRect()[property] * 100) / 100 + 'px'; return getComputedStyle(el)[property]; }, spec.property);
        else {
          const info = await handle.evaluate(el => { const style = getComputedStyle(el); return { properties: style.transitionProperty, durations: style.transitionDuration }; });
          const properties = info.properties.split(',').map(s => s.trim()); const durations = info.durations.split(',').map(s => s.trim());
          const at = properties.findIndex(p => p === spec.property || p === 'all'); const raw = at < 0 ? '0s' : durations[at % durations.length];
          const parsed = parseNum(raw); actual = parsed ? `${parsed.n}ms` : raw;
        }
        const compared = compareValues(dimension, spec.expected, actual, { tolerance: rulesFile.tolerance });
        if (!compared.within) failed += 1;
        lines.push(`${handles.length > 1 ? `第 ${index + 1} 个：` : ''}${actual}${compared.within ? '' : `（期望 ${spec.expected}，偏差 ${compared.delta}）`}`);
      }
      result.status = failed ? 'failed' : 'passed';
      result.actual = lines.join('；');
      result.evidence.additional = { property: spec.property, expected: spec.expected, state: spec.state ?? null, checked: handles.length, failed };
    } else if (rule.kind === 'focus') {
      const target = first('$target');
      try { await target.waitFor({ state: 'attached', timeout: stepTimeoutMs }); } catch { throw new Error(`选择器没有匹配到「${hint('$target')}」，请检查 selectors.json`); }
      const readStyle = el => { const s = getComputedStyle(el); return { outline: `${s.outlineStyle} ${s.outlineWidth}`, boxShadow: s.boxShadow, borderColor: s.borderTopColor, background: s.backgroundColor }; };
      const before = await target.evaluate(readStyle); let focused = false;
      for (let i = 0; i < 40 && !focused; i += 1) { await page.keyboard.press('Tab'); focused = await target.evaluate(el => el === document.activeElement); }
      if (!focused) { result.status = 'failed'; result.actual = '按 Tab 键 40 次内没有聚焦到该元素'; }
      else {
        const after = await target.evaluate(readStyle); const changed = Object.keys(before).filter(key => before[key] !== after[key]);
        result.status = changed.length ? 'passed' : 'failed';
        result.actual = changed.length ? `聚焦后样式变化：${changed.join('、')}（outline ${after.outline}）` : `聚焦后没有任何可见的样式变化（outline ${after.outline}）`;
        result.evidence.additional = { before, after };
      }
    } else if (rule.kind === 'flow') {
      const log = [];
      const numeric = (n, expect) => (typeof expect.eq === 'number' ? n === expect.eq : true) && (typeof expect.lte === 'number' ? n <= expect.lte : true) && (typeof expect.gte === 'number' ? n >= expect.gte : true);
      const describeNum = expect => [typeof expect.eq === 'number' && `等于 ${expect.eq}`, typeof expect.lte === 'number' && `不超过 ${expect.lte}`, typeof expect.gte === 'number' && `不少于 ${expect.gte}`].filter(Boolean).join('，');
      const present = async name => (await page.locator(sel(name)).count()) > 0;
      async function check(expect) {
        let ok = false; let text = '';
        if ('visible' in expect) { ok = (await present(expect.visible)) && await first(expect.visible).isVisible(); text = `「${hint(expect.visible)}」可见`; }
        else if ('hidden' in expect) { ok = !(await present(expect.hidden)) || !(await first(expect.hidden).isVisible()); text = `「${hint(expect.hidden)}」不可见`; }
        else if ('count' in expect) { const n = await page.locator(sel(expect.count)).count(); ok = numeric(n, expect); text = `「${hint(expect.count)}」数量 ${n}（要求${describeNum(expect)}）`; }
        else if ('text' in expect) { const actual = (await present(expect.text)) ? ((await first(expect.text).textContent()) ?? '').trim() : null; ok = actual !== null && (expect.equals !== undefined ? actual === expect.equals : actual.includes(expect.contains)); text = `「${hint(expect.text)}」文字为“${actual ?? '元素不存在'}”（要求${expect.equals !== undefined ? '等于' : '包含'}“${expect.equals ?? expect.contains}”）`; }
        else if ('value' in expect) { const actual = (await present(expect.value)) ? await first(expect.value).inputValue() : null; ok = actual === expect.equals; text = `「${hint(expect.value)}」的值为“${actual ?? '元素不存在'}”（要求“${expect.equals}”）`; }
        else if ('disabled' in expect) { ok = (await present(expect.disabled)) && await first(expect.disabled).isDisabled(); text = `「${hint(expect.disabled)}」不可点击`; }
        else if ('enabled' in expect) { ok = (await present(expect.enabled)) && await first(expect.enabled).isEnabled(); text = `「${hint(expect.enabled)}」可点击`; }
        else if ('urlHash' in expect) { const hash = new URL(page.url()).hash; ok = hash === expect.urlHash; text = `页面地址 hash 为 ${hash || '空'}（要求 ${expect.urlHash}）`; }
        else if ('requests' in expect) { const n = requests.filter(u => u.includes(expect.requests)).length; ok = numeric(n, expect); text = `发出 ${expect.requests} 请求 ${n} 次（要求${describeNum(expect)}）`; }
        log.push(`${ok ? '✓' : '✗'} ${text}`);
        if (!ok) throw new ExpectFailed(text);
      }
      async function step(item) {
        const options = { timeout: stepTimeoutMs };
        try {
          if ('fill' in item) await first(item.fill).fill(item.value, options);
          else if ('click' in item) await first(item.click).click({ ...options, force: Boolean(item.force) });
          else if ('hover' in item) await first(item.hover).hover(options);
          else if ('press' in item) await page.keyboard.press(item.press);
          else if ('wait' in item) await page.waitForTimeout(item.wait);
          else if ('repeat' in item) for (let i = 0; i < item.repeat; i += 1) await step(item.do);
          else if ('expect' in item) await check(item.expect);
        } catch (error) {
          if (error instanceof ExpectFailed) throw error;
          const target = item.fill ?? item.click ?? item.hover; if (target && /Timeout/i.test(String(error))) throw new Error(`操作目标「${hint(target)}」不存在或不可见，无法继续。若选择器正确，请在这一步前加一条“应可见”的判断，把缺失记为失败`);
          throw error;
        }
      }
      try { for (const item of spec.steps) await step(item); result.status = 'passed'; }
      catch (error) { if (error instanceof ExpectFailed) result.status = 'failed'; else throw error; }
      result.actual = log.join('；'); result.evidence.additional = { log };
    }
  } catch (error) {
    result.status = 'error'; result.actual = '检查没有执行完'; result.errorMessage = error instanceof Error ? error.message : String(error);
  }
  result.durationMs = Date.now() - started;
  await mkdir(join(reportDir, 'screenshots'), { recursive: true });
  const shot = join(reportDir, 'screenshots', `${runId}-${rule.id.replace('#', '_')}-${result.status}.png`);
  try { await page.screenshot({ path: shot, fullPage: true }); result.evidence.screenshotPath = relative(root, shot); } catch { /* 截图失败不影响结果 */ }
  await context.close();
  return result;
}

function html(report) {
  const esc = v => String(v ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  const rows = report.results.map(r => `<details class="${r.status}"><summary><b>${esc(r.ruleId)}</b> ${esc(r.name)} <span>${esc(r.status)}</span></summary><p><b>期望：</b>${esc(r.expected)}</p><p><b>实际：</b>${esc(r.actual)}</p>${r.errorMessage ? `<p><b>错误：</b>${esc(r.errorMessage)}</p>` : ''}<p><b>页面：</b>${esc(r.evidence.url ?? '')}</p><pre>${esc(JSON.stringify({ selectors: r.evidence.selectors, selectorWarnings: r.evidence.selectorWarnings, ...r.evidence.additional }, null, 2))}</pre>${r.evidence.screenshotPath ? `<img src="${esc(r.evidence.screenshotPath.replace(/^reports\//, ''))}">` : ''}</details>`).join('');
  const s = report.summary;
  return `<!doctype html><meta charset="utf-8"><title>回归检查报告</title><style>body{font:14px system-ui;margin:32px;background:#f5f8fb;color:#17233a}header,details{max-width:1100px;margin:0 auto 12px;background:#fff;border:1px solid #dce4ed;padding:16px}.kpis{display:flex;gap:16px;flex-wrap:wrap}.kpis b{font-size:24px;display:block}.passed{border-left:4px solid #17834c}.failed{border-left:4px solid #b93030}.error{border-left:4px solid #743d9c}.notRun{border-left:4px solid #a96b08}summary{cursor:pointer}span{margin-left:8px}pre{white-space:pre-wrap;max-height:200px;overflow:auto;background:#f6f8fa;padding:10px}img{max-width:100%;border:1px solid #ddd}</style><header><h1>回归检查报告</h1><p>${esc(report.meta.variant || '默认页面')} · ${esc(report.meta.generatedAt)} · ${report.meta.durationMs}ms · token ${esc(report.meta.tokenSet)}</p><div class="kpis"><div><small>总数</small><b>${s.totalRules}</b></div><div><small>通过</small><b>${s.passed}</b></div><div><small>失败</small><b>${s.failed}</b></div><div><small>未执行</small><b>${s.notRun}</b></div><div><small>执行错误</small><b>${s.error}</b></div></div></header>${rows}`;
}

async function run(runId, output) {
  const server = await serve(resolve(root, config.target?.root ?? '../app')); const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE; let browser; const started = Date.now();
  try {
    browser = await chromium.launch({ headless: true, ...(executablePath ? { executablePath } : {}) });
    const results = []; for (const rule of rules) results.push(await execute(browser, rule, baseUrl, runId));
    const report = { meta: { contractVersion: 1, targetVersion, generatedAt: new Date().toISOString(), variant, durationMs: Date.now() - started, tokenSet: `${rulesFile.tokenSet.name} ${rulesFile.tokenSet.version}` }, summary: summarize(results), results };
    await mkdir(reportDir, { recursive: true });
    await writeFile(join(reportDir, `${output}.json`), JSON.stringify(report, null, 2)); await writeFile(join(reportDir, `${output}.html`), html(report));
    return report;
  } finally { try { await browser?.close(); } finally { await new Promise(done => server.close(done)); } }
}

if (args.includes('--repeat')) {
  const reports = []; for (let i = 1; i <= 3; i += 1) reports.push(await run(`run-${i}`, `${outName}-run-${i}`));
  const same = stable(reports); await writeFile(join(reportDir, `${outName}-repeatability.json`), JSON.stringify({ stable: same, runs: reports.map(r => r.meta.generatedAt) }, null, 2));
  console.log(JSON.stringify(reports[0].summary)); console.log(`重复性：${same ? '三次结果一致' : '检测到漂移'}`);
  process.exitCode = same ? Math.max(...reports.map(reportExitCode)) : 1;
} else {
  const report = await run('run', outName); console.log(JSON.stringify(report.summary));
  for (const r of report.results) console.log(`${r.status.padEnd(7)} ${r.ruleId}  ${r.actual}${r.errorMessage ? ' [' + r.errorMessage + ']' : ''}`);
  process.exitCode = reportExitCode(report);
}
