---
name: baux-iteration-acceptance
description: baux 迭代验收：一次迭代一个功能模块，产品和设计验收规则、交互、视觉、还原度（对照设计技能产出的 HTML 设计稿或 Figma 设计稿），生成开发分发包和回归包，导入修复回执和测试复验结果，按角色签收，判断能否准出。
metadata:
  version: "0.3.1"
  author: baux
---

# baux 迭代验收

> 「B端AI设计视界」出品。关注同名公众号，获取更多 B 端产品设计与 AI 实践资源。

使用者是产品经理和设计师。开发和测试不需要用 Claude：开发拿分发包修复、自测、交回执，测试跑回归包、交结果文件，都由产品或设计导入。

和其他技能的分工：
- **整体验收**（验收报告技能）：体验地图、走查覆盖、跨模块评估。这里不做。
- **设计技能**：产出带 `data-screen`、`data-ref` 的冻结 HTML 设计稿。这里拿它做还原度基线。
- **Figma 设计稿**也可以：要还原的图层命名为 `#ref`，保存命名版本后采集基线，后续流程完全相同。
- 走查记录（体验验收技能的 findings.json）可以作为本技能的输入。

## 五条底线

1. **台账是唯一记录。** 这次迭代的所有状态都在 `iteration.json` 里，只能通过脚本改。不要手改台账里的 `state`、`signoff`、`receipt`。页面是台账的快照。
2. **Claude 不替人拍板，也不替人签收。** `decide`、`defer`、`sign` 只在对应角色的人明确表态后执行，并用那个人的姓名和角色记录。没有明确表态就停下来问。新问题一律进“待决策”。
3. **期望值来自 token 或冻结的设计稿，实测值来自取值。** 不从截图估像素。设计稿取值不在 token 上的，记成“设计稿偏离规范”交设计，不交开发。
4. **自动通过不等于关闭。** 回归全过只说明验收标准成立，关闭仍要签收人签。签收人可以批量签。
5. **台账不记账号密码。** 测试环境只记地址；截图、录屏里有账号或真实业务数据的，提交前先打码。

## 角色和签收

| 类别 | 谁拍板方案 | 谁签收 |
|---|---|---|
| 验收规则：业务规则 | 产品 | 产品 |
| 验收规则：功能缺陷（BUG） | 产品 | 测试 |
| 交互、视觉 | 设计 | 设计 |
| 还原度 | 设计 | 设计 |

每项只有一位签收人。状态：待决策 → 待修复 → 待复验 → 已关闭；复验不通过退回待修复，轮次加一；“移出本迭代”需要写原因（高严重度只能由产品移出）。修改方认为不该由自己改或方案行不通，可以提**异议**，问题退回待决策，拍板人回复后重新下发或移出。详见 `references/roles-and-flow.md`。

## 流程

从 Skill 根目录运行以下命令。命令行输入路径相对当前工作目录；台账中保存的资源路径相对 `iteration.json` 所在目录；`targets.json` 的本地页面路径相对该文件所在目录。

**1. 建单**（产品）
```
node scripts/init-iteration.mjs --product 产品 --module 模块 --iteration "迭代名" --pages "页面A,页面B" \
  --tokens tokens.json --design 设计稿.html --out work/iteration.json [--from 走查findings.json] [--people "产品=…,设计=…,测试=…,开发=…"] \
  [--env 测试环境地址] [--design-url "页面A=设计稿链接,…"] [--causes 原因分类.json]
```
- token 用本产品的。设计技能的 token 可以先用 `scripts/import-tokens.mjs` 导入。没有就用 `assets/tokens/builtin-b2b-default.json`，但要告诉用户这不是他们的规范。
- `--from` 带入走查记录里属于本模块的问题。手写的还原度问题不带入，改由设计稿对照生成。
- 问题原因分类默认用 `assets/causes.json`（开发实现、设计、规范与组件、需求四组），产品线有自己的分类就用 `--causes` 替换。

**2. 验收规则、交互、视觉**（产品、设计）
- 和用户逐项过验收范围，发现的问题按 `references/ledger-schema.md` 写成数组，用 `scripts/add-findings.mjs --ledger … --file new.json` 加入。
- 每条都要有复现步骤；交开发的要有期望行为和可验证的验收标准。能自动判断的验收标准写成 `checks`，写法见 `references/regression-checks.md`。槽位按设计稿的 `data-ref` 名写进 `refs`，分发时会预填成 `[data-testid='…']`。

**3. 还原度**（设计）
```
node scripts/capture-baseline.mjs --design 设计稿.html --out work/baseline/v1.0.json --shots work/baseline/shots --ledger work/iteration.json
node scripts/compare-fidelity.mjs --ledger work/iteration.json --baseline work/baseline/v1.0.json --targets targets.json --shots work/shots
```
设计稿是 Figma 时，第一条换成：
```
node scripts/capture-baseline-figma.mjs --file <Figma 链接> --screens "order-list=12:34" --version <版本 id> \
  --out work/baseline/v1.0.json --shots work/baseline/shots --ledger work/iteration.json     # 需要 FIGMA_TOKEN
```
- 设计稿必须已冻结：HTML 稿要 `design:status=frozen`，Figma 稿要指定命名版本（`--version`）。没冻结就停下，让设计先冻结。
- Figma 稿的图层命名约定、变量绑定、哪些属性不可比，见 `references/figma.md`。Claude 所在环境访问不到 Figma 接口时，请用户在本机运行，或用 `--from-json` 读取保存下来的接口返回。
- `targets.json` 写每个 `data-screen` 对应的开发页地址。Claude 所在的环境通常访问不到公司的测试环境，这时请用户在本机运行这两条命令，把台账和截图交回来。
- 对照结果自动进台账，状态是待决策，每条带“设计稿｜开发页”对照截图。开发页缺 `data-testid` 的元素会单独列出，作为准出条件。详见 `references/fidelity.md`。

**4. 拍板、下发**（产品、设计）
```
node scripts/act.mjs attach --ledger work/iteration.json --id F-007 --before 截图.png或录屏.mp4 --by 姓名 --role 产品
node scripts/act.mjs decide --ledger work/iteration.json --id F-007[,F-008] [--owner dev|design|product] [--expected …] [--acceptance "标准1|标准2"] --by 姓名 --role 产品
node scripts/act.mjs defer  --ledger work/iteration.json --id F-010 --note 原因 --by 姓名 --role 设计
node scripts/dispatch.mjs --ledger work/iteration.json --out work/dispatch
```
没有现状截图或录屏不能下发（交互类问题一张图说不清时用录屏）。分发包里有待修复清单、证据、回归包（选择器已按 data-testid 预填）、回执模板和建单表格。

在 TAPD、Jira 等系统里用建单表格批量建好单后，把单号挂回台账；设计稿、规范、讨论记录也可以挂成链接：
```
node scripts/act.mjs link --ledger work/iteration.json --file tickets.json --by 姓名 --role 产品
node scripts/act.mjs link --ledger work/iteration.json --id F-013 --url https://… --label 页签规范 --by 姓名 --role 设计
```
交接说明见 `references/handoff.md`。

**5. 修复回传**（开发交回，产品或设计导入）
```
node scripts/act.mjs results --ledger work/iteration.json --report 自测报告.json --source 开发自测 --by 姓名 --role 开发
node scripts/act.mjs receipt --ledger work/iteration.json --file receipt.json --by 姓名 --role 开发
node scripts/act.mjs dispute --ledger work/iteration.json --id F-013 --note 理由 --by 姓名 --role 开发
node scripts/act.mjs decide  --ledger work/iteration.json --id F-013 --note 回复 --by 姓名 --role 设计
```
带自动检查的项，当前轮次的全部检查必须通过才能提测；报告记录被测版本（真实环境用 `--target-version` 或 `target.version`，模拟例可用 `--variant`）。缺项计为未执行，旧轮次或旧规则报告拒绝导入；每项回执要写改了什么、选一个问题原因，并附修复后截图或录屏。
修改方对某项有异议时，用 `dispute` 登记理由，问题退回待决策；拍板人必须用 `--note` 回复才能重新下发，也可以 `defer` 移出。

**6. 复验、签收**（测试、产品、设计）
```
node scripts/act.mjs results --ledger work/iteration.json --report 测试环境报告.json --source 测试环境 --by 姓名 --role 测试
node scripts/act.mjs sign --ledger work/iteration.json --id F-018 --result pass --by 姓名 --role 测试
node scripts/act.mjs sign --ledger work/iteration.json --auto-passed --result pass --by 姓名 --role 设计
node scripts/act.mjs sign --ledger work/iteration.json --id F-007 --result fail --note 哪里不对 --by 姓名 --role 产品
```
复验退回后旧自动结果失效；重新生成分发包、运行当前轮次回归后才能再次提测。已关闭项的回归有失败、执行错误或漏测，也会退回待修复。设计改稿的项，先重新冻结、重新采集基线，再由设计提交回执。

**7. 准出**
```
node scripts/status.mjs --ledger work/iteration.json
node scripts/build-page.mjs --ledger work/iteration.json --out work/page [--fragment]
```
状态和页面会按问题原因统计，用来复盘。准出条件：台账结构校验通过；没有待决策的项；高严重度全部关闭；中低严重度关闭或已移到下一迭代；自动项最近一次回归全过并已签收；已下发的项都有现状截图；提测的项都有修复后截图；设计稿元素在开发页都找得到。页面分产品、设计、开发、测试四个视图。要发布成 claude.ai 页面时加 `--fragment`，并把 `shots/` 一起发布。

## 环境与版本升级

- Node.js 20.11 或更高；在 Skill 根目录运行 `npm install`，浏览器任务首次运行前执行 `npx playwright install chromium ffmpeg`。`npm test` 运行单元测试。
- 0.3.0 回归报告不包含检查契约，升级后请重新生成分发包再运行。旧台账已关闭的自动项，可用 `dispatch.mjs --include-closed` 纳入回归；通过保留原签收记录，未通过自动重新打开。
- 被测版本由运行人填写，记录提交号、部署版本或演示 variant，不能代替真实环境和代码版本核验。

## 完整示例

`examples/order-receiving/`：订单收货迭代，从建单到准出的 41 步，其中 6 步演示守卫拒绝违规操作，包含挂单号、开发提异议、录屏证据和问题原因统计。运行 `node run-demo.mjs`，过程记录在 `work/演示记录.md`。同一张订单列表的 Figma 版本见 `node run-figma-demo.mjs`（离线模式）。

## 边界

- `--by`、`--role` 由操作人自己声明，台账记录了谁在什么时候做了什么，但这不是权限系统。
- 还原度只比对能和 token 对上的属性（颜色、字号、字重、行高、高度、圆角、内边距、间距、过渡时长）。布局、宽度、对齐没有比对，仍靠设计肉眼看对照截图。
- Figma 稿里没开自动布局的图层没有内边距、间距可比；行高为“自动”的文字不比行高。这些会在采集时列为“不可比”。
- 只对照设计稿的默认状态。其他状态（空、加载、错误）要在开发页上准备好对应状态后，用 `--state` 单独对照。
- 自测和测试环境的回归结果都由人交回，Claude 不直接访问公司环境。
