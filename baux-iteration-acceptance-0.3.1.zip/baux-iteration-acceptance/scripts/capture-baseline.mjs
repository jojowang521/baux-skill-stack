#!/usr/bin/env node
// 从设计稿 html 采集还原度基线：每个 data-ref 元素的实测样式和元素截图。
// 设计稿须按设计技能 的约定产出（meta design:*、data-screen、data-ref），并且已冻结（design:status=frozen）。
// 用法：node capture-baseline.mjs --design 设计稿.html --out baseline.json --shots shots/ [--ledger iteration.json] [--states] [--allow-draft]
//   --states   有 data-state-switch 的，逐个状态采集（默认只采默认状态）
//   --ledger   同时把设计稿版本登记到台账 meta.design
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, relative, resolve, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { measureInPage, PROPS } from './fidelity.mjs';
import { baseDir, loadLedger, launchBrowser, parseArgs, saveLedger } from './ledger.mjs';

const a = parseArgs(process.argv.slice(2));
if (!a.design || !a.out || !a.shots) { console.error('用法：capture-baseline.mjs --design 设计稿.html --out baseline.json --shots 目录 [--ledger iteration.json] [--states] [--allow-draft]'); process.exit(2); }
const html = readFileSync(a.design, 'utf8');
const meta = name => (new RegExp(`<meta[^>]*name=["']design:${name}["'][^>]*content=["']([^"']*)["']`, 'i').exec(html) ?? [])[1];
const version = meta('version'); const status = meta('status'); const viewport = meta('viewport');
if (!version || !status) { console.error('设计稿缺少 <meta name="design:version"> 或 design:status，不是按设计技能 约定产出的稿子。先用设计技能 的 lint-design.mjs 检查'); process.exit(1); }
if (status !== 'frozen' && !a['allow-draft']) { console.error(`设计稿状态是 ${status}，还没冻结。还原度只对照冻结的稿子；确需先看效果，加 --allow-draft（结果会标为“草稿基线”）`); process.exit(1); }
const [vw, vh] = String(viewport ?? '1440x900').split('x').map(Number);

const browser = await launchBrowser();
const page = await browser.newPage({ viewport: { width: vw || 1440, height: vh || 900 } });
await page.goto(pathToFileURL(resolve(a.design)).href); await page.waitForTimeout(300);
const shotDir = resolve(a.shots); mkdirSync(shotDir, { recursive: true });
const outDir = dirname(resolve(a.out));

const screens = await page.$$eval('[data-screen]', els => els.map(e => e.getAttribute('data-screen')));
if (!screens.length) { console.error('设计稿里没有 data-screen'); process.exit(1); }
const switches = a.states ? await page.$$eval('[data-state-switch]', els => els.map(e => e.getAttribute('data-state-switch'))) : [];
const states = ['default', ...switches.filter(s => s !== 'default' && s !== 'normal')];

async function hideReviewBar() { await page.addStyleTag({ content: '[data-design-only]{display:none!important}' }); }
const baseline = { source: basename(a.design), version, status, viewport: { width: vw || 1440, height: vh || 900 }, capturedAt: new Date().toISOString(), props: Object.keys(PROPS), screens: {} };

for (const state of states) {
  if (state !== 'default') { await page.goto(pathToFileURL(resolve(a.design)).href); await page.click(`[data-state-switch="${state}"]`); await page.waitForTimeout(300); }
  await hideReviewBar();
  for (const screen of screens) {
    const root = page.locator(`[data-screen="${screen}"]`).first();
    const refs = await root.evaluate(r => [...new Set([...r.querySelectorAll('[data-ref]')].map(e => e.getAttribute('data-ref')))]);
    const entry = (baseline.screens[screen] ??= { states: {} }).states[state] = { refs: {} };
    for (const ref of refs) {
      const loc = root.locator(`[data-ref="${ref}"]`);
      const count = await loc.count(); const first = loc.first();
      const values = await first.evaluate(new Function('el', `return (${measureInPage.toString()})(el)`));
      if (!values._visible) { entry.refs[ref] = { count, hidden: true }; continue; }
      const file = `design-${screen}-${state}-${ref}.png`;
      try { await first.screenshot({ path: resolve(shotDir, file) }); } catch { /* 截不到就不截 */ }
      const { _text, _visible, _leaf, ...props } = values;
      entry.refs[ref] = { count, text: _leaf ? _text : '', props, shot: relative(outDir, resolve(shotDir, file)) };
    }
  }
}
await browser.close();
writeFileSync(a.out, JSON.stringify(baseline, null, 2) + '\n');
const total = Object.values(baseline.screens).reduce((n, s) => n + Object.keys(s.states.default.refs).length, 0);
console.log(`已采集设计稿 ${baseline.source} v${version}（${status}）：${screens.length} 个页面，${total} 个标注元素，${states.length} 个状态 → ${a.out}`);
if (a.ledger) {
  const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
  const p = relative(dir, resolve(a.design)); const entry = ledger.meta.design.find(d => d.path === p) ?? (ledger.meta.design.push({ path: p }), ledger.meta.design.at(-1));
  Object.assign(entry, { version, status, baseline: relative(dir, resolve(a.out)), screens });
  saveLedger(a.ledger, ledger); console.log('已登记到台账');
}
