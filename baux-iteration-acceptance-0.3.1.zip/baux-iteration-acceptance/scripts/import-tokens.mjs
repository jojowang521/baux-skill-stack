#!/usr/bin/env node
// 把产品自己的 token 换进来。支持两种输入：
//   --css  文件   :root 里的 CSS 自定义属性（--color-primary: #2A62F5;）
//   --dtcg 文件   W3C Design Tokens (DTCG) JSON（$type / $value）
// 输出统一结构。分不出类别的 token 会列出来，不会被悄悄归类。
// 交互状态矩阵、容差默认继承内置集，可用 --base 指定别的基底。
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { DIMENSIONS, TOKEN_DIMENSIONS, readJson } from './lib.mjs';

const args = process.argv.slice(2);
const opt = name => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const cssPath = opt('--css'); const dtcgPath = opt('--dtcg'); const out = opt('--out'); const name = opt('--name');
const basePath = opt('--base') ?? resolve(import.meta.dirname, '../assets/tokens/builtin-b2b-default.json');
if ((!cssPath && !dtcgPath) || !out || !name) {
  console.error('用法: node import-tokens.mjs (--css 文件 | --dtcg 文件) --name 产品名 --out tokens/产品名.json [--base 基底token.json]');
  process.exit(2);
}

const COLOR = /^(#([0-9a-f]{3,8})|rgba?\(.*\)|hsla?\(.*\))$/i;
function classify(key, value) {
  const name = key.toLowerCase(); const text = String(value).trim();
  if (COLOR.test(text)) return 'color';
  if (/duration|delay|transition|easing|\bease\b|motion/.test(name) || /^cubic-bezier\(/.test(text) || /^\d+(\.\d+)?m?s$/.test(text)) return 'motion';
  if (/font|line-height|letter|weight|text-size/.test(name)) return 'typography';
  if (/space|spacing|gap|margin|padding/.test(name)) return 'spacing';
  if (/size|height|width|radius|icon|target/.test(name)) return 'size';
  return null;
}

const found = []; // { key, value, dim }
if (cssPath) {
  const css = readFileSync(cssPath, 'utf8');
  for (const match of css.matchAll(/--([\w-]+)\s*:\s*([^;}]+?)\s*(?:;|(?=}))/g)) found.push({ key: match[1], value: match[2].trim(), dim: classify(match[1], match[2]) });
}
if (dtcgPath) {
  const typeDim = { color: 'color', duration: 'motion', cubicBezier: 'motion', fontSize: 'typography', lineHeight: 'typography', fontWeight: 'typography', fontFamily: 'typography', letterSpacing: 'typography' };
  const text = v => {
    if (v && typeof v === 'object') {
      if ('hex' in v) return String(v.hex);
      if ('value' in v && 'unit' in v) return `${v.value}${v.unit}`;
      if (Array.isArray(v)) return `cubic-bezier(${v.join(', ')})`;
    }
    return Array.isArray(v) ? `cubic-bezier(${v.join(', ')})` : String(v);
  };
  const walk = (node, path, inheritedType) => {
    if (!node || typeof node !== 'object') return;
    const type = node.$type ?? inheritedType;
    if ('$value' in node) {
      const key = path.join('-'); const value = text(node.$value);
      found.push({ key, value, dim: typeDim[type] ?? classify(key, value) });
      return;
    }
    for (const [childKey, child] of Object.entries(node)) if (!childKey.startsWith('$')) walk(child, [...path, childKey], type);
  };
  walk(readJson(dtcgPath), [], undefined);
}

const base = readJson(basePath);
const result = { name, version: '1.0.0', note: `由 ${cssPath ?? dtcgPath} 导入。交互状态矩阵与容差继承自 ${base.name}，请按本产品实际情况核对。`, tolerance: base.tolerance };
for (const dim of TOKEN_DIMENSIONS) result[dim] = {};
const unclassified = [];
for (const item of found) {
  if (!item.dim) { unclassified.push(item); continue; }
  result[item.dim][item.key] = { value: item.value, role: '' };
}
result.interaction = base.interaction;

mkdirSync(dirname(resolve(out)), { recursive: true });
writeFileSync(out, JSON.stringify(result, null, 2) + '\n');
console.log(`已写入 ${out}`);
for (const dim of TOKEN_DIMENSIONS) console.log(`  ${DIMENSIONS[dim]}：${Object.keys(result[dim]).length} 个`);
if (unclassified.length) {
  console.log(`\n有 ${unclassified.length} 个 token 无法自动归类，未写入，请手动处理：`);
  for (const item of unclassified) console.log(`  --${item.key}: ${item.value}`);
}
const empty = TOKEN_DIMENSIONS.filter(dim => !Object.keys(result[dim]).length);
if (empty.length) console.log(`\n注意：${empty.map(d => DIMENSIONS[d]).join('、')}没有任何 token，这些维度的问题只能用 noTokenReason。`);
console.log('role 字段留空，建议补上各 token 的用途，报告里会显示。');
