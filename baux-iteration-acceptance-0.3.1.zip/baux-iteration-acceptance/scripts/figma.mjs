// Figma 节点 → 还原度属性。纯函数，不联网，便于测试。
// 输入是 Figma REST 接口 GET /v1/files/:key/nodes 返回的节点 JSON。

const hex2 = n => Math.round(n * 255);
/** Figma 颜色（0~1 浮点）转 CSS。整体不透明时返回 rgb()，否则 rgba()（rgba 不参与 token 比对）。 */
export function paintToCss(paint, nodeOpacity = 1) {
  if (!paint || paint.visible === false || paint.type !== 'SOLID' || !paint.color) return null;
  const a = (paint.color.a ?? 1) * (paint.opacity ?? 1) * nodeOpacity;
  const [r, g, b] = [paint.color.r, paint.color.g, paint.color.b].map(hex2);
  return a >= 0.999 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${Math.round(a * 1000) / 1000})`;
}
const firstPaint = list => (list ?? []).find(p => p.visible !== false) ?? null;
const px = v => (typeof v === 'number' ? `${Math.round(v * 100) / 100}px` : null);

/** 图层名约定：以 # 开头，# 后是 ref（kebab-case），如 “#order-row”。名字后面可以跟空格和备注。 */
export function refOf(node) {
  const m = /^#([a-z0-9]+(?:-[a-z0-9]+)*)(?:\s|$)/.exec(String(node?.name ?? '').trim());
  return m ? m[1] : null;
}

/**
 * 读一个节点的还原度属性，字段与 HTML 基线一致。
 * 返回 { props, vars, notComparable, text, leaf }。
 *   vars：属性 → Figma 变量 id（设计师绑定了变量时才有）
 *   notComparable：在 Figma 里没有对应概念、不能比的属性（如没开自动布局时的内边距）
 */
export function nodeProps(node) {
  const props = {}; const vars = {}; const notComparable = [];
  const op = node.opacity ?? 1; const bv = node.boundVariables ?? {};
  const fill = firstPaint(node.fills); const stroke = firstPaint(node.strokes);
  const fillVar = (bv.fills ?? [])[0]?.id; const strokeVar = (bv.strokes ?? [])[0]?.id;
  if (node.type === 'TEXT') {
    props.color = paintToCss(fill, op); if (fillVar) vars.color = fillVar;
    props.backgroundColor = null;
    const st = node.style ?? {};
    props.fontSize = px(st.fontSize); props.fontWeight = st.fontWeight != null ? String(st.fontWeight) : null;
    props.lineHeight = st.lineHeightUnit === 'INTRINSIC_%' || st.lineHeightPx == null ? null : px(st.lineHeightPx);
    if (props.lineHeight == null) notComparable.push('lineHeight（行高为“自动”）');
    for (const k of ['fontSize', 'fontWeight', 'lineHeight']) if (bv[k]?.id) vars[k] = bv[k].id;
  } else {
    props.color = null; // 容器没有文字颜色，文字颜色在文字图层上比
    props.backgroundColor = paintToCss(fill, op); if (fillVar && props.backgroundColor) vars.backgroundColor = fillVar;
    props.fontSize = props.fontWeight = props.lineHeight = null;
  }
  props.borderTopColor = (node.strokeWeight ?? 0) > 0 ? paintToCss(stroke, op) : null; if (strokeVar && props.borderTopColor) vars.borderTopColor = strokeVar;
  props.height = px(node.absoluteBoundingBox?.height);
  const radius = node.rectangleCornerRadii?.[0] ?? node.cornerRadius; props.borderTopLeftRadius = radius ? px(radius) : null;
  if (bv.topLeftRadius?.id || bv.cornerRadius?.id) vars.borderTopLeftRadius = (bv.topLeftRadius ?? bv.cornerRadius).id;
  const auto = node.layoutMode && node.layoutMode !== 'NONE';
  for (const [k, f] of [['paddingTop', 'paddingTop'], ['paddingRight', 'paddingRight'], ['paddingBottom', 'paddingBottom'], ['paddingLeft', 'paddingLeft']]) {
    props[k] = auto ? px(node[f] ?? 0) : null; if (auto && bv[f]?.id) vars[k] = bv[f].id;
  }
  props.gap = auto && node.primaryAxisAlignItems !== 'SPACE_BETWEEN' ? px(node.itemSpacing ?? 0) : null; if (auto && bv.itemSpacing?.id) vars.gap = bv.itemSpacing.id;
  if (!auto && node.type !== 'TEXT' && node.children?.length) notComparable.push('内边距、间距（没有开自动布局）');
  props.transitionDuration = null; // Figma 原型动效不对照
  const leaf = node.type === 'TEXT';
  return { props, vars, notComparable, text: leaf ? String(node.characters ?? '').trim().replace(/\s+/g, ' ').slice(0, 16) : '', leaf };
}

/** 在画框里找所有带 #ref 的可见图层。同名的多个图层视为同一元素的多个实例，取第一个的属性。 */
export function collectRefs(frame) {
  const found = new Map();
  (function walk(n) {
    if (!n || n.visible === false) return;
    const ref = refOf(n);
    if (ref && n !== frame) { if (!found.has(ref)) found.set(ref, { node: n, count: 0 }); found.get(ref).count++; }
    for (const c of n.children ?? []) walk(c);
  })(frame);
  return found;
}

/** Figma 变量名 → token 引用。“color/status-neutral” → “color.status-neutral”。 */
export const varToTokenRef = name => name ? String(name).trim().replace(/\s+/g, '').split('/').filter(Boolean).join('.').replace(/^([^.]+)\.(.+)$/, (_, d, rest) => `${d}.${rest.replaceAll('.', '-')}`) : null;
