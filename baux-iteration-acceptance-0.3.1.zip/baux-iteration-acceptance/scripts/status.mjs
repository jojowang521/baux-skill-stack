#!/usr/bin/env node
// 看这次迭代的进度和准出结论。退出码：0 可以准出；1 暂不能准出。
// 用法：node status.mjs --ledger iteration.json [--json]
import { readJson } from './lib.mjs';
import { STATES, baseDir, causeStats, exitCheck, loadLedger, parseArgs, validateLedger } from './ledger.mjs';
const a = parseArgs(process.argv.slice(2));
if (!a.ledger) { console.error('用法：status.mjs --ledger iteration.json [--json]'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
const tokens = readJson(`${dir}/${ledger.meta.tokens.path}`);
const v = validateLedger(ledger, tokens, dir); const ex = exitCheck(ledger, dir, tokens);
const count = Object.fromEntries(Object.keys(STATES).map(k => [k, ledger.findings.filter(f => f.state === k).length]));
const causes = causeStats(ledger); const disputes = ledger.findings.filter(f => f.disputes?.length);
if (a.json) { console.log(JSON.stringify({ count, exit: ex, causes, disputes: disputes.map(f => ({ id: f.id, disputes: f.disputes })), errors: v.errors, warnings: v.warnings }, null, 2)); process.exit(ex.pass ? 0 : 1); }
const m = ledger.meta;
console.log(`${m.product} · ${m.module} · ${m.iteration}`);
console.log(Object.entries(STATES).map(([k, n]) => `${n} ${count[k]}`).join('  '));
if (v.errors.length) console.log('\n台账有结构错误：\n' + v.errors.map(e => '  - ' + e).join('\n'));
console.log('\n准出条件：');
for (const r of ex.rules) console.log(`  ${r.ok ? '✓' : '✗'} ${r.text}（${r.detail}）${!r.ok && r.ids.length ? '  ' + r.ids.join(' ') : ''}${r.missing?.length ? '  开发页缺：' + r.missing.join('、') : ''}`);
const used = causes.flatMap(g => g.items.filter(i => i.count).map(i => `${g.group}·${i.item} ${i.count}（${i.ids.join(' ')}）`));
if (used.length) console.log('\n问题原因：\n  ' + used.join('\n  '));
if (disputes.length) console.log(`\n异议：${disputes.map(f => `${f.id}（${f.disputes.length} 次${f.dispute?.reply ? '，已回复' : '，待回复'}）`).join('、')}`);
console.log(`\n结论：${ex.pass ? '可以准出' : '暂不能准出'}`);
process.exit(ex.pass ? 0 : 1);
