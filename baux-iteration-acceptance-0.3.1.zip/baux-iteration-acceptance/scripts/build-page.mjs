#!/usr/bin/env node
// 从台账生成迭代验收单页面（产品、设计、开发、测试四个视图，准出条件，截图对比，处理记录）。
// 用法：node build-page.mjs --ledger iteration.json --out page/ [--fragment] [--sample]
//   --fragment  只输出页面片段（不带 <!doctype>/<head>），用于发布到 claude.ai Artifact
//   --sample    页面标注“示例数据”
import { copyFileSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson } from './lib.mjs';
import { baseDir, causeStats, exitCheck, fileOk, loadLedger, parseArgs, validateLedger } from './ledger.mjs';
const here = dirname(fileURLToPath(import.meta.url));
const a = parseArgs(process.argv.slice(2));
if (!a.ledger || !a.out) { console.error('用法：build-page.mjs --ledger iteration.json --out 目录 [--fragment] [--sample]'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger); const out = resolve(a.out);
const tokens = readJson(resolve(dir, ledger.meta.tokens.path));
const v = validateLedger(ledger, tokens, dir);
if (v.errors.length) { console.error('台账有结构错误，先修正：\n' + v.errors.map(e => '  - ' + e).join('\n')); process.exit(1); }
mkdirSync(join(out, 'shots'), { recursive: true });
const copy = p => { if (!fileOk(dir, p)) return null; const name = `shots/${basename(p)}`; copyFileSync(resolve(dir, p), join(out, name)); return name; };
const findings = ledger.findings.map(f => {
  const { checks, history, ...rest } = f;
  return { ...rest, checks: (checks ?? []).map(c => ({ kind: c.kind })), history, shots: { before: copy(f.shots?.before), after: copy(f.shots?.after) } };
});
const data = { meta: ledger.meta, groups: ledger.groups, findings, causes: causeStats(ledger), exit: exitCheck(ledger, dir, tokens), generatedAt: new Date().toISOString(), ledgerFile: basename(a.ledger), sample: Boolean(a.sample) };
let html = readFileSync(resolve(here, '../assets/page-template.html'), 'utf8')
  .replace('__TITLE__', `${ledger.meta.module}迭代验收单`.replace(/[<>&]/g, ''))
  .replace('__DATA__', JSON.stringify(data).replace(/</g, '\\u003c'));
if (!a.fragment) html = `<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n${html}\n</html>\n`;
writeFileSync(join(out, 'index.html'), html);
console.log(`页面 → ${join(out, 'index.html')}（${findings.length} 项，${data.exit.pass ? '可以准出' : '暂不能准出'}）`);
