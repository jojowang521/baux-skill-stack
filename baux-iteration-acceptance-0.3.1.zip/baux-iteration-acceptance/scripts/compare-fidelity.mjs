#!/usr/bin/env node
// 还原度对照：按 data-ref（设计稿）↔ data-testid（开发页）逐个元素取值比对，把差异写成台账里的待决策问题。
// 设计稿取值在 token 上 → 开发还原度问题（交开发，带自动检查）；设计稿取值不在 token 上 → 设计稿偏离规范（交设计）。
// 用法：node compare-fidelity.mjs --ledger iteration.json --baseline baseline.json --targets targets.json --shots shots/ [--state default] [--dry-run]
//   targets.json：{ "设计稿 data-screen 名": { "url": "开发页地址或本地文件", "page": "台账里的页面名" } }
import { mkdirSync, readFileSync } from 'node:fs';
import { relative, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { readJson } from './lib.mjs';
import { PROPS, PROP_LABEL, classify, measureInPage, showValue } from './fidelity.mjs';
import { baseDir, loadLedger, launchBrowser, parseArgs, saveLedger, validateLedger } from './ledger.mjs';

const a = parseArgs(process.argv.slice(2));
if (!a.ledger || !a.baseline || !a.targets || !a.shots) { console.error('用法：compare-fidelity.mjs --ledger iteration.json --baseline baseline.json --targets targets.json --shots 目录'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
const tokens = readJson(resolve(dir, ledger.meta.tokens.path));
const baseline = readJson(a.baseline); const targets = readJson(a.targets); const state = a.state && a.state !== true ? a.state : 'default';
const bdir = resolve(a.baseline, '..'); const shotDir = resolve(a.shots); mkdirSync(shotDir, { recursive: true });
const tdir = resolve(a.targets, '..'); // 本地文件路径相对 targets.json 所在目录
const toUrl = u => /^(https?|file):/.test(u) ? u : pathToFileURL(resolve(tdir, u.split(/[?#]/)[0])).href + (u.match(/[?#].*$/)?.[0] ?? '');
const measure = new Function('el', `return (${measureInPage.toString()})(el)`);

const browser = await launchBrowser();
const diffs = []; const missing = []; let total = 0; let compared = 0;
for (const [screen, s] of Object.entries(baseline.screens)) {
  const base = s.states[state]; if (!base) continue;
  const target = targets[screen]; const refs = Object.entries(base.refs).filter(([, r]) => !r.hidden);
  total += refs.length;
  if (!target) { missing.push(...refs.map(([ref]) => `${screen}/${ref}`)); console.log(`没有给 ${screen} 配开发页地址，跳过 ${refs.length} 个元素`); continue; }
  const page = await browser.newPage({ viewport: baseline.viewport });
  await page.goto(toUrl(target.url)); await page.waitForTimeout(400);
  for (const [ref, b] of refs) {
    const loc = page.locator(`[data-testid="${ref}"], [data-ref="${ref}"]`); const n = await loc.count();
    if (!n) { missing.push(ref); continue; }
    compared++;
    const all = []; for (let i = 0; i < n; i++) all.push(await loc.nth(i).evaluate(measure));
    for (const prop of Object.keys(PROPS)) {
      const dv = b.props[prop];
      const bad = all.map((m, i) => ({ i, v: m[prop], c: classify(tokens, prop, dv, m[prop], ref, b.tokens?.[prop]) })).filter(x => x.c);
      if (!bad.length) continue;
      diffs.push({ screen, page: target.page, url: target.url, ref, text: b.text, count: n, prop, designValue: showValue(prop, dv), devValue: showValue(prop, bad[0].v), instances: bad.length, cls: bad[0].c, designShot: b.shot ? resolve(bdir, b.shot) : null, pageObj: page });
    }
  }
  // 开发页元素截图（每个元素一张，标红框）
  for (const d of diffs.filter(x => x.screen === screen && !x.devShot)) {
    const file = resolve(shotDir, `dev-${screen}-${d.ref}.png`);
    if (!diffs.some(x => x.devShot === file)) { try { await page.locator(`[data-testid="${d.ref}"], [data-ref="${d.ref}"]`).first().screenshot({ path: file }); } catch { /* 忽略 */ } }
    d.devShot = file; delete d.pageObj;
  }
  await page.close();
}

/* 合并：同一属性、同一设计值、同一开发值、同一归属的差异，合成一个问题（如多个状态标签同样偏了） */
const groups = new Map();
for (const d of diffs) {
  const key = [d.screen, d.prop, d.designValue, d.devValue, d.cls.kind].join('|');
  if (!groups.has(key)) groups.set(key, { ...d, refs: [] }); groups.get(key).refs.push({ ref: d.ref, text: d.text, count: d.count, designShot: d.designShot, devShot: d.devShot });
}

/* 拼对照图：左设计稿、右开发页 */
async function sideBySide(g, file) {
  const img = p => { try { return readFileSync(p); } catch { return null; } };
  const width = buf => buf && buf.length > 24 ? buf.readUInt32BE(16) : 0;
  const uri = buf => buf ? 'data:image/png;base64,' + buf.toString('base64') : '';
  const rows = g.refs.slice(0, 4).map(r => {
    const d = img(r.designShot); const v = img(r.devShot); const wide = Math.max(width(d), width(v)) > 440;
    return `<div class="row${wide ? ' wide' : ''}"><div><small>设计稿 v${baseline.version} · ${r.ref}</small><img src="${uri(d)}"></div><div><small>开发页 · ${r.ref}</small><img class="dev" src="${uri(v)}"></div></div>`;
  }).join('');
  const p = await browser.newPage({ viewport: { width: 960, height: 200 } });
  await p.setContent(`<style>body{margin:0;font:13px system-ui,"PingFang SC",sans-serif;background:#fff;color:#1f2a44}#wrap{padding:16px;display:inline-flex;flex-direction:column;gap:12px;max-width:928px}.row{display:grid;grid-template-columns:auto auto;gap:24px;justify-content:start}.row.wide{grid-template-columns:1fr}.row div{display:flex;flex-direction:column;gap:6px;min-width:0}img{max-width:100%;border:1px solid #dce3ef;align-self:flex-start}img.dev{outline:2px solid #e5484d;outline-offset:2px}h4{margin:0;font-size:14px}</style><div id="wrap"><h4>${PROP_LABEL[g.prop]}：设计稿 ${g.designValue ?? '无'} ｜ 开发页 ${g.devValue ?? '无'}</h4>${rows}</div>`);
  await p.locator('#wrap').screenshot({ path: file }); await p.close();
}

let n = Math.max(0, ...ledger.findings.map(f => Number(f.id.slice(2)) || 0));
const added = []; const updated = []; const resolved = [];
const keyOf = g => `${g.screen}|${g.prop}|${g.cls.kind}|${g.refs.map(r => r.ref).sort().join(',')}`;
const seenKeys = new Set();
for (const g of groups.values()) {
  const fkey = keyOf(g); seenKeys.add(fkey);
  const label = g.refs.map(r => r.text ? `「${r.text}」` : `${r.ref}${r.count > 1 ? `（${r.count} 个）` : ''}`).slice(0, 2).join('、') + (g.refs.length > 2 ? ` 等 ${g.refs.length} 处` : '');
  const existing = ledger.findings.find(f => f.fidelityKey === fkey);
  if (existing) { if (!['closed', 'out'].includes(existing.state)) { existing.actualValue = existing.tokenRef ? g.devValue : existing.actualValue; updated.push(existing.id); } else if (existing.state === 'closed') console.log(`注意：${existing.id} 已关闭，但这次对照又出现了同样的差异，请确认是否回退`); continue; }
  const id = `F-${String(++n).padStart(3, '0')}`;
  const shot = resolve(shotDir, `fidelity-${id}.png`); await sideBySide(g, shot);
  const dim = g.cls.dim; const propLabel = PROP_LABEL[g.prop];
  const common = { id, module: ledger.meta.module, page: g.page, dimension: dim, category: 'fidelity', signer: '设计', state: 'decide', round: 1, fidelityKey: fkey,
    repro: [`打开${g.page}`, `找到 ${g.refs.map(r => `data-testid="${r.ref}"`).join('、')} 的元素`, `读取${propLabel}（computed style）`],
    evidence: { state: 'measured', ref: `设计稿 ${baseline.source} v${baseline.version} 对照取值` },
    shots: { before: relative(dir, shot) }, fidelity: { screen: g.screen, refs: g.refs.map(r => r.ref), prop: g.prop, designValue: g.designValue, devValue: g.devValue, instances: g.instances, baseline: `${baseline.source} v${baseline.version}`, ...(g.cls.token ? { tokenSource: g.cls.token.bound ? '设计稿绑定的变量' : '按数值匹配' } : {}) },
    history: [{ at: new Date().toISOString(), by: 'compare-fidelity', role: '系统', action: 'fidelity', from: null, to: 'decide' }] };
  let f;
  if (g.cls.kind === 'dev') {
    const t = g.cls.token; const expected = t.value;
    f = { ...common, title: `${label}的${propLabel}与设计稿不一致`, type: '开发还原度', severity: dim === 'color' ? '中' : '低', severityBasis: dim === 'color' ? '颜色偏差，可能造成状态误读' : '外观一致性，不影响使用', owner: 'dev',
      ...(t.ref ? { tokenRef: t.ref, expectedValue: expected } : { noTokenReason: '设计稿取值为 0，不对应具体 token', expectedValue: expected }), actualValue: g.devValue ?? '无',
      expected: `${propLabel}为 ${expected}${t.ref ? `（${t.ref}）` : ''}，与设计稿一致。`, actual: `开发页${propLabel}为 ${g.devValue ?? '无'}${g.instances > 1 ? `，共 ${g.instances} 处` : ''}。`,
      acceptance: g.refs.map(r => `data-testid="${r.ref}" 的${propLabel}为 ${expected}${r.count > 1 ? `（全部 ${r.count} 个）` : ''}`),
      checks: g.refs.map((r, i) => ({ acceptance: i, kind: g.prop === 'transitionDuration' ? 'transition' : 'style', slots: { $target: `${r.text ? `「${r.text}」` : ''}data-testid="${r.ref}" 的元素` }, refs: { $target: r.ref }, property: g.prop === 'transitionDuration' ? 'all' : g.prop, ...(t.ref ? { tokenRef: t.ref } : { expected }), ...(r.count > 1 ? { all: true } : {}) })),
      suggestion: t.ref ? `改用 token ${t.ref}，不要写死数值。` : '' };
  } else {
    f = { ...common, title: `设计稿里${label}的${propLabel} ${g.designValue} 不在 token 中`, type: 'UI问题', severity: '低', severityBasis: '规范一致性，先由设计确认取值', owner: 'design',
      noTokenReason: `设计稿取值 ${g.designValue} 不在当前 token 集中`,
      expected: `由设计确认：改设计稿为 token 值，或补充 token。确认前不下发开发。`, actual: `设计稿 ${g.designValue}，开发页 ${g.devValue ?? '无'}${g.cls.silent ? '（开发照稿实现）' : ''}。`,
      suggestion: '改稿后重新冻结并采集基线。' };
  }
  ledger.findings.push(f); added.push(f);
}
for (const f of ledger.findings) if (f.fidelityKey && !seenKeys.has(f.fidelityKey) && ['fix', 'retest'].includes(f.state)) resolved.push(f.id);
await browser.close();

ledger.meta.fidelity = { baseline: `${baseline.source} v${baseline.version}`, state, comparedAt: new Date().toISOString(), total, compared, missing };
const v = validateLedger(ledger, tokens, dir);
if (v.errors.length) { console.error('生成的问题没有通过校验，台账未写入：\n' + v.errors.map(e => '  - ' + e).join('\n')); process.exit(1); }
if (!a['dry-run']) saveLedger(a.ledger, ledger);
console.log(`对照 ${compared}/${total} 个元素（设计稿 ${baseline.source} v${baseline.version}，状态 ${state}）`);
for (const f of added) console.log(`  新增 ${f.id} [${f.owner === 'dev' ? '交开发' : '交设计'}] ${f.title}`);
if (updated.length) console.log(`  已有问题更新实测值：${updated.join('、')}`);
if (resolved.length) console.log(`  这次对照已一致（仍需回执和签收才能关闭）：${resolved.join('、')}`);
if (missing.length) console.log(`  开发页找不到这些元素（需要加 data-testid，与设计稿 data-ref 同名）：${missing.join('、')}`);
console.log('新增问题都是“待决策”，由设计确认后才下发。');
