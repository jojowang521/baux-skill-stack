// 还原度对照的共享逻辑：取哪些属性、归到哪个维度、偏差算谁的。
import { compareValues, normColor, resolveToken, sameValue } from './lib.mjs';

/** 展示用：颜色统一成大写十六进制。 */
export const showValue = (prop, v) => v == null ? null : (PROPS[prop] === 'color' ? (normColor(v)?.toUpperCase() ?? v) : v);

/** 取值的属性 → 维度。只取能和 token 对上的属性；宽度受布局影响，不取。 */
export const PROPS = {
  color: 'color', backgroundColor: 'color', borderTopColor: 'color',
  fontSize: 'typography', fontWeight: 'typography', lineHeight: 'typography',
  height: 'size', borderTopLeftRadius: 'size',
  paddingTop: 'spacing', paddingRight: 'spacing', paddingBottom: 'spacing', paddingLeft: 'spacing', gap: 'spacing',
  transitionDuration: 'motion'
};
export const PROP_LABEL = { color: '文字颜色', backgroundColor: '背景色', borderTopColor: '边框色', fontSize: '字号', fontWeight: '字重', lineHeight: '行高', height: '高度', borderTopLeftRadius: '圆角', paddingTop: '上内边距', paddingRight: '右内边距', paddingBottom: '下内边距', paddingLeft: '左内边距', gap: '元素间距', transitionDuration: '过渡时长' };
/** 设计稿自查只针对刻度有限的属性：颜色、字号、内边距、间距。高度、行高这类派生值不查。 */
export const AUDIT_PROPS = new Set(['color', 'backgroundColor', 'borderTopColor', 'fontSize', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'gap']);

/** 在浏览器里执行：读取一个元素的属性。没有意义的值（透明背景、0 宽边框、无过渡、非 flex 的 gap）返回 null。 */
export function measureInPage(el) {
  const s = getComputedStyle(el); const r = el.getBoundingClientRect(); const out = {};
  const alpha = v => /rgba\([^)]*,\s*0\)$/.test(v) || v === 'transparent';
  out.color = s.color;
  out.backgroundColor = alpha(s.backgroundColor) ? null : s.backgroundColor;
  out.borderTopColor = parseFloat(s.borderTopWidth) > 0 && !alpha(s.borderTopColor) ? s.borderTopColor : null;
  out.fontSize = s.fontSize; out.fontWeight = s.fontWeight; out.lineHeight = s.lineHeight === 'normal' ? null : s.lineHeight;
  out.height = Math.round(r.height * 100) / 100 + 'px';
  out.borderTopLeftRadius = s.borderTopLeftRadius === '0px' ? null : s.borderTopLeftRadius;
  for (const k of ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft']) out[k] = s[k];
  out.gap = /flex|grid/.test(s.display) && s.columnGap !== 'normal' ? s.columnGap : null;
  const d = s.transitionDuration.split(',')[0].trim();
  out.transitionDuration = d === '0s' ? null : (d.endsWith('ms') ? d : parseFloat(d) * 1000 + 'ms');
  out._text = (el.innerText || el.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 16);
  out._visible = r.width > 0 && r.height > 0;
  out._leaf = el.children.length === 0;
  return out;
}

/** 在 token 集里找和这个值相等的 token。同值的 token 不止一个时，优先选名字和元素 ref 有共同词的（如 status-cancelled → color.status-neutral）。
 *  spacing 的 0px 视为在刻度上。 */
export function matchToken(tokens, dim, value, hint = '') {
  if (value == null) return null;
  if (dim === 'spacing' && /^0(px)?$/.test(String(value))) return { ref: null, value: '0px', zero: true };
  const pools = dim === 'size' ? ['size', 'spacing'] : [dim];
  const words = new Set(String(hint).toLowerCase().split(/[^a-z0-9]+/).filter(Boolean));
  const hits = [];
  for (const d of pools) for (const [key, t] of Object.entries(tokens?.[d] ?? {})) {
    if (!(t && typeof t === 'object' && 'value' in t)) continue;
    if (sameValue(d === 'color' || d === 'typography' || d === 'motion' ? d : 'size', t.value, value)) hits.push({ ref: `${d}.${key}`, value: t.value, score: key.split('-').filter(w => words.has(w)).length });
  }
  if (hits.length) return hits.sort((x, y) => y.score - x.score)[0];
  if (dim === 'color' && !normColor(value)) return { ref: null, value, unknown: true };
  return null;
}

/** 高度、行高是派生值（由内容和行数决定）。设计稿上的值不在 token 上时，不拿它判对错。 */
export const DERIVED = new Set(['height', 'lineHeight']);

/**
 * 判断一处差异算谁的。纯函数，便于测试。
 * 返回 null（没有差异、在容差内、或派生值不可比）、{ kind: 'dev', token }（设计稿取值在 token 上，开发没做到）、
 * { kind: 'design' }（设计稿取值不在 token 上，先由设计确认；silent 表示开发照稿实现了）。
 */
export function classify(tokens, prop, designValue, devValue, hint = '', boundRef = null) {
  const dim = PROPS[prop];
  if (designValue == null) return null; // 设计稿没有这项（如透明背景），开发多出来的样式不在还原度范围
  // 开发页没有这个概念（如表格不是 flex，没有 gap；间距可能用 margin 实现）：不可比，不判
  if (devValue == null && prop === 'gap') return null;
  const cmp = devValue == null ? { within: false } : compareValues(dim, designValue, devValue, tokens);
  // 设计师绑定了变量、且变量对应的 token 值与设计稿一致时，直接用它，不按数值猜
  const bound = boundRef ? resolveToken(tokens, boundRef) : null;
  const token = bound && sameValue(dim === 'color' || dim === 'typography' || dim === 'motion' ? dim : 'size', bound.value, designValue) ? { ref: boundRef, value: bound.value, bound: true } : matchToken(tokens, dim, designValue, hint);
  if (cmp.within) return AUDIT_PROPS.has(prop) && !token ? { kind: 'design', silent: true, dim } : null;
  if (token && !token.unknown) return { kind: 'dev', dim, token };
  if (DERIVED.has(prop)) return null;
  return { kind: 'design', dim };
}
