#!/usr/bin/env node
// 建一张迭代验收单（台账 iteration.json）。一次迭代 = 一个功能模块。
// 用法：node init-iteration.mjs --product 产品 --module 模块 --iteration 迭代名 --pages "页面A,页面B"
//        --tokens tokens.json --out iteration.json [--design 设计稿.html,…] [--from findings.json] [--keep-fidelity]
//        [--people "产品=张三,设计=李四,测试=王五,开发=赵六"] [--env 测试环境地址] [--design-url "页面A=https://…,页面B=https://…"]
//        [--causes 原因分类.json]
// 测试环境只记地址，不要把账号密码写进台账。
// --from 用于把走查记录里属于本模块的问题带进来，一律进入“待决策”。还原度问题默认不带，改由设计稿对照自动生成。
import { existsSync } from 'node:fs';
import { relative, resolve, dirname } from 'node:path';
import { readJson } from './lib.mjs';
import { categorize, defaultSigner, parseArgs, saveLedger, validateLedger } from './ledger.mjs';

const a = parseArgs(process.argv.slice(2));
for (const k of ['product', 'module', 'iteration', 'tokens', 'out']) if (!a[k] || a[k] === true) { console.error(`缺少 --${k}\n用法见文件头注释`); process.exit(2); }
if (existsSync(a.out) && !a.force) { console.error(`${a.out} 已存在。台账是这次迭代的唯一记录，不会覆盖；确实要重建请加 --force`); process.exit(2); }
const dir = dirname(resolve(a.out)); const rel = p => relative(dir, resolve(p)) || '.';
const tokens = readJson(a.tokens);
const people = Object.fromEntries(String(a.people ?? '').split(',').filter(Boolean).map(s => s.split('=').map(x => x.trim())));
const design = String(a.design ?? '').split(',').filter(Boolean).map(p => ({ path: rel(p) }));
const pageLinks = Object.fromEntries(String(a['design-url'] ?? '').split(',').filter(Boolean).map(s => { const i = s.indexOf('='); return [s.slice(0, i).trim(), s.slice(i + 1).trim()]; }));
const causes = a.causes ? readJson(a.causes) : undefined;
const ledger = {
  meta: { product: a.product, module: a.module, iteration: a.iteration, pages: String(a.pages ?? '').split(',').map(s => s.trim()).filter(Boolean),
    createdAt: new Date().toISOString().slice(0, 10), tokens: { path: rel(a.tokens), name: tokens.name, version: tokens.version }, design, people,
    ...(a.env && a.env !== true ? { env: a.env } : {}), ...(Object.keys(pageLinks).length ? { pageLinks } : {}), ...(causes ? { causes } : {}) },
  groups: [], findings: []
};
if (a.from) {
  const src = readJson(a.from); let skipped = 0;
  for (const f of src.findings ?? []) {
    if (f.module !== a.module) continue;
    if (f.type === '开发还原度' && !a['keep-fidelity']) { skipped++; continue; }
    const { status, recheck, checkpoint, ...rest } = f;
    const item = { ...rest, state: 'decide', round: 1 };
    item.category = categorize(item); item.signer = defaultSigner(item);
    item.history = [{ at: new Date().toISOString(), by: 'init', role: '系统', action: 'import', from: null, to: 'decide', note: `来自 ${a.from.split('/').pop()}，原状态 ${status}` }];
    ledger.findings.push(item);
  }
  const used = new Set(ledger.findings.map(f => f.group).filter(Boolean));
  ledger.groups = (src.groups ?? []).filter(g => used.has(g.id));
  console.log(`带入 ${ledger.findings.length} 个问题（全部为待决策）${skipped ? `；跳过 ${skipped} 个还原度问题，改由设计稿对照生成` : ''}`);
}
const v = validateLedger(ledger, tokens, dir);
if (v.errors.length) { console.error('带入的问题有结构错误，先修正来源文件：\n' + v.errors.map(e => '  - ' + e).join('\n')); process.exit(1); }
saveLedger(a.out, ledger);
console.log(`已建单 → ${a.out}（${a.product} · ${a.module} · ${a.iteration}）`);
if (!design.length) console.log('还没有登记设计稿。还原度需要冻结的设计稿 html，登记后运行 capture-baseline.mjs');
