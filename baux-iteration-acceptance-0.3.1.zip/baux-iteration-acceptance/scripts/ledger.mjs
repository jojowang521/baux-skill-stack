// 台账（iteration.json）的共享逻辑：状态、分类、签收人、守卫、准出判断。
// 所有写台账的脚本都走这里，页面和命令行用同一份准出判断，保证两边结论一致。
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, extname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { validate } from './lib.mjs';
import { checkRules, checkFingerprint, regressionContract } from './regression-contract.mjs';
export { checkRules, checkFingerprint, regressionContract } from './regression-contract.mjs';

export const STATES = { decide: '待决策', fix: '待修复', retest: '待复验', closed: '已关闭', out: '移出本迭代' };
export const CATEGORIES = { rule: '验收规则', interaction: '交互', visual: '视觉', fidelity: '还原度' };
export const SIGNERS = ['产品', '设计', '测试'];
export const ROLES = ['产品', '设计', '测试', '开发'];
export const OWNER_ROLE = { dev: '开发', design: '设计', product: '产品' };
const STATUS_OF = { decide: 'draft', fix: 'confirmed', retest: 'fixed', closed: 'verified', out: 'rejected' };

/** 证据可以是截图，也可以是录屏或动图。 */
export const IMAGE_EXT = ['.png', '.jpg', '.jpeg', '.webp', '.gif'];
export const VIDEO_EXT = ['.mp4', '.mov', '.webm'];
export const isVideo = p => VIDEO_EXT.includes(extname(String(p ?? '')).toLowerCase());
export const evidenceOk = p => [...IMAGE_EXT, ...VIDEO_EXT].includes(extname(String(p ?? '')).toLowerCase());

/** 问题原因分类：台账里有就用台账的，没有用默认的。 */
export function causesOf(ledger) {
  if (ledger?.meta?.causes?.groups) return ledger.meta.causes;
  return JSON.parse(readFileSync(resolve(dirname(fileURLToPath(import.meta.url)), '../assets/causes.json'), 'utf8'));
}
export const causeList = ledger => causesOf(ledger).groups.flatMap(g => g.items.map(item => ({ group: g.group, item })));
export function causeStats(ledger) {
  const stats = causesOf(ledger).groups.map(g => ({ group: g.group, items: g.items.map(item => ({ item, count: 0, ids: [] })) }));
  for (const f of ledger.findings) { const c = f.receipt?.cause; if (!c) continue; for (const g of stats) for (const it of g.items) if (it.item === c) { it.count++; it.ids.push(f.id); } }
  return stats;
}
const httpUrl = u => /^https?:\/\/[^\s]+$/.test(String(u ?? ''));

export class GuardError extends Error {}
const refuse = message => { throw new GuardError(message); };

export function loadLedger(path) {
  const ledger = JSON.parse(readFileSync(path, 'utf8'));
  ledger.findings ??= []; ledger.groups ??= [];
  return ledger;
}
export function saveLedger(path, ledger) { writeFileSync(path, JSON.stringify(ledger, null, 2) + '\n'); }
export const baseDir = path => dirname(resolve(path));

/** 新问题的默认分类和签收人。分类决定谁签收：规则→产品（功能缺陷→测试），交互、视觉、还原度→设计。 */
export function categorize(f) {
  if (f.category) return f.category;
  if (f.type === 'BUG问题' || f.owner === 'product') return 'rule';
  if (f.type === 'UI问题') return 'visual';
  if (f.type === '开发还原度') return 'fidelity';
  return 'interaction';
}
export function defaultSigner(f) {
  const cat = categorize(f);
  if (cat === 'rule') return f.type === 'BUG问题' ? '测试' : '产品';
  return '设计';
}
export const isAuto = f => Array.isArray(f.checks) && f.checks.length > 0;
export function autoPassed(f) {
  const a = f.auto, expected = checkRules(f);
  if (!a || !expected.length || a.contractVersion !== 1 || a.round !== (f.round ?? 1)
    || a.fingerprint !== checkFingerprint(f) || !String(a.targetVersion ?? '').trim()
    || !Array.isArray(a.items) || a.items.length !== expected.length) return false;
  const ids = new Set(a.items.map(r => r.ruleId));
  return ids.size === expected.length && expected.every(e => a.items.some(r => r.ruleId === e.id && r.acceptance === e.acceptance && r.status === 'passed'));
}
function invalidateAuto(f, reason) {
  if (f.auto) (f.autoHistory ??= []).push({ ...f.auto, invalidatedAt: new Date().toISOString(), reason });
  delete f.auto;
}
export const fileOk = (dir, p) => typeof p === 'string' && p.length > 0 && existsSync(resolve(dir, p));

/** 投影成验收 技能的 findings 结构，复用同一套字段校验（期望值来自 token、研发项必须有验收标准等）。 */
export function toFindings(ledger) {
  return {
    meta: { product: ledger.meta?.product },
    groups: ledger.groups,
    findings: ledger.findings.map(f => ({ ...f, status: STATUS_OF[f.state] ?? f.state, recheck: f.state === 'closed' ? { result: 'pass' } : f.recheck, rejectReason: f.outReason ?? f.rejectReason }))
  };
}

/** 结构校验：字段是否齐全、取值是否合法。流程规则（截图、签收人）由守卫和准出判断负责。 */
export function validateLedger(ledger, tokens, dir) {
  const v = validate(toFindings(ledger), tokens);
  v.errors = v.errors.filter(e => !e.startsWith('findings: 没有任何问题')); // 刚建单、还没有问题是正常的
  const err = (id, m) => v.errors.push(`${id}: ${m}`);
  const warn = (id, m) => v.warnings.push(`${id}: ${m}`);
  for (const key of ['product', 'module', 'iteration']) if (!ledger.meta?.[key]) err('meta', `缺少 ${key}`);
  for (const [page, url] of Object.entries(ledger.meta?.pageLinks ?? {})) if (!httpUrl(url)) err('meta', `页面「${page}」的设计稿链接不是 http(s) 地址`);
  if (ledger.meta?.env && !httpUrl(ledger.meta.env)) err('meta', '测试环境只记地址，不能是其他内容');
  if (/password|passwd|密码|口令/i.test(JSON.stringify(ledger.meta ?? {}))) err('meta', '台账里不能记账号密码，测试环境只记地址');
  for (const g of ledger.groups ?? []) for (const l of g.specs ?? []) if (!httpUrl(l.url)) err(g.id, `规范链接不是 http(s) 地址：${l.url}`);
  for (const f of ledger.findings) {
    if (!(f.state in STATES)) err(f.id, `state 无效：${f.state}`);
    if (!(f.category in CATEGORIES)) err(f.id, `category 无效：${f.category}`);
    if (!SIGNERS.includes(f.signer)) err(f.id, `signer 只能是 ${SIGNERS.join(' / ')}`);
    if (f.state === 'out' && !f.outReason) err(f.id, '移出本迭代需要 outReason');
    if (f.state === 'closed' && f.signoff?.role !== f.signer) err(f.id, `已关闭但签收人不是指定的 ${f.signer}`);
    if (['retest', 'closed'].includes(f.state) && !f.receipt) err(f.id, '待复验或已关闭的项需要修复回执 receipt');
    for (const k of ['before', 'after']) if (f.shots?.[k] && dir && !fileOk(dir, f.shots[k])) warn(f.id, `证据文件不存在：${f.shots[k]}`);
    if (f.receipt?.cause && !causeList(ledger).some(c => c.item === f.receipt.cause)) err(f.id, `问题原因“${f.receipt.cause}”不在分类里`);
    for (const l of [...(f.links ?? []), ...(f.ticket ? [f.ticket] : [])]) if (l.url && !httpUrl(l.url)) err(f.id, `链接不是 http(s) 地址：${l.url}`);
  }
  return v;
}

/** 准出条件。返回逐条结果和总结论。页面、status 命令都用它。 */
export function exitCheck(ledger, dir, tokens) {
  let validation;
  try { validation = validateLedger(ledger, tokens ?? JSON.parse(readFileSync(resolve(dir, ledger.meta.tokens.path), 'utf8')), dir); }
  catch (error) { validation = { errors: [error.message] }; }
  const items = ledger.findings.filter(f => f.state !== 'out');
  const ids = list => list.map(f => f.id);
  const decide = items.filter(f => f.state === 'decide');
  const highOpen = items.filter(f => f.severity === '高' && f.state !== 'closed');
  const otherOpen = items.filter(f => f.severity !== '高' && f.state !== 'closed');
  const autos = items.filter(isAuto); const autoBad = autos.filter(f => !(f.state === 'closed' && autoPassed(f)));
  const dispatched = items.filter(f => ['fix', 'retest', 'closed'].includes(f.state));
  const noBefore = dispatched.filter(f => !fileOk(dir, f.shots?.before));
  const tested = items.filter(f => ['retest', 'closed'].includes(f.state));
  const noAfter = tested.filter(f => !fileOk(dir, f.shots?.after));
  const fid = ledger.meta?.fidelity;
  const rules = [
    { key: 'structure', ok: !validation.errors.length, text: '台账结构与签收记录校验通过', detail: validation.errors.length ? validation.errors.join('；') : '无结构错误', ids: [] },
    { key: 'decide', ok: !decide.length, text: '没有待决策的项：方案都已拍板，或已移出本迭代', detail: decide.length ? `还有 ${decide.length} 项` : '0 项', ids: ids(decide) },
    { key: 'high', ok: !highOpen.length, text: '高严重度问题全部关闭', detail: highOpen.length ? `还有 ${highOpen.length} 项` : '已全部关闭', ids: ids(highOpen) },
    { key: 'other', ok: !otherOpen.length, text: '中、低严重度问题全部关闭，或由签收人同意移到下一迭代', detail: otherOpen.length ? `还有 ${otherOpen.length} 项` : '已处理', ids: ids(otherOpen) },
    { key: 'auto', ok: !autoBad.length, text: '自动检查项最近一次回归全部通过，并已签收', detail: autos.length ? `${autos.length - autoBad.length}/${autos.length} 项` : '没有自动项', ids: ids(autoBad) },
    { key: 'before', ok: !noBefore.length, text: '已下发的项都有现状截图或录屏', detail: noBefore.length ? `缺 ${noBefore.length} 项` : '齐全', ids: ids(noBefore) },
    { key: 'after', ok: !noAfter.length, text: '提测的项都有修复后截图或录屏', detail: tested.length ? (noAfter.length ? `缺 ${noAfter.length} 项` : '齐全') : '暂无提测项', ids: ids(noAfter) }
  ];
  if (fid) rules.push({ key: 'fidelity', ok: !(fid.missing ?? []).length && fid.compared > 0, text: '设计稿里标注的元素，在开发页面上都找得到并已对照', detail: `${fid.compared}/${fid.total} 个元素`, ids: [] , missing: fid.missing ?? [] });
  else rules.push({ key: 'fidelity', ok: false, text: '设计稿里标注的元素，在开发页面上都找得到并已对照', detail: '还没有对照设计稿', ids: [] });
  return { rules, pass: rules.every(r => r.ok) };
}

/** 状态推进。每个动作都过守卫，拒绝时抛 GuardError，不写台账。 */
export function act(ledger, dir, action, opts) {
  const { by, role, note } = opts;
  if (!by) refuse('需要 --by 写明操作人');
  if (!ROLES.includes(role)) refuse(`--role 只能是 ${ROLES.join(' / ')}`);
  const find = id => ledger.findings.find(f => f.id === id) ?? refuse(`没有 ${id}`);
  const log = (f, from, extra = {}) => { (f.history ??= []).push({ at: opts.at ?? new Date().toISOString(), by, role, action, from, to: f.state, ...(note ? { note } : {}), ...extra }); };
  const done = [];
  // 回复异议：当前异议和异议记录里的最后一条同时写上（保存后两者是不同对象）
  const answer = f => { const r = { by, role, note, at: opts.at ?? new Date().toISOString() }; f.dispute.reply = r; if (f.disputes?.length) f.disputes.at(-1).reply = r; };

  if (action === 'attach') {
    const f = find(opts.id);
    for (const k of ['before', 'after']) if (opts[k]) {
      if (!evidenceOk(opts[k])) refuse(`${f.id}: 证据只能是截图（png/jpg/webp/gif）或录屏（mp4/mov/webm）`);
      if (!fileOk(dir, opts[k])) refuse(`${f.id}: 找不到证据文件 ${opts[k]}（路径相对台账所在目录）`); (f.shots ??= {})[k] = opts[k];
    }
    log(f, f.state, { attached: Object.keys(opts).filter(k => k === 'before' || k === 'after') }); done.push(f.id);
  }

  else if (action === 'decide') {
    if (!['产品', '设计'].includes(role)) refuse('方案只能由产品或设计拍板');
    for (const id of opts.ids) {
      const f = find(id);
      if (f.state !== 'decide') refuse(`${id}: 当前是“${STATES[f.state]}”，只有待决策的项可以下发`);
      if (f.dispute && !f.dispute.reply) { if (!note) refuse(`${id}: 修改方提了异议（${f.dispute.note}），重新下发前要用 --note 回复`); answer(f); }
      if (opts.owner) { if (!(opts.owner in OWNER_ROLE)) refuse('--owner 只能是 dev / design / product'); f.owner = opts.owner; }
      if (opts.expected) f.expected = opts.expected;
      if (opts.acceptance) f.acceptance = opts.acceptance;
      if (opts.signer) { if (!SIGNERS.includes(opts.signer)) refuse(`--signer 只能是 ${SIGNERS.join(' / ')}`); f.signer = opts.signer; }
      if (!fileOk(dir, f.shots?.before)) refuse(`${id}: 没有现状截图或录屏，不能下发。先用 attach --before 补上`);
      if (f.owner === 'dev' && !(f.expected && f.acceptance?.length)) refuse(`${id}: 交给开发的项需要期望行为和验收标准（--expected、--acceptance）`);
      const from = f.state; invalidateAuto(f, '重新拍板下发，需使用当前方案重新回归'); f.state = 'fix'; f.round = f.round ?? 1; log(f, from); done.push(id);
    }
  }

  else if (action === 'defer') {
    if (!note) refuse('移出本迭代需要 --note 写明原因');
    for (const id of opts.ids) {
      const f = find(id);
      if (f.state === 'closed' || f.state === 'out') refuse(`${id}: 当前是“${STATES[f.state]}”，不能移出`);
      if (f.severity === '高' && role !== '产品') refuse(`${id}: 高严重度问题只能由产品决定移出本迭代`);
      if (f.severity !== '高' && role !== '产品' && role !== f.signer) refuse(`${id}: 只有产品或签收人（${f.signer}）可以把它移到下一迭代`);
      if (f.dispute && !f.dispute.reply) answer(f);
      const from = f.state; f.state = 'out'; f.outReason = note; log(f, from); done.push(id);
    }
  }

  else if (action === 'receipt') {
    for (const entry of opts.entries) {
      const f = find(entry.id);
      if (f.state !== 'fix') refuse(`${f.id}: 当前是“${STATES[f.state]}”，只有待修复的项可以提交回执`);
      if (role !== OWNER_ROLE[f.owner]) refuse(`${f.id}: 这项由${OWNER_ROLE[f.owner]}修改，回执也要由${OWNER_ROLE[f.owner]}提交`);
      if (!entry.note) refuse(`${f.id}: 回执需要写修改说明 note`);
      if (!fileOk(dir, entry.after)) refuse(`${f.id}: 回执需要修复后截图或录屏（after），文件 ${entry.after ?? '未填'} 不存在`);
      if (!evidenceOk(entry.after)) refuse(`${f.id}: 修复后证据只能是截图或录屏`);
      if (!entry.cause) refuse(`${f.id}: 回执要选问题原因（cause），可选：${causeList(ledger).map(c => c.item).join('、')}`);
      if (!causeList(ledger).some(c => c.item === entry.cause)) refuse(`${f.id}: 问题原因“${entry.cause}”不在分类里，可选：${causeList(ledger).map(c => c.item).join('、')}`);
      if (isAuto(f) && !autoPassed(f)) refuse(`${f.id}: 有自动检查，提测前自测必须全部通过。先导入自测结果（results），当前${f.auto ? `：通过 ${f.auto.counts.passed}，失败 ${f.auto.counts.failed}，未执行 ${f.auto.counts.notRun}，错误 ${f.auto.counts.error}` : '还没有自测结果'}`);
    }
    for (const entry of opts.entries) {
      const f = find(entry.id); const from = f.state;
      f.receipt = { by, at: opts.at ?? new Date().toISOString(), note: entry.note, cause: entry.cause, ...(entry.commit ? { commit: entry.commit } : {}), round: f.round ?? 1 };
      (f.shots ??= {}).after = entry.after; f.state = 'retest'; log(f, from); done.push(f.id);
    }
  }

  else if (action === 'results') {
    const report = opts.report;
    if (report?.meta?.contractVersion !== 1) refuse('回归报告缺少 0.3.1 检查契约，请重新生成分发包并运行回归');
    if (!Number.isFinite(Date.parse(report.meta.generatedAt))) refuse('回归报告 generatedAt 不是有效时间');
    if (typeof report.meta.targetVersion !== 'string' || !report.meta.targetVersion.trim()) refuse('回归报告必须记录被测版本 targetVersion');
    if (!Array.isArray(report.results) || !report.results.length) refuse('回归报告没有检查结果');
    const grouped = new Map(), seen = new Set();
    // Validate the complete import before changing any finding.
    for (const r of report.results) {
      const f = find(r.findingId), expected = checkRules(f).find(e => e.id === r.ruleId);
      if (!expected || expected.acceptance !== r.acceptance) refuse(`${f.id}: 报告含未知或已变更的检查 ${r.ruleId}`);
      if (seen.has(r.ruleId)) refuse(`报告重复包含检查 ${r.ruleId}`); seen.add(r.ruleId);
      if (!['passed', 'failed', 'notRun', 'error'].includes(r.status)) refuse(`${r.ruleId}: 无效结果状态`);
      const contract = regressionContract(f);
      if (r.round !== contract.round || r.fingerprint !== contract.fingerprint) refuse(`${f.id}: 报告轮次或规则版本已过期，请更新分发包并重新回归`);
      const latest = [f.auto, ...(f.autoHistory ?? [])].filter(Boolean).map(a => Date.parse(a.runAt)).filter(Number.isFinite);
      if (latest.length && Date.parse(report.meta.generatedAt) < Math.max(...latest)) refuse(`${f.id}: 不能用较旧的报告覆盖较新的结果`);
      (grouped.get(f.id) ?? grouped.set(f.id, []).get(f.id)).push(r);
    }
    for (const [id, rs] of grouped) {
      const f = find(id), contract = regressionContract(f);
      const items = checkRules(f).map(e => {
        const r = rs.find(r => r.ruleId === e.id);
        return { ruleId: e.id, acceptance: e.acceptance, status: r?.status ?? 'notRun', actual: r?.actual ?? '报告未包含此检查' };
      });
      const count = status => items.filter(r => r.status === status).length;
      invalidateAuto(f, '被新回归结果替代');
      f.auto = { contractVersion: 1, ...contract, targetVersion: report.meta.targetVersion.trim(),
        runAt: report.meta.generatedAt, source: opts.source ?? role, variant: report.meta.variant || null,
        counts: { passed: count('passed'), failed: count('failed'), notRun: count('notRun'), error: count('error') }, items };
      const from = f.state;
      if (!autoPassed(f) && ['retest', 'closed'].includes(f.state)) {
        const counts = f.auto.counts; invalidateAuto(f, '复验未全过，进入新的修复轮次');
        f.state = 'fix'; f.round = (f.round ?? 1) + 1; delete f.signoff; delete f.receipt;
        log(f, from, { reason: '回归未全部通过，退回待修复', auto: counts });
      } else log(f, from, { auto: f.auto.counts });
      done.push(id);
    }
  }

  else if (action === 'sign') {
    const result = opts.result;
    if (!['pass', 'fail'].includes(result)) refuse('--result 只能是 pass 或 fail');
    if (result === 'fail' && !note) refuse('复验不通过需要 --note 写明哪里不对');
    const targets = opts.autoPassed ? ledger.findings.filter(f => f.state === 'retest' && f.signer === role && isAuto(f) && autoPassed(f)).map(f => f.id) : opts.ids;
    if (!targets.length) refuse(opts.autoPassed ? `没有轮到${role}签收、且自动检查全部通过的项` : '需要 --id');
    for (const id of targets) {
      const f = find(id);
      if (f.state !== 'retest') refuse(`${id}: 当前是“${STATES[f.state]}”，只有待复验的项可以签收`);
      if (role !== f.signer) refuse(`${id}: 这项由${f.signer}签收，${role}不能代签`);
      if (result === 'pass') {
        if (!fileOk(dir, f.shots?.after)) refuse(`${id}: 没有修复后截图或录屏，不能签收`);
        if (isAuto(f) && !autoPassed(f)) refuse(`${id}: 自动检查没有全部通过，不能签收`);
      }
    }
    for (const id of targets) {
      const f = find(id); const from = f.state;
      if (result === 'pass') { f.state = 'closed'; f.signoff = { by, role, at: opts.at ?? new Date().toISOString(), ...(note ? { note } : {}) }; }
      else { invalidateAuto(f, '人工复验退回'); f.state = 'fix'; f.round = (f.round ?? 1) + 1; f.lastReject = { by, role, note, at: opts.at ?? new Date().toISOString() }; delete f.receipt; }
      log(f, from); done.push(id);
    }
  }
  else if (action === 'dispute') {
    if (!note) refuse('提异议需要 --note 写明理由，比如“这是框架统一行为，本模块改不了”');
    for (const id of opts.ids) {
      const f = find(id);
      if (f.state !== 'fix') refuse(`${id}: 当前是“${STATES[f.state]}”，只有待修复的项可以提异议`);
      if (role !== OWNER_ROLE[f.owner]) refuse(`${id}: 这项由${OWNER_ROLE[f.owner]}修改，异议也要由${OWNER_ROLE[f.owner]}提出`);
      const from = f.state; invalidateAuto(f, '修改方提出异议，方案需重新确认'); f.state = 'decide'; f.dispute = { by, role, note, at: opts.at ?? new Date().toISOString(), round: f.round ?? 1 };
      (f.disputes ??= []).push(f.dispute); log(f, from); done.push(id);
    }
  }

  else if (action === 'link') {
    for (const id of opts.ids) {
      const f = find(id);
      if (opts.ticket) { if (opts.url && !httpUrl(opts.url)) refuse('--url 需要 http(s) 地址'); f.ticket = { id: opts.ticket, ...(opts.system ? { system: opts.system } : {}), ...(opts.url ? { url: opts.url } : {}) }; }
      else if (opts.url) { if (!httpUrl(opts.url)) refuse('--url 需要 http(s) 地址'); (f.links ??= []).push({ label: opts.label || '链接', url: opts.url }); }
      else refuse('link 需要 --ticket 单号，或 --url 链接');
      log(f, f.state, { linked: opts.ticket ?? opts.url }); done.push(id);
    }
  }
  else refuse(`不认识的动作：${action}`);
  return done;
}

/** 加载 Playwright：先按包名找，找不到再试全局安装目录。 */
export async function loadPlaywright() {
  try { return await import('playwright'); } catch { /* 继续 */ }
  const req = createRequire(import.meta.url);
  for (const base of [process.env.NODE_PATH, '/usr/local/lib/node_modules', '/usr/lib/node_modules'].filter(Boolean)) {
    try { return req(resolve(base, 'playwright')); } catch { /* 继续 */ }
  }
  console.error('找不到 Playwright。请先 npm install playwright，并执行 npx playwright install chromium'); process.exit(2);
}

/** Optional local browser path for managed environments; normal installs use Playwright's browser. */
export async function launchBrowser(options = {}) {
  const { chromium } = await loadPlaywright();
  return chromium.launch({ ...options, ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE } : {}) });
}

export function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) { const k = a.slice(2); const v = argv[i + 1]; if (v === undefined || v.startsWith('--')) out[k] = true; else { out[k] = v; i++; } }
    else out._.push(a);
  }
  return out;
}
