#!/usr/bin/env node
// 生成交给开发的分发包：待修复清单、现状截图、回归包（自测用）、修复回执模板。
// 用法：node dispatch.mjs --ledger iteration.json --out dispatch/ [--include-retest]
// 重复生成不会覆盖开发已经填好的 regression/selectors.json、regression.config.json 和 receipt.json。
import { copyFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, resolveToken } from './lib.mjs';
import { checkRules, regressionContract } from './regression-contract.mjs';
import { CATEGORIES, OWNER_ROLE, baseDir, causeList, fileOk, isAuto, isVideo, loadLedger, parseArgs } from './ledger.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const a = parseArgs(process.argv.slice(2));
if (!a.ledger || !a.out) { console.error('用法：dispatch.mjs --ledger iteration.json --out 目录'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger); const out = resolve(a.out);
const tokens = readJson(resolve(dir, ledger.meta.tokens.path));
const states = a['include-retest'] ? ['fix', 'retest'] : ['fix'];
const m = ledger.meta;
const items = ledger.findings.filter(f => states.includes(f.state) || (a['include-closed'] && f.state === 'closed' && isAuto(f))).sort((x, y) => '高中低'.indexOf(x.severity) - '高中低'.indexOf(y.severity));
const devItems = items.filter(f => f.owner === 'dev'); const otherItems = items.filter(f => f.owner !== 'dev');
if (!items.length) { console.log('没有待修复的项，不需要分发'); process.exit(0); }
mkdirSync(join(out, 'shots'), { recursive: true });
const keep = (p, make) => { if (existsSync(p)) { try { return readJson(p); } catch { /* 损坏重建 */ } } return make(); };

/* 1 清单 */
const shotOf = f => { if (!fileOk(dir, f.shots?.before)) return null; const name = `${f.id}-现状${f.shots.before.slice(f.shots.before.lastIndexOf('.'))}`; copyFileSync(resolve(dir, f.shots.before), join(out, 'shots', name)); return `shots/${name}`; };
const block = f => {
  const shot = shotOf(f);
  return [`### ${f.id} ${f.title}`, '',
    `- 页面：${f.page} · 严重度：${f.severity} · 类别：${CATEGORIES[f.category]} · 签收：${f.signer}${f.round > 1 ? ` · **第 ${f.round} 轮**` : ''}${isAuto(f) ? ' · 有自动检查' : ''}`,
    ...(f.ticket ? [`- 单号：${f.ticket.system && !f.ticket.id.startsWith(f.ticket.system) ? f.ticket.system + ' ' : ''}${f.ticket.id}${f.ticket.url ? `（${f.ticket.url}）` : ''}`] : []),
    ...((f.links ?? []).length || m.pageLinks?.[f.page] ? [`- 链接：${[...(m.pageLinks?.[f.page] ? [`设计稿 ${m.pageLinks[f.page]}`] : []), ...(f.links ?? []).map(l => `${l.label} ${l.url}`)].join('；')}`] : []),
    ...(f.dispute?.reply ? [`- 异议与回复：${f.dispute.role} ${f.dispute.by}：${f.dispute.note} → ${f.dispute.reply.role} ${f.dispute.reply.by}：${f.dispute.reply.note}`] : []),
    ...(f.lastReject ? [`- **上一轮复验不通过**（${f.lastReject.role} ${f.lastReject.by}）：${f.lastReject.note}`] : []),
    `- 现状：${f.actual}`, `- 期望：${f.expected}`,
    ...(f.tokenRef ? [`- 取值：${f.tokenRef} = ${f.expectedValue}（实测 ${f.actualValue}）`] : []),
    '', '复现步骤：', ...f.repro.map((s, i) => `${i + 1}. ${s}`),
    ...(f.acceptance?.length ? ['', '验收标准：', ...f.acceptance.map(s => `- [ ] ${s}`)] : []),
    ...(f.suggestion ? ['', `修改建议：${f.suggestion}`] : []),
    ...(shot ? ['', isVideo(shot) ? `现状录屏：[${shot}](${shot})` : `![现状](${shot})`] : []), ''].join('\n');
};
writeFileSync(join(out, '待修复清单.md'), [`# ${m.product} · ${m.module} · ${m.iteration} 待修复清单`, '',
  `共 ${devItems.length} 项交开发${otherItems.length ? `，另有 ${otherItems.length} 项由设计或产品自己改（见文末）` : ''}。设计稿：${m.design.map(d => `${basename(d.path)} v${d.version ?? '?'}`).join('、') || '无'}；token：${m.tokens.name} ${m.tokens.version}。`, '',
  ...(m.env ? [`测试环境：${m.env}（账号请向测试负责人获取，不写在这里）`, ''] : []),
  '提测前请：1）跑回归包自测，带“有自动检查”的项必须全部通过；2）每项附一张修复后截图或录屏；3）填好 receipt.json（含问题原因）一起交回。', '',
  '觉得某一项不该由你改、或方案行不通？不要硬改，在回执里删掉这项，单独把理由交给产品或设计，由他们登记为异议、重新拍板。', '',
  ...(m.fidelity?.missing?.length ? ['## 开发页缺少的 data-testid', '', `设计稿 ${m.fidelity.baseline} 里标注了这些元素，开发页找不到，还原度无法对照。请在对应元素上加同名 data-testid：`, '', ...m.fidelity.missing.map(r => `- \`${r}\``), ''] : []),
  ...devItems.map(block), ...(otherItems.length ? ['---', '', '## 设计 / 产品自己改的项', '', ...otherItems.map(f => `- ${f.id} ${f.title}（${OWNER_ROLE[f.owner]}处理）`)] : [])].join('\n') + '\n');

/* 2 回归包 */
const rdir = join(out, 'regression'); mkdirSync(rdir, { recursive: true });
const DIM_BY_PROP = { color: 'color', backgroundColor: 'color', borderTopColor: 'color', height: 'size', borderTopLeftRadius: 'size', fontSize: 'typography', lineHeight: 'typography', fontWeight: 'typography', paddingTop: 'spacing', paddingBottom: 'spacing', paddingLeft: 'spacing', paddingRight: 'spacing', gap: 'spacing' };
const rules = [];
for (const f of devItems.filter(isAuto)) for (const { id, check } of checkRules(f)) {
  const rule = { id, ...regressionContract(f), findingId: f.id, acceptance: check.acceptance, acceptanceText: f.acceptance[check.acceptance], title: f.title, severity: f.severity, status: 'confirmed', page: f.page, kind: check.kind, slots: check.slots ?? {}, mock: check.mock ?? [] };
  if (check.kind === 'style' || check.kind === 'transition') {
    const token = check.tokenRef ? resolveToken(tokens, check.tokenRef) : null;
    rule.dimension = check.kind === 'transition' ? 'motion' : (token?.dim ?? DIM_BY_PROP[check.property] ?? f.dimension);
    rule.spec = { property: check.property, expected: token ? token.value : check.expected, tokenRef: check.tokenRef ?? null, state: check.state ?? null, all: Boolean(check.all), reducedMotion: Boolean(check.reducedMotion) };
    rule.expectedText = `${check.property}${check.kind === 'transition' ? ' 过渡时长' : ''} = ${rule.spec.expected}${check.tokenRef ? `（${check.tokenRef}）` : ''}`;
  } else if (check.kind === 'focus') { rule.spec = {}; rule.expectedText = 'Tab 键聚焦后有可见的聚焦样式'; }
  else { rule.spec = { steps: check.steps }; rule.expectedText = '按步骤操作后，每一条“应…”判断都成立'; }
  rule.refs = check.refs ?? {};
  rules.push(rule);
}
const oldSel = keep(join(rdir, 'selectors.json'), () => ({})); const selectors = {}; let missing = 0;
for (const r of rules) { selectors[r.id] = {}; for (const name of Object.keys(r.slots)) { const old = oldSel[r.id]?.[name]; const pre = r.refs[name] ? `[data-testid='${r.refs[name]}']` : ''; selectors[r.id][name] = typeof old === 'string' && old ? old : pre; if (!selectors[r.id][name]) missing++; } }
const pages = [...new Set(rules.map(r => r.page))];
const config = keep(join(rdir, 'regression.config.json'), () => ({ target: { root: '../app', note: '被测页面所在的静态目录；线上环境请改写 pages 里的地址' }, pages: {}, viewport: { width: 1440, height: 900 }, timeoutMs: 8000, stepTimeoutMs: 3000, settleMs: 600, mockDelayMs: 800 }));
config.pages ??= {}; for (const p of pages) if (!(p in config.pages)) config.pages[p] = '';
writeFileSync(join(rdir, 'rules.json'), JSON.stringify({ generatedFrom: basename(a.ledger), iteration: `${m.module} ${m.iteration}`, tokenSet: { name: tokens.name, version: tokens.version }, tolerance: tokens.tolerance ?? {}, rules }, null, 2) + '\n');
writeFileSync(join(rdir, 'selectors.json'), JSON.stringify(selectors, null, 2) + '\n');
writeFileSync(join(rdir, 'regression.config.json'), JSON.stringify(config, null, 2) + '\n');
const runner = resolve(here, '../assets/regression-runner');
for (const f of ['run.mjs', 'semantics.mjs', 'semantics.test.mjs', 'package.json', 'README.md']) copyFileSync(join(runner, f), join(rdir, f));
copyFileSync(join(here, 'lib.mjs'), join(rdir, 'lib.mjs'));

/* 3 回执模板 */
const receiptPath = join(out, 'receipt.json');
const receipt = keep(receiptPath, () => ({ items: [] }));
for (const f of items) if (!receipt.items.some(x => x.id === f.id)) receipt.items.push({ id: f.id, title: f.title, note: '', cause: '', commit: '', after: `shots/${f.id}-修复后.png` });
receipt.causeOptions = causeList(ledger).map(c => `${c.group}：${c.item}`);
writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
writeFileSync(join(out, 'README.md'), `# 开发分发包 · ${m.module} ${m.iteration}

1. 看 \`待修复清单.md\`，每项都有复现步骤、期望和验收标准。
2. 修完后自测：进 \`regression/\`，按里面的 README 填页面地址（选择器已按 data-testid 预填，名字和设计稿 data-ref 一致），运行 \`node run.mjs\`。
   报告在 \`regression/reports/regression-report.json\`，带自动检查的项必须全部通过才能提测。
3. 每项截一张修复后的图，放到 \`shots/\`，文件名与 receipt.json 里的 after 一致。
4. 填 \`receipt.json\`：每项写一句改了什么（note），从 causeOptions 里选一个问题原因填进 cause（只填冒号后面的部分），有提交号就填 commit。没修的项从文件里删掉，不要留空。
   截图换成录屏也可以（mp4 / mov / webm），after 写对应的文件名。
   对某一项有异议（不该你改、方案行不通），不要硬改，把理由交给产品或设计登记为异议。
5. 把 receipt.json、shots/ 和自测报告一起交回给产品或设计导入。
`);
/* 4 建单表格：用来在 TAPD / Jira 等系统批量建单，建好后用 act.mjs link --file 把单号挂回来 */
const csvCell = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
const csv = [['问题编号', '标题', '页面', '严重度', '类别', '修改方', '签收', '期望', '验收标准', '现有单号'].map(csvCell).join(',')]
  .concat(items.map(f => [f.id, f.title, f.page, f.severity, CATEGORIES[f.category], OWNER_ROLE[f.owner], f.signer, f.expected, (f.acceptance ?? []).join('；'), f.ticket?.id ?? ''].map(csvCell).join(',')));
writeFileSync(join(out, '建单表格.csv'), '\ufeff' + csv.join('\n') + '\n');
console.log(`分发包 → ${out}`);
console.log(`  交开发 ${devItems.length} 项，其中 ${devItems.filter(isAuto).length} 项带自动检查（${rules.length} 条规则）${otherItems.length ? `；设计/产品自己改 ${otherItems.length} 项` : ''}`);
console.log(`  选择器：已按 data-testid 预填 ${rules.reduce((n, r) => n + Object.keys(r.slots).length, 0) - missing} 个，待开发填写 ${missing} 个`);
const unmapped = pages.filter(p => !config.pages[p]); if (unmapped.length) console.log(`  regression.config.json 还有 ${unmapped.length} 个页面没配地址：${unmapped.join('、')}`);
