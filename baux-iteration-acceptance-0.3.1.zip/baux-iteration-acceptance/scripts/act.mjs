#!/usr/bin/env node
// 推进状态。每个动作都有守卫，不满足就拒绝，台账不变。
// 用法：node act.mjs <动作> --ledger iteration.json --by 姓名 --role 产品|设计|测试|开发 [参数]
//   attach  --id F-001 [--before 图] [--after 图]                补截图（路径相对台账目录）
//   decide  --id F-001[,F-002] [--owner dev|design|product] [--expected 文本] [--acceptance "标准1|标准2"] [--signer 产品|设计|测试]
//   defer   --id F-001 --note 原因                                移到下一迭代
//   receipt --file receipt.json                                   修复回执（开发或改稿的设计提交）
//   results --report regression-report.json [--source 自测|测试环境]   导入回归结果
//   sign    (--id F-001[,…] | --auto-passed) --result pass|fail [--note 说明]
//   dispute --id F-013 --note 理由                               修改方提异议，退回待决策；拍板人用 decide --note 回复后重新下发，或 defer
//   link    --id F-007 --ticket TAPD-1001 [--system TAPD] [--url 地址]   挂外部单号
//   link    --id F-007 --url 地址 [--label 名称]                 挂其他链接（设计稿、规范、讨论记录）
//   link    --file tickets.json                                  批量挂单号：[{ "id": "F-007", "ticket": "TAPD-1001", "url": "…" }]
// 证据（--before、--after、回执 after）可以是截图（png/jpg/webp/gif）或录屏（mp4/mov/webm）。
// 退出码：0 成功；1 守卫拒绝或校验失败；2 参数错误。
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, extname, resolve } from 'node:path';
import { readJson } from './lib.mjs';
import { GuardError, act, baseDir, loadLedger, parseArgs, saveLedger, validateLedger, STATES } from './ledger.mjs';
const a = parseArgs(process.argv.slice(2)); const action = a._[0];
if (!action || !a.ledger) { console.error('用法见文件头注释'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
const tokens = readJson(`${dir}/${ledger.meta.tokens.path}`);
const opts = { by: a.by === true ? undefined : a.by, role: a.role, note: a.note === true ? undefined : a.note, at: a.at,
  id: a.id, ids: String(a.id ?? '').split(',').map(s => s.trim()).filter(Boolean), owner: a.owner, expected: a.expected, signer: a.signer,
  acceptance: a.acceptance ? String(a.acceptance).split('|').map(s => s.trim()).filter(Boolean) : undefined,
  before: a.before, after: a.after, result: a.result, autoPassed: Boolean(a['auto-passed']), source: a.source,
  ticket: a.ticket === true ? undefined : a.ticket, system: a.system === true ? undefined : a.system, url: a.url === true ? undefined : a.url, label: a.label === true ? undefined : a.label };
if (action === 'attach') {
  // 截图可以在任何位置，统一拷进台账目录的 shots/
  for (const k of ['before', 'after']) if (typeof opts[k] === 'string') {
    const src = resolve(opts[k]); if (!existsSync(src)) { console.error(`拒绝：找不到截图文件 ${opts[k]}`); process.exit(1); }
    mkdirSync(resolve(dir, 'shots'), { recursive: true });
    const name = `shots/${opts.id}-${k}${extname(src)}`; if (resolve(dir, name) !== src) copyFileSync(src, resolve(dir, name)); opts[k] = name;
  }
}
if (action === 'receipt') {
  if (!a.file) { console.error('receipt 需要 --file'); process.exit(2); }
  const r = readJson(a.file); const rdir = dirname(resolve(a.file));
  // 回执里的截图路径相对回执文件；拷进台账目录的 shots/，按轮次命名，旧轮次的图保留
  opts.entries = (Array.isArray(r) ? r : r.items).filter(e => e.note || e.commit).map(e => {
    const src = e.after ? resolve(rdir, e.after) : null; const f = ledger.findings.find(x => x.id === e.id);
    if (!src || !existsSync(src) || !f) return e;
    mkdirSync(resolve(dir, 'shots'), { recursive: true });
    const name = `shots/${e.id}-after-r${f.round ?? 1}${extname(src)}`; copyFileSync(src, resolve(dir, name));
    return { ...e, after: name };
  });
}
if (action === 'results') { if (!a.report) { console.error('results 需要 --report'); process.exit(2); } opts.report = readJson(a.report); }
try {
  let done;
  if (action === 'link' && a.file) { done = []; for (const e of readJson(a.file)) done.push(...act(ledger, dir, 'link', { ...opts, ids: [e.id], ticket: e.ticket, system: e.system ?? opts.system, url: e.url, label: e.label })); }
  else done = act(ledger, dir, action, opts);
  const v = validateLedger(ledger, tokens, dir);
  if (v.errors.length) { console.error('操作后台账校验不通过，没有保存：\n' + v.errors.map(e => '  - ' + e).join('\n')); process.exit(1); }
  saveLedger(a.ledger, ledger);
  for (const id of done) { const f = ledger.findings.find(x => x.id === id); console.log(`${id}  → ${STATES[f.state]}${f.round > 1 ? `（第 ${f.round} 轮）` : ''}${f.auto && action === 'results' ? `  自动：通过 ${f.auto.counts.passed} / 失败 ${f.auto.counts.failed} / 未执行 ${f.auto.counts.notRun} / 错误 ${f.auto.counts.error}` : ''}`); }
} catch (e) {
  if (e instanceof GuardError) { console.error('拒绝：' + e.message); process.exit(1); }
  throw e;
}
