#!/usr/bin/env node
// 把验收中新发现的问题加进台账。新问题一律“待决策”，由产品或设计拍板后才下发。
// 用法：node add-findings.mjs --ledger iteration.json --file new.json   （new.json 是问题数组，字段同 references/ledger-schema.md）
import { readJson } from './lib.mjs';
import { baseDir, categorize, defaultSigner, loadLedger, parseArgs, saveLedger, validateLedger } from './ledger.mjs';
const a = parseArgs(process.argv.slice(2));
if (!a.ledger || !a.file) { console.error('用法：add-findings.mjs --ledger iteration.json --file new.json'); process.exit(2); }
const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
const tokens = readJson(`${dir}/${ledger.meta.tokens.path}`);
const incoming = readJson(a.file); const list = Array.isArray(incoming) ? incoming : incoming.findings;
let n = Math.max(0, ...ledger.findings.map(f => Number(f.id.slice(2)) || 0));
for (const raw of list) {
  const { status, recheck, ...f } = raw;
  f.id = f.id && !ledger.findings.some(x => x.id === f.id) ? f.id : `F-${String(++n).padStart(3, '0')}`;
  f.module ??= ledger.meta.module; f.state = 'decide'; f.round = 1;
  f.category = categorize(f); f.signer ??= defaultSigner(f);
  f.history = [{ at: new Date().toISOString(), by: a.by ?? '验收', role: a.role ?? '系统', action: 'add', from: null, to: 'decide' }];
  ledger.findings.push(f);
}
const v = validateLedger(ledger, tokens, dir);
if (v.errors.length) { console.error('新问题有错误，没有写入：\n' + v.errors.map(e => '  - ' + e).join('\n')); process.exit(1); }
saveLedger(a.ledger, ledger);
console.log(`已加入 ${list.length} 个问题（待决策）。${v.warnings.length ? '\n提醒：\n' + v.warnings.map(w => '  - ' + w).join('\n') : ''}`);
