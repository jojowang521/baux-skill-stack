#!/usr/bin/env node
// 从 Figma 设计稿采集还原度基线。输出格式与 capture-baseline.mjs（HTML 设计稿）完全相同，后续对照、签收流程不变。
// 约定：要还原的图层命名为 “#ref”（如 #order-row），开发页用同名 data-testid。见 references/figma.md。
//
// 在线（需要 Figma 访问令牌，在能访问 api.figma.com 的机器上运行）：
//   node capture-baseline-figma.mjs --file <文件链接或 key> --screens "order-list=12:34" --version <版本 id>
//        --out baseline.json --shots shots/ [--token xxx | 环境变量 FIGMA_TOKEN] [--ledger iteration.json]
// 离线（已有接口返回的 JSON，例如别人导出的、或通过 Figma 连接器取得的）：
//   node capture-baseline-figma.mjs --from-json nodes.json --screens "order-list=12:34" --out baseline.json --shots shots/
//        [--images-dir 图片目录] [--variables variables.json] [--version-label v1.0]
// 没有 --version 视为未冻结的稿子，会被拒绝；确需先看效果，加 --allow-draft。
import { mkdirSync, readFileSync, writeFileSync, copyFileSync, existsSync } from 'node:fs';
import { relative, resolve, dirname, join } from 'node:path';
import { collectRefs, nodeProps, varToTokenRef } from './figma.mjs';
import { PROPS } from './fidelity.mjs';
import { baseDir, loadLedger, parseArgs, saveLedger } from './ledger.mjs';

const a = parseArgs(process.argv.slice(2));
const die = (m, code = 1) => { console.error(m); process.exit(code); };
if (!a.screens || !a.out || !a.shots || (!a.file && !a['from-json'])) die('用法见文件头注释', 2);
const offline = Boolean(a['from-json']);
const fileKey = a.file ? (/figma\.com\/(?:design|file|proto)\/([A-Za-z0-9]+)/.exec(a.file)?.[1] ?? a.file) : null;
const screens = Object.fromEntries(String(a.screens).split(',').map(s => s.split('=').map(x => x.trim())).map(([k, id]) => [k, id.replace('-', ':')]));
const version = a.version && a.version !== true ? String(a.version) : null;
if (!version && !a['allow-draft']) die('没有指定 --version。还原度只对照冻结的稿子：请在 Figma 版本历史里保存一个命名版本，把版本 id 填进来；确需先看效果，加 --allow-draft（结果会标为“草稿基线”）');
const token = a.token && a.token !== true ? a.token : process.env.FIGMA_TOKEN;
if (!offline && !token) die('需要 Figma 访问令牌：--token 或环境变量 FIGMA_TOKEN');

const api = async path => {
  const r = await fetch(`https://api.figma.com/v1/${path}`, { headers: { 'X-Figma-Token': token } });
  if (!r.ok) throw new Error(`Figma 接口 ${path.split('?')[0]} 返回 ${r.status}：${(await r.text()).slice(0, 200)}`);
  return r.json();
};

/* 1 取节点 */
let doc; const ids = Object.values(screens);
try {
  doc = offline ? JSON.parse(readFileSync(a['from-json'], 'utf8')) : await api(`files/${fileKey}/nodes?ids=${encodeURIComponent(ids.join(','))}${version ? `&version=${version}` : ''}`);
} catch (e) { die(`读取 Figma 节点失败：${e.message}\n如果这台机器访问不到 api.figma.com，请在能访问的机器上运行，或用 --from-json 离线模式`); }

/* 2 变量名（用于把绑定的变量换成 token 引用） */
let varNames = {};
const loadVars = j => { const vs = j?.meta?.variables ?? j?.variables ?? {}; for (const [id, v] of Object.entries(vs)) varNames[id] = v.name; };
if (a.variables) loadVars(JSON.parse(readFileSync(a.variables, 'utf8')));
else if (!offline) { try { loadVars(await api(`files/${fileKey}/variables/local`)); } catch (e) { console.log(`读不到变量定义（${e.message.slice(0, 80)}…）。变量接口通常需要企业版；绑定关系仍会记录，期望值改为按数值匹配 token`); } }

/* 3 版本信息 */
let versionLabel = a['version-label'] && a['version-label'] !== true ? a['version-label'] : null;
if (!versionLabel && version && !offline) { try { const vs = await api(`files/${fileKey}/versions`); const hit = vs.versions?.find(v => String(v.id) === version); versionLabel = hit?.label || hit?.created_at?.slice(0, 10) || null; } catch { /* 拿不到就用 id */ } }

/* 4 采集 */
const shotDir = resolve(a.shots); mkdirSync(shotDir, { recursive: true }); const outDir = dirname(resolve(a.out));
const baseline = { source: `Figma：${doc.name ?? fileKey ?? '离线文件'}`, kind: 'figma', fileKey, version: versionLabel ?? version ?? 'draft', versionId: version, status: version ? 'frozen' : 'draft', capturedAt: new Date().toISOString(), props: Object.keys(PROPS), screens: {} };
const wanted = []; let unbound = 0; const nc = new Set(); let viewport = null;
for (const [screen, id] of Object.entries(screens)) {
  const frame = doc.nodes?.[id]?.document;
  if (!frame) die(`找不到画框 ${id}（${screen}）。在 Figma 里选中画框，复制链接，node-id 就是它`);
  const bb = frame.absoluteBoundingBox; if (bb && !viewport) viewport = { width: Math.round(bb.width), height: Math.round(bb.height) };
  const refs = collectRefs(frame);
  if (!refs.size) console.log(`画框 ${screen} 里没有以 # 开头命名的图层，没有可对照的元素`);
  const entry = (baseline.screens[screen] = { frameId: id, states: { default: { refs: {} } } }).states.default;
  for (const [ref, { node, count }] of refs) {
    const r = nodeProps(node);
    const tokens = {}; for (const [prop, vid] of Object.entries(r.vars)) { const t = varToTokenRef(varNames[vid]); if (t) tokens[prop] = t; }
    for (const p of ['color', 'backgroundColor', 'borderTopColor', 'fontSize', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'gap', 'borderTopLeftRadius']) if (r.props[p] != null && !r.vars[p] && !/^0(px)?$/.test(r.props[p])) unbound++;
    r.notComparable.forEach(x => nc.add(`${ref}：${x}`));
    const file = `figma-${screen}-${ref}.png`;
    entry.refs[ref] = { count, text: r.text, props: r.props, nodeId: node.id, ...(Object.keys(tokens).length ? { tokens } : {}), ...(Object.keys(r.vars).length ? { vars: r.vars } : {}), ...(r.notComparable.length ? { notComparable: r.notComparable } : {}), shot: relative(outDir, join(shotDir, file)) };
    wanted.push({ id: node.id, file });
  }
}
baseline.viewport = viewport ?? { width: 1440, height: 900 };

/* 5 元素截图 */
let shots = 0;
if (offline) {
  const dir = a['images-dir'] && a['images-dir'] !== true ? resolve(a['images-dir']) : null;
  for (const w of wanted) { const src = dir && join(dir, `${w.id.replace(/:/g, '-')}.png`); if (src && existsSync(src)) { copyFileSync(src, join(shotDir, w.file)); shots++; } }
} else if (wanted.length) {
  try {
    const res = await api(`images/${fileKey}?ids=${encodeURIComponent(wanted.map(w => w.id).join(','))}&format=png&scale=1${version ? `&version=${version}` : ''}`);
    for (const w of wanted) { const url = res.images?.[w.id]; if (!url) continue; const r = await fetch(url); if (r.ok) { writeFileSync(join(shotDir, w.file), Buffer.from(await r.arrayBuffer())); shots++; } }
  } catch (e) { console.log(`元素截图导出失败（${e.message.slice(0, 80)}），对照图里将只有开发页一侧`); }
}
for (const s of Object.values(baseline.screens)) for (const r of Object.values(s.states.default.refs)) if (!existsSync(resolve(outDir, r.shot))) delete r.shot;

writeFileSync(a.out, JSON.stringify(baseline, null, 2) + '\n');
const total = Object.values(baseline.screens).reduce((n, s) => n + Object.keys(s.states.default.refs).length, 0);
console.log(`已采集 ${baseline.source} ${baseline.version}（${baseline.status === 'frozen' ? '已冻结' : '草稿'}）：${Object.keys(screens).length} 个画框，${total} 个 # 图层，${shots} 张元素截图 → ${a.out}`);
const bound = Object.values(baseline.screens).reduce((n, s) => n + Object.values(s.states.default.refs).reduce((m, r) => m + Object.keys(r.tokens ?? {}).length, 0), 0);
console.log(`  绑定变量并对应到 token 的属性 ${bound} 处；手写数值没有绑变量的 ${unbound} 处${unbound ? '（不算问题，但期望值只能按数值匹配 token）' : ''}`);
if (nc.size) console.log(`  不可比的属性：${[...nc].join('；')}`);
if (a.ledger) {
  const ledger = loadLedger(a.ledger); const dir = baseDir(a.ledger);
  const p = fileKey ? `figma:${fileKey}` : `figma:${a['from-json']}`;
  const entry = ledger.meta.design.find(d => d.path === p) ?? (ledger.meta.design.push({ path: p }), ledger.meta.design.at(-1));
  Object.assign(entry, { kind: 'figma', version: baseline.version, status: baseline.status, baseline: relative(dir, resolve(a.out)), screens: Object.keys(screens) });
  saveLedger(a.ledger, ledger); console.log('已登记到台账');
}
