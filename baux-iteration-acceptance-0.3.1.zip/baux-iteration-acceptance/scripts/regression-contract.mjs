// Shared by dispatch and ledger import: one ID and one contract for every check.
import { createHash } from 'node:crypto';

const canonical = value => Array.isArray(value) ? value.map(canonical)
  : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(k => [k, canonical(value[k])])) : value;

export function checkRules(finding) {
  const seen = new Map();
  return (finding.checks ?? []).map(check => {
    const base = `${finding.id}#${check.acceptance}`;
    const n = (seen.get(base) ?? 0) + 1; seen.set(base, n);
    return { id: n === 1 ? base : `${base}-${n}`, acceptance: check.acceptance, check };
  });
}

export function checkFingerprint(finding) {
  const spec = { id: finding.id, page: finding.page, owner: finding.owner,
    expected: finding.expected ?? null, acceptance: finding.acceptance ?? [], checks: finding.checks ?? [],
    tokenRef: finding.tokenRef ?? null, expectedValue: finding.expectedValue ?? null };
  return createHash('sha256').update(JSON.stringify(canonical(spec))).digest('hex');
}

export function regressionContract(finding) {
  return { round: finding.round ?? 1, fingerprint: checkFingerprint(finding) };
}
