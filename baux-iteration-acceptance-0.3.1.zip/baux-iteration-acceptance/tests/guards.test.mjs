// 守卫、准出、还原度归属的测试。运行：node --test tests/
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { GuardError, act, exitCheck, validateLedger, checkRules, regressionContract } from '../scripts/ledger.mjs';
import { classify, matchToken } from '../scripts/fidelity.mjs';

const tokens = JSON.parse(readFileSync(resolve(import.meta.dirname, '../assets/tokens/builtin-b2b-default.json'), 'utf8'));
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFBQIAX8jx0gAAAABJRU5ErkJggg==', 'base64');

function setup() {
  const dir = mkdtempSync(join(tmpdir(), 'ia-'));
  writeFileSync(join(dir, 't.json'), JSON.stringify(tokens));
  mkdirSync(join(dir, 'shots')); writeFileSync(join(dir, 'shots/a.png'), PNG); writeFileSync(join(dir, 'shots/b.png'), PNG);
  const base = { module: '订单收货', page: '订单列表', repro: ['打开页面'], severityBasis: '示例', evidence: { state: 'observed' }, round: 1 };
  const ledger = { meta: { product: 'P', module: '订单收货', iteration: 'I1', tokens: { path: 't.json' }, design: [], fidelity: { total: 1, compared: 1, missing: [] } }, groups: [], findings: [
    { ...base, id: 'F-001', title: '规则项', dimension: 'interaction', type: '交互问题', severity: '高', owner: 'product', state: 'decide', category: 'rule', signer: '产品' },
    { ...base, id: 'F-002', title: '交互项', dimension: 'interaction', type: '交互问题', severity: '中', owner: 'dev', state: 'decide', category: 'interaction', signer: '设计', expected: '期望', acceptance: ['标准一'],
      checks: [{ acceptance: 0, kind: 'flow', slots: { $a: '按钮' }, steps: [{ click: '$a' }] }] },
    { ...base, id: 'F-003', title: '缺陷', dimension: 'function', type: 'BUG问题', severity: '低', owner: 'dev', state: 'decide', category: 'rule', signer: '测试', expected: '期望', acceptance: ['标准一'] }
  ] };
  return { dir, ledger };
}
const P = (role, extra = {}) => ({ by: '某人', role, ...extra });
const report = (f, status) => ({ meta: { contractVersion: 1, targetVersion: 'test-build-1', generatedAt: new Date().toISOString() }, results: checkRules(f).map(r => ({ findingId: f.id, ruleId: r.id, acceptance: r.acceptance, ...regressionContract(f), status, actual: '' })) });

test('没有现状截图不能下发', () => {
  const { dir, ledger } = setup();
  assert.throws(() => act(ledger, dir, 'decide', P('产品', { ids: ['F-001'], owner: 'dev', expected: 'x', acceptance: ['y'] })), /现状截图/);
});
test('测试和开发不能拍板方案', () => {
  const { dir, ledger } = setup();
  for (const role of ['测试', '开发']) assert.throws(() => act(ledger, dir, 'decide', P(role, { ids: ['F-003'] })), GuardError);
});
test('交给开发的项必须有期望和验收标准', () => {
  const { dir, ledger } = setup();
  act(ledger, dir, 'attach', P('产品', { id: 'F-001', before: 'shots/a.png' }));
  assert.throws(() => act(ledger, dir, 'decide', P('产品', { ids: ['F-001'], owner: 'dev' })), /验收标准/);
  act(ledger, dir, 'decide', P('产品', { ids: ['F-001'], owner: 'dev', expected: '先确认', acceptance: ['弹出确认框'] }));
  assert.equal(ledger.findings[0].state, 'fix');
});
test('高严重度只能由产品移出；中低可由产品或签收人移出，且要写原因', () => {
  const { dir, ledger } = setup();
  assert.throws(() => act(ledger, dir, 'defer', P('设计', { ids: ['F-001'], note: '下期' })), /产品/);
  assert.throws(() => act(ledger, dir, 'defer', P('设计', { ids: ['F-003'], note: '下期' })), /签收人/);
  assert.throws(() => act(ledger, dir, 'defer', P('测试', { ids: ['F-003'] })), /原因/);
  act(ledger, dir, 'defer', P('测试', { ids: ['F-003'], note: '下期' }));
  assert.equal(ledger.findings[2].state, 'out');
  assert.equal(validateLedger(ledger, tokens, dir).errors.length, 0);
});
function toFix(dir, ledger, id) { act(ledger, dir, 'attach', P('设计', { id, before: 'shots/a.png' })); act(ledger, dir, 'decide', P('设计', { ids: [id] })); }
test('有自动检查的项，自测没全过不能提测；回执要截图、要说明、要由修改方提交', () => {
  const { dir, ledger } = setup(); toFix(dir, ledger, 'F-002');
  const entry = { id: 'F-002', note: '改了', after: 'shots/b.png', cause: '未按设计稿实现' };
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [entry] })), /自测/);
  act(ledger, dir, 'results', P('开发', { report: report(ledger.findings.find(f => f.id === 'F-002'), 'failed') }));
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [entry] })), /自测/);
  act(ledger, dir, 'results', P('开发', { report: report(ledger.findings.find(f => f.id === 'F-002'), 'passed') }));
  assert.throws(() => act(ledger, dir, 'receipt', P('设计', { entries: [entry] })), /开发/);
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [{ ...entry, after: 'shots/none.png' }] })), /截图/);
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [{ ...entry, note: '' }] })), /说明/);
  act(ledger, dir, 'receipt', P('开发', { entries: [entry] }));
  assert.equal(ledger.findings[1].state, 'retest');
});
test('只有指定签收人能签；不通过要写原因并退回、轮次加一；自动项失败会退回已关闭的项', () => {
  const { dir, ledger } = setup(); toFix(dir, ledger, 'F-002');
  act(ledger, dir, 'results', P('开发', { report: report(ledger.findings.find(f => f.id === 'F-002'), 'passed') }));
  act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '改了', after: 'shots/b.png', cause: '未按设计稿实现' }] }));
  assert.throws(() => act(ledger, dir, 'sign', P('测试', { ids: ['F-002'], result: 'pass' })), /代签/);
  assert.throws(() => act(ledger, dir, 'sign', P('设计', { ids: ['F-002'], result: 'fail' })), /写明/);
  act(ledger, dir, 'sign', P('设计', { ids: ['F-002'], result: 'fail', note: '不对' }));
  const f = ledger.findings[1]; assert.equal(f.state, 'fix'); assert.equal(f.round, 2);
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '再改', after: 'shots/b.png', cause: '未按设计稿实现' }] })), /自测/);
  act(ledger, dir, 'results', P('开发', { report: report(f, 'passed') }));
  act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '再改', after: 'shots/b.png', cause: '未按设计稿实现' }] }));
  act(ledger, dir, 'sign', P('设计', { autoPassed: true, result: 'pass' }));
  assert.equal(f.state, 'closed');
  act(ledger, dir, 'results', P('测试', { report: report(ledger.findings.find(f => f.id === 'F-002'), 'failed') }));
  assert.equal(f.state, 'fix'); assert.equal(f.round, 3); assert.equal(f.signoff, undefined);
});
test('准出：全部关闭或移出、截图齐、设计稿元素都对照到才通过', () => {
  const { dir, ledger } = setup();
  assert.equal(exitCheck(ledger, dir).pass, false);
  for (const f of ledger.findings) { f.state = 'out'; f.outReason = '下期'; }
  assert.equal(exitCheck(ledger, dir).pass, true);
  ledger.meta.fidelity.missing = ['status-running'];
  assert.equal(exitCheck(ledger, dir).pass, false);
  delete ledger.meta.fidelity; assert.equal(exitCheck(ledger, dir).pass, false);
});
test('还原度归属：设计稿在 token 上算开发，不在 token 上算设计；派生值不判', () => {
  assert.deepEqual(classify(tokens, 'height', '48px', '48px'), null);
  assert.equal(classify(tokens, 'height', '48px', '40px').kind, 'dev');
  assert.equal(classify(tokens, 'height', '48px', '40px').token.ref, 'size.table-row-height');
  assert.equal(classify(tokens, 'color', 'rgb(91, 104, 129)', 'rgb(208, 58, 50)', 'status-cancelled').token.ref, 'color.status-neutral');
  assert.equal(classify(tokens, 'fontSize', '13px', '12px').kind, 'design');
  assert.equal(classify(tokens, 'fontSize', '13px', '13px').silent, true);
  assert.equal(classify(tokens, 'height', '184px', '160px'), null);
  assert.equal(classify(tokens, 'backgroundColor', null, 'rgb(255, 255, 255)'), null);
  assert.equal(matchToken(tokens, 'spacing', '0px').zero, true);
});

/* ── 0.3.0：原因、异议、链接、录屏 ── */
test('回执必须选问题原因，且在分类里；状态里能按原因统计', async () => {
  const { causeStats } = await import('../scripts/ledger.mjs');
  const { dir, ledger } = setup(); toFix(dir, ledger, 'F-002');
  act(ledger, dir, 'results', P('开发', { report: report(ledger.findings.find(f => f.id === 'F-002'), 'passed') }));
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '改了', after: 'shots/b.png' }] })), /问题原因/);
  assert.throws(() => act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '改了', after: 'shots/b.png', cause: '随便写的' }] })), /不在分类/);
  act(ledger, dir, 'receipt', P('开发', { entries: [{ id: 'F-002', note: '改了', after: 'shots/b.png', cause: '组件属性配置错误' }] }));
  const hit = causeStats(ledger).flatMap(g => g.items).find(x => x.item === '组件属性配置错误');
  assert.equal(hit.count, 1); assert.deepEqual(hit.ids, ['F-002']);
});
test('异议：只有修改方能提、要写理由；退回待决策；拍板人必须回复才能重新下发', () => {
  const { dir, ledger } = setup(); toFix(dir, ledger, 'F-002'); const f = ledger.findings[1];
  assert.throws(() => act(ledger, dir, 'dispute', P('开发', { ids: ['F-002'] })), /理由/);
  assert.throws(() => act(ledger, dir, 'dispute', P('测试', { ids: ['F-002'], note: '不是问题' })), /开发/);
  act(ledger, dir, 'dispute', P('开发', { ids: ['F-002'], note: '页签上限由框架统一控制' }));
  assert.equal(f.state, 'decide');
  assert.throws(() => act(ledger, dir, 'decide', P('设计', { ids: ['F-002'] })), /回复/);
  act(ledger, dir, 'decide', P('设计', { ids: ['F-002'], note: '框架有 maxTabs 配置，本模块开启即可' }));
  assert.equal(f.state, 'fix'); assert.equal(f.dispute.reply.role, '设计');
  assert.equal(JSON.parse(JSON.stringify(f)).disputes[0].reply.role, '设计'); // 保存后异议记录里也有回复
  assert.throws(() => act(ledger, dir, 'dispute', P('开发', { ids: ['F-001'], note: 'x' })), /待修复/);
});
test('外部单号和链接只接受 http(s)；台账不能记账号密码', () => {
  const { dir, ledger } = setup();
  act(ledger, dir, 'link', P('产品', { ids: ['F-001'], ticket: 'TAPD-1001', system: 'TAPD', url: 'https://tapd.example.com/story/1001' }));
  assert.equal(ledger.findings[0].ticket.id, 'TAPD-1001');
  assert.throws(() => act(ledger, dir, 'link', P('产品', { ids: ['F-001'], url: 'javascript:alert(1)' })), /http/);
  act(ledger, dir, 'link', P('设计', { ids: ['F-001'], url: 'https://design.example.com/order-list', label: '设计稿' }));
  assert.equal(validateLedger(ledger, tokens, dir).errors.length, 0);
  ledger.meta.env = 'https://test.example.com 账号 admin 密码 123';
  assert.ok(validateLedger(ledger, tokens, dir).errors.some(e => e.includes('密码') || e.includes('只记地址')));
});
test('录屏可以作为现状和修复后证据，其他文件类型不行', () => {
  const { dir, ledger } = setup();
  writeFileSync(join(dir, 'shots/rec.webm'), Buffer.from('fake')); writeFileSync(join(dir, 'shots/x.txt'), 'x');
  act(ledger, dir, 'attach', P('设计', { id: 'F-002', before: 'shots/rec.webm' }));
  assert.throws(() => act(ledger, dir, 'attach', P('设计', { id: 'F-002', before: 'shots/x.txt' })), /录屏/);
  act(ledger, dir, 'decide', P('设计', { ids: ['F-002'] }));
  assert.equal(exitCheck(ledger, dir).rules.find(r => r.key === 'before').ok, true);
});
