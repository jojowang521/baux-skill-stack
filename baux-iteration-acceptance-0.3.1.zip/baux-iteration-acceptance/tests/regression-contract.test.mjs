import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {act,autoPassed,checkRules,regressionContract,exitCheck,validateLedger} from '../scripts/ledger.mjs';

const kit=resolve(import.meta.dirname,'..');
const tokens=JSON.parse(readFileSync(join(kit,'assets/tokens/builtin-b2b-default.json'),'utf8'));
function setup(){
  const dir=mkdtempSync(join(tmpdir(),'baux-031-'));
  mkdirSync(join(dir,'shots'));writeFileSync(join(dir,'tokens.json'),JSON.stringify(tokens));
  const example=JSON.parse(readFileSync(join(kit,'examples/order-receiving/work/iteration.json'),'utf8'));
  const f=structuredClone(example.findings.find(f=>f.id==='F-018'));
  Object.assign(f,{state:'fix',round:1,history:[],shots:{before:'shots/before.png',after:'shots/after.png'}});
  for(const k of ['receipt','signoff','auto','autoHistory'])delete f[k];
  for(const name of ['before','after'])writeFileSync(join(dir,'shots/'+name+'.png'),Buffer.from('simulated-evidence'));
  const ledger={meta:{product:'审核模拟',module:f.module,iteration:'I1',tokens:{path:'tokens.json'},design:[],fidelity:{total:1,compared:1,missing:[]}},groups:[],findings:[f]};
  return {dir,ledger,f};
}
const opts=(role,extra)=>({by:'模拟操作者',role,...extra});
const report=(f,status='passed')=>({meta:{contractVersion:1,targetVersion:'test-build-1',generatedAt:new Date().toISOString()},results:checkRules(f).map(r=>({findingId:f.id,ruleId:r.id,acceptance:r.acceptance,...regressionContract(f),status,actual:'模拟结果'}))});
const results=(x,r)=>act(x.ledger,x.dir,'results',opts('开发',{report:r}));
const receipt=x=>act(x.ledger,x.dir,'receipt',opts('开发',{entries:[{id:x.f.id,note:'模拟修复',cause:'业务逻辑缺陷',after:'shots/after.png'}]}));
const sign=(x,result='pass')=>act(x.ledger,x.dir,'sign',opts('测试',{ids:[x.f.id],result,note:'模拟复验'}));

test('完整当前轮次报告可以提测、签收和准出',()=>{
  const x=setup();results(x,report(x.f));receipt(x);sign(x);
  assert.equal(validateLedger(x.ledger,tokens,x.dir).errors.length,0);
  assert.equal(autoPassed(x.f),true);assert.equal(exitCheck(x.ledger,x.dir).pass,true);
});
test('三个检查只传一个通过结果，漏掉的两个计为未执行，不能提测',()=>{
  const x=setup(),r=report(x.f);assert.equal(r.results.length,3);r.results=r.results.slice(0,1);results(x,r);
  assert.equal(x.f.auto.counts.notRun,2);assert.equal(autoPassed(x.f),false);
  assert.throws(()=>receipt(x),/自测/);assert.equal(exitCheck(x.ledger,x.dir).pass,false);
});
test('重复检查不能凑满覆盖数量，导入被拒绝且不改变台账',()=>{
  const x=setup(),r=report(x.f);r.results=[r.results[0],r.results[0],r.results[0]];const before=JSON.stringify(x.ledger);
  assert.throws(()=>results(x,r),/重复/);assert.equal(JSON.stringify(x.ledger),before);
});
test('未知规则、不合法状态和空报告均被拒绝',()=>{
  for(const mutate of [r=>r.results[0].ruleId='F-018#99',r=>r.results[0].status='success',r=>r.results=[]]){
    const x=setup(),r=report(x.f);mutate(r);assert.throws(()=>results(x,r));assert.equal(x.f.auto,undefined);
  }
});
test('缺少被测版本或旧格式报告不能作为验收依据',()=>{
  for(const mutate of [r=>delete r.meta.contractVersion,r=>delete r.meta.targetVersion]){
    const x=setup(),r=report(x.f);mutate(r);assert.throws(()=>results(x,r));
  }
});
test('期望或检查条件改变后，旧规则报告不能导入',()=>{
  const x=setup(),r=report(x.f);x.f.acceptance[0]+=' 新要求';assert.throws(()=>results(x,r),/规则版本/);
});
test('同一个验收标准的多个检查具有不同规则编号',()=>{
  const x=setup();x.f.checks.forEach(c=>c.acceptance=0);assert.deepEqual(checkRules(x.f).map(r=>r.id),['F-018#0','F-018#0-2','F-018#0-3']);
  results(x,report(x.f));assert.equal(autoPassed(x.f),true);
});
test('人工退回后旧结果失效，新轮次必须更新分发包并重新回归',()=>{
  const x=setup(),old=report(x.f);results(x,old);receipt(x);sign(x,'fail');
  assert.equal(x.f.round,2);assert.equal(x.f.auto,undefined);assert.equal(x.f.autoHistory.length,1);
  assert.throws(()=>receipt(x),/自测/);assert.throws(()=>results(x,old),/轮次/);
  results(x,report(x.f));receipt(x);sign(x);assert.equal(exitCheck(x.ledger,x.dir).pass,true);
});
test('已关闭项遇到失败、执行错误或漏测报告，必须重新打开',()=>{
  for(const status of ['failed','error','notRun']){
    const x=setup();results(x,report(x.f));receipt(x);sign(x);results(x,report(x.f,status));
    assert.equal(x.f.state,'fix');assert.equal(x.f.round,2);assert.equal(x.f.signoff,undefined);assert.equal(x.f.receipt,undefined);
    assert.equal(exitCheck(x.ledger,x.dir).pass,false);
  }
});
test('不能用较旧报告覆盖较新结果',()=>{
  const x=setup(),r=report(x.f);r.meta.generatedAt='2026-11-12T03:00:00Z';results(x,r);
  const old=report(x.f);old.meta.generatedAt='2026-11-12T02:00:00Z';assert.throws(()=>results(x,old),/较旧/);
});
test('不能仅通过篡改 passed 计数绕过逐项检查',()=>{
  const x=setup();results(x,report(x.f,'failed'));x.f.auto.counts={passed:3,failed:0,error:0,notRun:0};assert.equal(autoPassed(x.f),false);
});
test('缺少当前令牌或签收记录错误时，准出命令返回非零',()=>{
  const x=setup();results(x,report(x.f));receipt(x);sign(x);x.f.signoff.role='开发';
  assert.equal(exitCheck(x.ledger,x.dir).pass,false);
  const file=join(x.dir,'iteration.json');writeFileSync(file,JSON.stringify(x.ledger));
  const r=spawnSync('node',[join(kit,'scripts/status.mjs'),'--ledger',file,'--json'],{encoding:'utf8'});
  assert.equal(r.status,1);const data=JSON.parse(r.stdout);assert.equal(data.exit.pass,false);assert.ok(data.errors.some(e=>e.includes('签收人')));
  x.ledger.meta.tokens.path='missing.json';assert.equal(exitCheck(x.ledger,x.dir).pass,false);
});
test('旧台账已关闭的自动项可重新分发，规则包含当前轮次和指纹',()=>{
  const x=setup();results(x,report(x.f));receipt(x);sign(x);delete x.f.auto.contractVersion;
  assert.equal(autoPassed(x.f),false);
  const file=join(x.dir,'iteration.json');writeFileSync(file,JSON.stringify(x.ledger));
  const out=join(x.dir,'dispatch');
  const r=spawnSync('node',[join(kit,'scripts/dispatch.mjs'),'--ledger',file,'--out',out,'--include-closed'],{encoding:'utf8'});
  assert.equal(r.status,0,r.stderr);
  const rules=JSON.parse(readFileSync(join(out,'regression/rules.json'),'utf8')).rules;
  assert.equal(rules.length,3);assert.deepEqual(rules.map(r=>r.id),checkRules(x.f).map(r=>r.id));
  assert.ok(rules.every(r=>r.round===1&&r.fingerprint===regressionContract(x.f).fingerprint));
});
