// Figma 节点取值、变量换 token、对照归属的测试。运行：node --test tests/figma.test.mjs
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { collectRefs, nodeProps, paintToCss, refOf, varToTokenRef } from '../scripts/figma.mjs';
import { classify } from '../scripts/fidelity.mjs';

const tokens = JSON.parse(readFileSync(resolve(import.meta.dirname, '../assets/tokens/builtin-b2b-default.json'), 'utf8'));
const solid = (r, g, b, extra = {}) => ({ type: 'SOLID', color: { r: r / 255, g: g / 255, b: b / 255, a: 1 }, ...extra });

test('颜色换算：不透明为 rgb，半透明为 rgba，隐藏的填充不算', () => {
  assert.equal(paintToCss(solid(91, 104, 129)), 'rgb(91, 104, 129)');
  assert.match(paintToCss(solid(0, 0, 0, { opacity: 0.5 })), /^rgba\(0, 0, 0, 0\.5\)$/);
  assert.equal(paintToCss(solid(0, 0, 0, { visible: false })), null);
  assert.equal(paintToCss({ type: 'GRADIENT_LINEAR' }), null);
});
test('图层命名约定：# 开头的 kebab-case', () => {
  assert.equal(refOf({ name: '#order-row' }), 'order-row');
  assert.equal(refOf({ name: '#status-cancelled 已取消标签' }), 'status-cancelled');
  assert.equal(refOf({ name: 'order-row' }), null);
  assert.equal(refOf({ name: '#OrderRow' }), null);
});
test('文字图层取字体和文字颜色；行高为自动时不可比', () => {
  const r = nodeProps({ type: 'TEXT', characters: '已取消', fills: [solid(91, 104, 129)], boundVariables: { fills: [{ id: 'V1' }] }, style: { fontSize: 13, fontWeight: 400, lineHeightUnit: 'INTRINSIC_%' }, absoluteBoundingBox: { height: 22 } });
  assert.equal(r.props.color, 'rgb(91, 104, 129)'); assert.equal(r.props.fontSize, '13px'); assert.equal(r.props.lineHeight, null);
  assert.equal(r.vars.color, 'V1'); assert.equal(r.text, '已取消'); assert.ok(r.notComparable.length);
});
test('容器：开了自动布局才有内边距和间距；没开的标为不可比', () => {
  const auto = nodeProps({ type: 'FRAME', layoutMode: 'HORIZONTAL', paddingLeft: 16, paddingRight: 16, itemSpacing: 8, fills: [], absoluteBoundingBox: { height: 48 } });
  assert.equal(auto.props.paddingLeft, '16px'); assert.equal(auto.props.gap, '8px'); assert.equal(auto.props.color, null);
  const free = nodeProps({ type: 'FRAME', layoutMode: 'NONE', children: [{}], fills: [], absoluteBoundingBox: { height: 48 } });
  assert.equal(free.props.paddingLeft, null); assert.ok(free.notComparable.some(x => x.includes('自动布局')));
});
test('同名图层算同一元素的多个实例，隐藏的不算', () => {
  const frame = { name: 'f', children: [{ name: '#row', id: 'a' }, { name: '#row', id: 'b' }, { name: '#row', id: 'c', visible: false }, { name: 'x', children: [{ name: '#tag', id: 'd' }] }] };
  const refs = collectRefs(frame);
  assert.equal(refs.get('row').count, 2); assert.equal(refs.get('row').node.id, 'a'); assert.ok(refs.has('tag'));
});
test('变量名换成 token 引用', () => {
  assert.equal(varToTokenRef('color/status-neutral'), 'color.status-neutral');
  assert.equal(varToTokenRef('spacing/space/4'), 'spacing.space-4');
  assert.equal(varToTokenRef(undefined), null);
});
test('绑定了变量时，期望 token 取绑定的那个，不按数值猜', () => {
  // #5B6881 同时等于 text-secondary 和 status-neutral；没有任何名字线索时，按数值会选到第一个
  assert.equal(classify(tokens, 'color', 'rgb(91, 104, 129)', 'rgb(208, 58, 50)').token.ref, 'color.text-secondary');
  const c = classify(tokens, 'color', 'rgb(91, 104, 129)', 'rgb(208, 58, 50)', '', 'color.status-neutral');
  assert.equal(c.token.ref, 'color.status-neutral'); assert.equal(c.token.bound, true);
  // 绑定的变量在 token 集里值不一样（比如模式不同），退回按数值匹配
  assert.equal(classify(tokens, 'color', 'rgb(91, 104, 129)', 'rgb(208, 58, 50)', '', 'color.status-error').token.bound, undefined);
});
test('开发页没有 gap（非 flex 布局）时不判', () => {
  assert.equal(classify(tokens, 'gap', '0px', null), null);
  assert.equal(classify(tokens, 'gap', '16px', null), null);
});
