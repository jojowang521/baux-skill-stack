# baux-iteration-acceptance · baux 迭代验收技能 0.3.1

「B端AI设计视界」出品。关注同名公众号，获取更多 B 端产品设计与 AI 实践资源。

一次迭代 = 一个功能模块。产品和设计验收规则、交互、视觉、还原度，开发修复、测试复验通过文件交接，按角色签收，判断能否准出。

```
SKILL.md                    入口（中文）：底线、角色、流程、命令
references/
  roles-and-flow.md         状态、守卫、签收人、准出条件
  ledger-schema.md          台账 iteration.json 字段
  fidelity.md               还原度：设计稿约定、采集、差异归属
  figma.md                  Figma 设计稿：图层命名、版本、变量绑定、不可比属性
  handoff.md                分发包、回执、测试复验
  regression-checks.md      自动检查（checks）写法
scripts/
  init-iteration.mjs        建单（可带入走查记录）
  add-findings.mjs          新增问题（进待决策）
  capture-baseline.mjs      从冻结的 HTML 设计稿采集基线
  capture-baseline-figma.mjs  从 Figma 命名版本采集基线（在线或离线）
  compare-fidelity.mjs      按 data-ref ↔ data-testid 对照开发页，生成还原度问题
  act.mjs                   推进状态：attach / decide / defer / receipt / results / sign / dispute / link
  dispatch.mjs              生成开发分发包（清单、证据、回归包、回执模板、建单表格）
  status.mjs                进度和准出结论
  build-page.mjs            生成迭代验收单页面
  ledger.mjs  fidelity.mjs  figma.mjs  lib.mjs  import-tokens.mjs   共享逻辑
assets/
  page-template.html        页面模板
  regression-runner/        回归包运行器（Playwright）
  tokens/builtin-b2b-default.json   内置参考 token（不是任何真实产品的规范）
  causes.json               默认的问题原因分类
tests/                      守卫、准出、还原度归属、Figma 取值测试
examples/order-receiving/   订单收货迭代完整闭环示例
```

快速验证：`node --test tests/guards.test.mjs tests/figma.test.mjs`；`cd examples/order-receiving && node run-demo.mjs`。
需要 Node.js 20.11 或更高。在 Skill 根目录运行：

```sh
npm install
npx playwright install chromium ffmpeg
npm test
npm run demo
npm run demo:figma
```

单元测试不启动浏览器；浏览器采集、回归与录屏示例依赖 Playwright、Chromium 和 FFmpeg。受管环境可通过 `PLAYWRIGHT_CHROMIUM_EXECUTABLE` 指定已有 Chromium。

0.3.1 修复不完整回归报告误放行、跨轮次沿用旧结果、台账校验错误仍准出和绝对网址解析问题。旧版回归报告须重新生成；旧台账的已关闭自动项可用 `dispatch.mjs --include-closed` 纳入回归。真实环境运行时填写 `--target-version <提交号或部署版本>`（或配置 `target.version`）；示例使用 `--variant` 标记被测变体。

## 使用许可

本包尚未指定独立使用许可；使用与再分发范围请联系作者确认。作者署名与测试通过记录不构成许可声明。
