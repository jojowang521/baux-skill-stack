# 台账 iteration.json

```json
{
  "meta": {
    "product": "采购管理平台", "module": "订单收货", "iteration": "2026-11 第1迭代",
    "pages": ["订单列表", "订单详情", "收货单"],
    "tokens": { "path": "../tokens.json", "name": "…", "version": "…" },
    "design": [{ "path": "design/order-list.html", "version": "1.0", "status": "frozen", "baseline": "baseline/v1.0.json", "screens": ["order-list"] }],
    "people": { "产品": "周敏", "设计": "王娇", "测试": "刘洋", "开发": "陈哲" },
    "env": "https://test.example.com/procurement",
    "pageLinks": { "订单列表": "https://design.example.com/procurement/order-list" },
    "causes": { "groups": [{ "group": "开发实现", "items": ["…"] }] },
    "fidelity": { "baseline": "order-list.html v1.1", "total": 5, "compared": 5, "missing": [] }
  },
  "groups": [{ "id": "G3", "title": "…", "fix": "…" }],
  "findings": [ … ]
}
```

路径都相对台账所在目录。`env` 只记测试环境地址，不记账号密码。`causes` 省略时用默认分类。同类问题（groups）可以带 `specs: [{ "label": "页签规范", "url": "…" }]`。

## 问题字段

**沿用体验验收的字段**（同一套校验）：`id`（F-001）、`title`、`module`、`page`、`dimension`（color / spacing / size / typography / motion / interaction / function）、`type`（交互问题 / UI问题 / 开发还原度 / BUG问题）、`severity`（高 / 中 / 低）、`severityBasis`、`owner`（dev / design / product，即修改方）、`repro`、`expected`、`actual`、`acceptance`、`suggestion`、`evidence`（state：measured / observed / missing）、`tokenRef` + `expectedValue` + `actualValue` 或 `noTokenReason`、`group`、`checks`。

**迭代验收新增**：

| 字段 | 说明 | 谁写 |
|---|---|---|
| `state` | decide / fix / retest / closed / out | 脚本 |
| `category` | rule / interaction / visual / fidelity | 新增时按 type 推断，可手填 |
| `signer` | 产品 / 设计 / 测试 | 新增时按类别推断，拍板时可改 |
| `round` | 第几轮修复 | 脚本 |
| `shots.before` / `shots.after` | 现状 / 修复后证据：截图或录屏（台账目录下的路径） | attach、receipt |
| `receipt` | `{ by, at, note, cause, commit, round }`，cause 是问题原因 | receipt |
| `dispute` / `disputes` | 当前异议 `{ by, role, note, at, round, reply }` / 全部异议记录 | dispute、decide、defer |
| `ticket` | 外部单号 `{ id, system, url }` | link |
| `links` | 其他链接 `[{ label, url }]` | link |
| `auto` | 最近一次回归结果 `{ runAt, source, counts, items }` | results |
| `signoff` | `{ by, role, at, note }` | sign |
| `lastReject` | 上一次复验不通过的说明 | sign |
| `outReason` | 移出本迭代的原因 | defer |
| `fidelity` | 还原度来源 `{ screen, refs, prop, designValue, devValue, baseline }` | compare-fidelity |
| `fidelityKey` | 去重用，重复对照不会重复建问题 | compare-fidelity |
| `history` | 每次操作的记录 | 脚本 |

新问题只需要写体验验收字段，`state`、`category`、`signer` 由 `add-findings.mjs` 补。

## 新问题示例

```json
[{
  "title": "取消订单没有二次确认", "page": "订单详情", "dimension": "interaction", "type": "交互问题",
  "severity": "高", "severityBasis": "破坏性操作", "owner": "product",
  "repro": ["打开一张已部分收货的订单", "点击“取消订单”"],
  "expected": "需要产品确认取消规则", "actual": "订单被直接取消",
  "evidence": { "state": "observed", "ref": "截图" }
}]
```
