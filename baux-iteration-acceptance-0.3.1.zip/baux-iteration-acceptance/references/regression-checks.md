# 自动检查（回归规则）

验收标准里能用机器判断的部分，可以写成 `checks`，生成给研发的 Playwright 回归包。研发修完自己跑，通过后再交给设计和产品回验。

## 哪些适合自动化

适合：计算样式（颜色、尺寸、间距、字号）、过渡时长、聚焦样式是否可见、明确的操作流程（点了之后按钮禁用、请求只发一次、数量不超过上限、弹窗出现、hash 变化）。
不适合：“看起来协调”“层级清晰”“文案是否合适”。这类留给人回验，不要硬写成检查。

## 写法

`checks` 是问题上的数组，每条对应一条验收标准（`acceptance` 是下标，从 0 开始）。选择器不由走查的人写，写成 `$槽位` 加中文说明，由研发在 `selectors.json` 里填真实选择器。

| kind | 作用 | 关键字段 |
| --- | --- | --- |
| style | 读计算样式并与期望值比较 | `property`、`tokenRef` 或 `expected`、`state`（hover / focus）、`all`（检查所有匹配元素）、`$target` 槽位 |
| transition | 读过渡时长（毫秒）并与期望值比较 | `property`、`tokenRef` 或 `expected`、`state`、`reducedMotion`、`$target` 槽位 |
| focus | Tab 键聚焦到元素后，样式有没有可见变化 | `$target` 槽位 |
| flow | 一串操作加判断 | `steps`、`mock`（要拦截的请求片段，会被延迟约 800ms 后返回） |

flow 的步骤：`fill`（加 `value`）、`click`（可加 `force`）、`hover`、`press`、`wait`、`repeat`（加 `do`）、`expect`。
expect 的判断：`visible`、`hidden`、`count`（`eq` / `lte` / `gte`）、`text`（`contains` / `equals`）、`value`（`equals`）、`disabled`、`enabled`、`urlHash`（写成 `"#new"`）、`requests`（URL 片段加 `eq` / `lte` / `gte`）。

规则：
- 期望值写 `tokenRef` 时，取 token 当前的值，不自拟。不属于 token 的才写 `expected`。
- 点击一个可能不存在的元素前，先写一条 `expect visible`。这样缺失会记为“失败”，而不是“执行出错”。
- 第一条不成立的 `expect` 会结束这条流程，后面的步骤不再执行。

## 生成和运行

```
node scripts/generate-regression.mjs --findings findings.json --tokens tokens.json --out regression/
cd regression && npm install && npx playwright install chromium
# 填 selectors.json 和 regression.config.json 的 pages
node run.mjs --variant fixed          # 单次
node run.mjs --variant fixed --repeat # 连跑三次确认稳定
```

重复生成不会覆盖研发已填好的选择器和页面配置。

## 结果含义

| 状态 | 含义 |
| --- | --- |
| passed | 页面符合这条标准 |
| failed | 页面明确违反标准 |
| notRun | 选择器或页面地址没配齐，不算通过 |
| error | 检查本身没跑完（选择器写错、页面打不开），不算通过也不算失败 |

退出码：0 全部通过；1 有失败或执行错误；2 有未执行项。

## 合并回清单

```
node scripts/merge-results.mjs --findings findings.json --results regression/reports/regression-report.json
```

- 把每条标准的结果写进 `recheck.auto`，报告里的验收标准旁会显示“自动：通过 / 未通过 / 未执行”。
- 有失败项：`recheck.result` 置为 `fail`；原状态是 `fixed` 或 `verified` 的会退回 `confirmed`，并记录原状态。
- 不会自动写 `pass`，也不会自动改成 `verified`。自动检查全部通过，只说明这几条标准在这次运行里成立，是否关单由设计和产品回验决定。

## 已知边界

- 只在 1440×900 一个视口、Chromium 一个浏览器里运行。
- 样式检查在状态动作后等待约 600ms 再读值，动效很长的组件需要调大 `settleMs`。
- 框架自动生成的类名（如 `.ant-`、`.css-`）会收到选择器提醒，建议改用 `data-testid`。
- 示例回归包对着一个模拟页面验证过，没有对着真实产品验证过。

## 迭代验收补充：refs

迭代验收里，每个 check 可以加 `refs`，把槽位对应到设计稿的 `data-ref` 名：

```json
{ "acceptance": 0, "kind": "flow", "slots": { "$qty": "本次收货数量输入框", "$err": "错误提示" },
  "refs": { "$qty": "receive-qty", "$err": "receive-error" }, "steps": [ … ] }
```

按约定，开发页用同名 `data-testid`，所以 `dispatch.mjs` 会把选择器预填成 `[data-testid='receive-qty']`，开发不用再逐个填。还原度对照生成的问题自动带 `refs`。
