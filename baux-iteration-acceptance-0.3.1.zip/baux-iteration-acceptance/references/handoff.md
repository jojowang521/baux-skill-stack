# 和开发、测试的交接

开发和测试不需要用 Claude，交接全靠文件。

## 交给开发：dispatch.mjs 生成的分发包

```
dispatch/
  README.md            开发看的说明
  待修复清单.md         每项的现状、期望、复现步骤、验收标准、现状截图；退回的项写明上一轮原因
  shots/               现状截图
  regression/          回归包：rules.json、selectors.json（按 data-testid 预填）、regression.config.json、run.mjs
  receipt.json         回执模板（含问题原因可选项 causeOptions）
  建单表格.csv          在 TAPD、Jira 等系统批量建单用
```

开发需要做的：
1. 在 `regression/regression.config.json` 里填页面地址，`npm install` 后运行 `node run.mjs`。
2. 修完自测，报告在 `regression/reports/*.json`。带自动检查的项必须全过。
3. 每项截一张修复后的图（或录一段屏）放到 `shots/`，文件名和 receipt.json 的 `after` 一致。
4. 填 receipt.json：`note` 写改了什么，`cause` 从 causeOptions 里选一个原因，`commit` 可选。没修的项删掉。
5. 觉得某项不该自己改、或方案行不通，不要硬改：把理由交给产品或设计登记为异议（`act.mjs dispute`），等拍板人回复。
6. 把 receipt.json、shots/、自测报告交回。

重复生成分发包不会覆盖开发已填的选择器、页面地址和回执。

## 导入

```
node scripts/act.mjs results --ledger … --report 自测报告.json --source 开发自测 --by 开发姓名 --role 开发
node scripts/act.mjs receipt --ledger … --file dispatch/receipt.json --by 开发姓名 --role 开发
```

回执里的截图会拷进台账目录的 `shots/`，按轮次命名，旧轮次的图保留。

## 测试复验

测试用同一个回归包在测试环境跑一遍，把报告交回：

```
node scripts/act.mjs results --ledger … --report 测试环境报告.json --source 测试环境 --by 测试姓名 --role 测试
```

有失败的项自动退回待修复。功能缺陷由测试签收；其余项由产品或设计签收，测试的回归结果是他们签收的依据。

## 为什么不由 Claude 直接跑

Claude 所在的环境通常访问不到公司内网的测试环境。自测和复验都在开发、测试自己的机器或流水线上跑，结果以文件交回，台账只认导入的结果。

## 外部单号

团队的任务流转在 TAPD、Jira 等系统里，技能不替代它们，只把单号挂回来，方便两边对照：

1. 分发包里的 `建单表格.csv` 有标题、页面、严重度、期望、验收标准，可以直接导入或照着批量建单。
2. 建好后整理成 `tickets.json`：`[{ "id": "F-007", "ticket": "TAPD-1001", "system": "TAPD", "url": "…" }]`。
3. `act.mjs link --file tickets.json` 挂回台账。之后分发清单、页面上都会显示单号。

## 0.3.1 回归结果与升级

- 真实环境填写 `regression.config.json` 的 `target.version`，或使用 `node run.mjs --target-version <提交号或部署版本>`；模拟示例可使用 `--variant fixed`。
- 报告包含被测版本、规则指纹和修复轮次。旧格式、过期轮次、变更前规则、重复规则和未知结果会被拒绝导入。
- `--only` 的范围是具体问题；同一问题仍须完整执行全部检查。漏项计为未执行，不能提测或签收。
- 退回、异议后重新下发或修改验收条件时，重新生成分发包并运行回归。旧结果保留在 `autoHistory`，不再作为本轮通过依据。
- 旧台账已关闭的自动项可以用 `dispatch.mjs --include-closed` 重新生成检查；通过保留原签收，未通过重新打开。
