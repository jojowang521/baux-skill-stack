# Figma 设计稿

设计稿是 Figma 时，只把“采集基线”这一步换成 `capture-baseline-figma.mjs`。它输出的基线文件和 HTML 设计稿的格式完全相同，之后的对照、判定、下发、签收都不变。

## 设计师要做的三件事

1. **给要还原的图层命名为 `#ref`。** 例如 `#order-row`、`#status-cancelled`。ref 用小写字母、数字和连字符；名字后面可以加空格和备注（`#status-cancelled 已取消标签`）。重复的元素（表格行、标签）用同一个名字。开发页在对应元素上加同名 `data-testid`。
2. **冻结：保存一个命名版本。** 在 Figma 版本历史里保存版本，把版本 id 交给采集脚本（`--version`）。对照的是这个版本，之后稿子再改也不影响本次基线。改稿后保存新版本、重新采集。
3. **尽量绑定变量。** 颜色、字号、间距绑定了 Figma 变量，并且变量名和 token 对得上（`color/status-neutral` 对应 `color.status-neutral`），期望值就直接取绑定的 token，不用按数值去猜。没绑的不算问题，只是期望值改为按数值匹配 token；同值的 token 不止一个时可能选错。

## 能取哪些值

| 还原度属性 | Figma 里的来源 | 说明 |
|---|---|---|
| 文字颜色 | 文字图层的填充 | 容器图层没有文字颜色，不比 |
| 背景色、边框色 | 填充、描边 | 渐变、图片填充不比；半透明颜色不参与 token 匹配 |
| 字号、字重、行高 | 文字样式 | 行高为“自动”时不比 |
| 高度 | 图层尺寸 | 高度是派生值，设计稿取值不在 token 上时不判 |
| 圆角 | 圆角 | 四角不同时取左上角 |
| 内边距、间距 | 自动布局 | 没开自动布局的图层不比；开发页不是 flex/grid 布局时，间距不比 |
| 元素截图 | 按图层导出 PNG | 用来拼“设计稿｜开发页”对照图 |
| 过渡时长 | — | 原型动效不比 |

采集时会列出“不可比”的属性和“手写数值没有绑变量”的数量，方便设计决定要不要补。

## 结构差异要注意

Figma 的图层结构和开发页的 DOM 结构不一定一样。例如表格行在 Figma 里是一个自动布局容器、内边距在单元格上，开发页的内边距写在 `td` 上。`#ref` 尽量标在两边结构一致的元素上（单元格、标签、按钮），不要标在只存在于某一边的包装层上。

## 运行方式

在线（需要能访问 api.figma.com，并有访问令牌）：
```
FIGMA_TOKEN=xxx node scripts/capture-baseline-figma.mjs --file https://www.figma.com/design/KEY/… \
  --screens "order-list=12:34,order-detail=12:80" --version 1234567890 \
  --out work/baseline/v1.0.json --shots work/baseline/shots --ledger work/iteration.json
```
- `--screens` 写“页面名=画框 node-id”。在 Figma 里选中画框、复制链接，链接里的 `node-id=12-34` 就是它。
- 变量名通过 `variables/local` 接口读取，这个接口一般需要企业版。读不到时脚本会提示，变量绑定关系仍会记录，期望值改为按数值匹配；也可以用 `--variables` 提供导出的变量文件。

离线（已有接口返回的 JSON）：
```
node scripts/capture-baseline-figma.mjs --from-json nodes.json --screens "order-list=12:34" --version 1234567890 --version-label 1.0 \
  [--variables variables.json] [--images-dir 图片目录] --out … --shots …
```
`nodes.json` 是 `GET /v1/files/:key/nodes?ids=…` 的原样返回；`--images-dir` 里放按 node-id 命名的元素截图（`12-34.png`），没有截图时对照图只有开发页一侧。

Claude 所在的云端环境通常访问不到 api.figma.com，在线模式请在本机运行。

## 示例

`examples/order-receiving/figma/` 是订单列表的 Figma 节点样例（模拟数据，结构按接口格式）。运行 `node run-figma-demo.mjs`，结果和 HTML 设计稿一致：行高、“已取消”颜色两个开发问题，字号 13px 的设计稿问题，开发页缺 `status-running`。其中“已取消”的期望值来自变量绑定（`color.status-neutral`），没有按数值误选成同色的 `color.text-secondary`。
