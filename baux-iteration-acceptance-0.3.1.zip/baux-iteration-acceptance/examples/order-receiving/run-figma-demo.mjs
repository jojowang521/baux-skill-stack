#!/usr/bin/env node
// 设计稿是 Figma 时的还原度对照演示（离线模式，用保存下来的 Figma 接口返回）。模拟数据。
// 用法：node run-figma-demo.mjs   输出在 work-figma/，过程记录在 work-figma/演示记录.md
// 真实使用时把 --from-json 换成 --file <Figma 链接> --version <版本 id>，并提供 FIGMA_TOKEN。
import { execFileSync } from 'node:child_process';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
const here = import.meta.dirname; const skill = resolve(here, '../..'); const W = join(here, 'work-figma');
rmSync(W, { recursive: true, force: true }); mkdirSync(W, { recursive: true });
const log = ['# Figma 设计稿还原度对照 · 演示记录', '', '模拟数据。Figma 节点来自保存下来的接口返回（figma/nodes.json），变量名来自 figma/variables.json。', '']; let n = 0; let bad = 0;
function run(title, file, args, expectFail = false) {
  n++; let out = ''; let failed = false;
  try { out = execFileSync('node', [join(skill, 'scripts', file), ...args], { cwd: here, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { failed = true; out = (e.stdout ?? '') + (e.stderr ?? ''); }
  const ok = failed === expectFail; if (!ok) bad++;
  log.push(`## ${n}. ${title}${expectFail ? '（应被拒绝）' : ''}`, '', '```', `$ node scripts/${file} ${args.map(x => x.includes(' ') ? `"${x}"` : x).join(' ')}`, out.trim(), '```', '');
  console.log(`${ok ? '✓' : '✗'} ${n}. ${title}`); if (!ok) console.log(out);
}
run('建单', 'init-iteration.mjs', ['--product', '采购管理平台', '--module', '订单收货', '--iteration', '2026-11 第1迭代（Figma 稿）', '--pages', '订单列表', '--tokens', '../../assets/tokens/builtin-b2b-default.json', '--out', 'work-figma/iteration.json']);
run('没有指定冻结版本', 'capture-baseline-figma.mjs', ['--from-json', 'figma/nodes.json', '--screens', 'order-list=10:1', '--out', 'work-figma/baseline/figma.json', '--shots', 'work-figma/baseline/shots'], true);
run('从 Figma 采集基线（命名版本 v1.0）', 'capture-baseline-figma.mjs', ['--from-json', 'figma/nodes.json', '--screens', 'order-list=10-1', '--version', '2214938712', '--version-label', '1.0', '--variables', 'figma/variables.json', '--images-dir', 'figma/images', '--out', 'work-figma/baseline/figma-v1.0.json', '--shots', 'work-figma/baseline/shots', '--ledger', 'work-figma/iteration.json']);
run('对照开发页', 'compare-fidelity.mjs', ['--ledger', 'work-figma/iteration.json', '--baseline', 'work-figma/baseline/figma-v1.0.json', '--targets', 'targets.json', '--shots', 'work-figma/shots']);
run('看进度', 'status.mjs', ['--ledger', 'work-figma/iteration.json'], true);
writeFileSync(join(W, '演示记录.md'), log.join('\n') + '\n');
console.log(bad ? `有 ${bad} 步与预期不符` : '全部步骤与预期一致。记录：work-figma/演示记录.md'); process.exit(bad ? 1 : 0);
