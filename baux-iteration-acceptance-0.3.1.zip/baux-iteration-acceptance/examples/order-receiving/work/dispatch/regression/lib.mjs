// 共享逻辑：枚举、token 解析、数值比较、findings 校验。
// 校验规则是本技能 的核心约束，build-report 与 validate-findings 共用同一份。
import { readFileSync } from 'node:fs';

export const DIMENSIONS = { color: '颜色', spacing: '间距', size: '尺寸', typography: '字体排版', motion: '动效', interaction: '交互', function: '功能' };
export const TOKEN_DIMENSIONS = ['color', 'spacing', 'size', 'typography', 'motion'];
export const TYPES = ['交互问题', 'UI问题', '开发还原度', 'BUG问题'];
export const SEVERITIES = ['高', '中', '低'];
export const OWNERS = { dev: '研发', design: '设计', product: '产品' };
export const STATUSES = ['draft', 'confirmed', 'rejected', 'fixed', 'verified'];
export const EVIDENCE_STATES = ['measured', 'observed', 'missing'];

export const readJson = path => JSON.parse(readFileSync(path, 'utf8'));

export function resolveToken(tokens, ref) {
  if (!ref) return null;
  const [dim, ...rest] = String(ref).split('.');
  const entry = tokens?.[dim]?.[rest.join('.')];
  return entry && typeof entry === 'object' && 'value' in entry ? { dim, key: rest.join('.'), ...entry } : null;
}

export function normColor(value) {
  const text = String(value ?? '').trim().toLowerCase();
  let match = text.match(/^#([0-9a-f]{3})$/);
  if (match) return '#' + [...match[1]].map(c => c + c).join('');
  match = text.match(/^#([0-9a-f]{6})([0-9a-f]{2})?$/);
  if (match) return match[2] && match[2] !== 'ff' ? `#${match[1]}${match[2]}` : `#${match[1]}`;
  match = text.match(/^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)(?:[\s,/]+([\d.]+))?\s*\)$/);
  if (match) {
    const hex = [match[1], match[2], match[3]].map(n => Number(n).toString(16).padStart(2, '0')).join('');
    return match[4] !== undefined && Number(match[4]) !== 1 ? null : '#' + hex;
  }
  return null;
}

export function parseNum(value) {
  const match = String(value ?? '').trim().match(/^(-?\d+(?:\.\d+)?)(px|ms|s|rem|em|%)?$/i);
  if (!match) return null;
  let n = Number(match[1]); let unit = (match[2] ?? '').toLowerCase();
  if (unit === 's') { n *= 1000; unit = 'ms'; }
  return { n, unit };
}

export function toleranceFor(tokens, dim) {
  const raw = tokens?.tolerance?.[dim];
  if (raw == null || raw === 'exact') return 0;
  return parseNum(raw)?.n ?? 0;
}

const squash = value => String(value ?? '').replace(/\s+/g, '').toLowerCase();

/** 比较期望值与实测值。within = 偏差落在容差内（不构成问题）。 */
export function compareValues(dim, expected, actual, tokens) {
  if (dim === 'color') {
    const a = normColor(expected); const b = normColor(actual);
    if (a && b) return { equal: a === b, within: a === b, delta: a === b ? '0' : '色值不符' };
  } else {
    const e = parseNum(expected); const a = parseNum(actual);
    if (e && a && e.unit === a.unit) {
      const diff = Math.round((a.n - e.n) * 100) / 100;
      return { equal: diff === 0, within: Math.abs(diff) <= toleranceFor(tokens, dim), delta: (diff > 0 ? '+' : diff < 0 ? '−' : '') + Math.abs(diff) + e.unit };
    }
  }
  const same = squash(expected) === squash(actual);
  return { equal: same, within: same, delta: same ? '0' : '不符' };
}

export function sameValue(dim, a, b) {
  if (dim === 'color') { const x = normColor(a); const y = normColor(b); if (x && y) return x === y; }
  else { const x = parseNum(a); const y = parseNum(b); if (x && y && x.unit === y.unit) return x.n === y.n; }
  return squash(a) === squash(b);
}

const filled = value => typeof value === 'string' && value.trim().length > 0;
const list = value => Array.isArray(value) && value.length > 0 && value.every(filled);


export const CHECK_KINDS = ['style', 'transition', 'focus', 'flow'];
export const STEP_KEYS = ['fill', 'click', 'hover', 'press', 'wait', 'repeat', 'expect'];
export const EXPECT_KEYS = ['visible', 'hidden', 'count', 'text', 'value', 'disabled', 'enabled', 'urlHash', 'requests'];
export const CHECKPOINT_RESULTS = ['pending', 'ok', 'issue', 'skipped'];
const SLOT = /^\$[A-Za-z]\w*$/;

export function slotsUsed(value, out = new Set()) {
  if (typeof value === 'string') { if (SLOT.test(value)) out.add(value); }
  else if (Array.isArray(value)) value.forEach(v => slotsUsed(v, out));
  else if (value && typeof value === 'object') Object.values(value).forEach(v => slotsUsed(v, out));
  return out;
}

function checkExpect(expect, label, err) {
  const keys = EXPECT_KEYS.filter(k => k in (expect ?? {}));
  if (keys.length !== 1) { err(label, `expect 需要且只能有一个判断：${EXPECT_KEYS.join(' / ')}`); return; }
  const key = keys[0];
  const hasNum = ['eq', 'lte', 'gte'].some(k => typeof expect[k] === 'number');
  if (key === 'count' && !hasNum) err(label, 'count 需要 eq / lte / gte 之一（数字）');
  if (key === 'requests' && (!filled(expect.requests) || !hasNum)) err(label, 'requests 需要请求地址片段，以及 eq / lte / gte 之一');
  if (key === 'text' && !(filled(expect.contains) || filled(expect.equals))) err(label, 'text 需要 contains 或 equals');
  if (key === 'value' && typeof expect.equals !== 'string') err(label, 'value 需要 equals');
  if (key === 'urlHash' && !/^#/.test(String(expect.urlHash ?? ''))) err(label, 'urlHash 需要写成期望的 hash，如 "#new"');
}
function checkStep(step, label, err) {
  const keys = STEP_KEYS.filter(k => k in (step ?? {}));
  if (keys.length !== 1) { err(label, `步骤需要且只能有一个动作：${STEP_KEYS.join(' / ')}`); return; }
  const key = keys[0];
  if (key === 'fill' && typeof step.value !== 'string') err(label, 'fill 需要 value');
  if (key === 'repeat') { if (!(Number.isInteger(step.repeat) && step.repeat > 0)) err(label, 'repeat 需要正整数'); else checkStep(step.do, label + ' › do', err); }
  if (key === 'expect') checkExpect(step.expect, label, err);
  if (key === 'wait' && !(typeof step.wait === 'number' && step.wait >= 0)) err(label, 'wait 需要毫秒数');
}

/** 校验一条 check（验收标准对应的自动检查规格）。 */
function validateCheck(f, c, index, tokens, err, warn) {
  const label = `${f.id} checks[${index}]`;
  const e = message => err(label, message);
  if (!CHECK_KINDS.includes(c.kind)) { e(`kind 无效：${c.kind}`); return; }
  if (!Number.isInteger(c.acceptance) || !filled(f.acceptance?.[c.acceptance])) e('acceptance 需要指向该问题已有的验收标准（从 0 开始的序号）');
  if (!c.slots || typeof c.slots !== 'object' || !Object.keys(c.slots).length) e('slots 必填：用 $名字 给每个要定位的元素起名，并写一句人能看懂的说明');
  else for (const [name, hint] of Object.entries(c.slots)) { if (!SLOT.test(name)) e(`槽位名 ${name} 需形如 $target`); if (!filled(hint)) e(`槽位 ${name} 缺少说明`); }
  const slots = c.slots ?? {};
  if (['style', 'transition', 'focus'].includes(c.kind) && !('$target' in slots)) e('需要 $target 槽位');
  if (c.kind === 'style' || c.kind === 'transition') {
    if (!filled(c.property)) e('缺少 property');
    const want = c.kind === 'style' ? ['color', 'spacing', 'size', 'typography'] : ['motion'];
    if (c.tokenRef) {
      const token = resolveToken(tokens, c.tokenRef);
      if (!token) e(`tokenRef ${c.tokenRef} 不在当前 token 集中`);
      else if (!want.includes(token.dim)) e(`${c.kind} 检查不能引用 ${token.dim} 类 token`);
    } else if (!filled(c.expected)) e('需要 tokenRef，或用 expected 写字面期望值');
  }
  if (c.kind === 'flow') {
    if (!Array.isArray(c.steps) || !c.steps.length) e('flow 需要 steps');
    else c.steps.forEach((step, i) => checkStep(step, `${label} steps[${i}]`, err));
    const used = slotsUsed(c.steps ?? []);
    for (const name of used) if (!(name in slots)) e(`步骤里用了未声明的槽位 ${name}`);
    for (const name of Object.keys(slots)) if (!used.has(name)) warn(label, `槽位 ${name} 声明了但没有使用`);
    if (c.mock !== undefined && !(Array.isArray(c.mock) && c.mock.every(filled))) e('mock 需要请求地址片段数组');
  }
}

/** 校验 findings。extra.checkpoints 为走查检查点数组（可选）。返回 { errors, warnings, stats }。 */
export function validate(data, tokens, extra = {}) {
  const errors = []; const warnings = [];
  const err = (id, message) => errors.push(`${id}: ${message}`);
  const warn = (id, message) => warnings.push(`${id}: ${message}`);
  const findings = data.findings ?? []; const groups = data.groups ?? [];
  const groupIds = new Set(groups.map(g => g.id)); const seen = new Set(); const members = {};

  if (!data.meta?.product) err('meta', '缺少 product');
  if (!findings.length) err('findings', '没有任何问题');

  for (const f of findings) {
    const id = f.id ?? '(无编号)';
    if (!/^F-\d{3,}$/.test(f.id ?? '')) err(id, '编号需形如 F-001');
    if (seen.has(f.id)) err(id, '编号重复'); seen.add(f.id);
    for (const key of ['title', 'module', 'page', 'severityBasis']) if (!filled(f[key])) err(id, `缺少 ${key}`);
    if (!(f.dimension in DIMENSIONS)) err(id, `dimension 无效：${f.dimension}`);
    if (!TYPES.includes(f.type)) err(id, `type 无效：${f.type}`);
    if (!SEVERITIES.includes(f.severity)) err(id, `severity 无效：${f.severity}`);
    if (!(f.owner in OWNERS)) err(id, `owner 无效：${f.owner}`);
    if (!STATUSES.includes(f.status)) err(id, `status 无效：${f.status}`);
    if (!EVIDENCE_STATES.includes(f.evidence?.state)) err(id, `evidence.state 无效：${f.evidence?.state}`);
    if (!list(f.repro)) err(id, '缺少复现步骤 repro');

    const toDev = f.owner === 'dev' && ['confirmed', 'fixed', 'verified'].includes(f.status);
    if (toDev) {
      if (!filled(f.expected)) err(id, '研发处理项缺少 expected（期望行为）');
      if (!list(f.acceptance)) err(id, '研发处理项缺少 acceptance（可验证的验收标准）。写不出验收标准，说明还没想清楚，请把处理方改为设计或产品');
      if (f.evidence?.state === 'missing') warn(id, '研发处理项没有证据，建议补截图或取值');
    }
    if (f.status === 'rejected' && !filled(f.rejectReason)) err(id, '已驳回项需要 rejectReason');
    if (f.status === 'verified' && f.recheck?.result !== 'pass') err(id, 'verified 需要 recheck.result 为 pass');
    if (f.status === 'fixed' && f.recheck?.result === 'pass') warn(id, '回验已通过，状态可改为 verified');

    if (f.group) { if (!groupIds.has(f.group)) err(id, `通用问题 ${f.group} 未定义`); (members[f.group] ??= []).push(f.id); }

    if (TOKEN_DIMENSIONS.includes(f.dimension)) {
      if (!f.tokenRef) {
        if (!filled(f.noTokenReason)) err(id, `${DIMENSIONS[f.dimension]}类问题需要 tokenRef，或用 noTokenReason 说明为什么没有对应 token`);
      } else {
        const token = resolveToken(tokens, f.tokenRef);
        if (!token) err(id, `tokenRef ${f.tokenRef} 不在当前 token 集中`);
        else if (!f.expectedValue) err(id, '有 tokenRef 时需要 expectedValue');
        else if (!sameValue(f.dimension, f.expectedValue, token.value)) err(id, `expectedValue ${f.expectedValue} 与 token ${f.tokenRef} 的值 ${token.value} 不一致。期望值必须来自 token，不能自拟`);
        if (token && f.expectedValue) {
          if (f.evidence?.state === 'measured') {
            if (!filled(f.actualValue)) err(id, '实测证据需要 actualValue');
            else if (compareValues(f.dimension, f.expectedValue, f.actualValue, tokens).within) err(id, `实测 ${f.actualValue} 与期望 ${f.expectedValue} 的偏差在容差内，不构成问题`);
          } else if (filled(f.actualValue)) warn(id, '非实测证据不应填写具体 actualValue（从截图估像素不可靠）');
        }
      }
    }
    if (f.missingStates !== undefined) {
      const required = tokens?.interaction?.stateMatrix?.[f.component];
      if (!required) err(id, `component ${f.component} 不在状态矩阵中`);
      else { const bad = f.missingStates.filter(s => !required.includes(s)); if (bad.length) err(id, `missingStates 含矩阵之外的状态：${bad.join('、')}`); }
    }
    if (f.checks !== undefined) {
      if (!Array.isArray(f.checks)) err(id, 'checks 需要是数组');
      else f.checks.forEach((c, i) => validateCheck(f, c, i, tokens, (l, m) => errors.push(`${l}: ${m}`), (l, m) => warnings.push(`${l}: ${m}`)));
      if (Array.isArray(f.checks) && f.owner !== 'dev') warn(id, '只有研发处理项的验收标准会进入自动检查');
    }
    if (f.checkpoint !== undefined && extra.checkpoints && !extra.checkpoints.some(c => c.id === f.checkpoint)) err(id, `checkpoint ${f.checkpoint} 不在检查点清单中`);
  }
  for (const group of groups) if ((members[group.id] ?? []).length < 2) warn(group.id, `通用问题只有 ${(members[group.id] ?? []).length} 条成员，归并意义不足`);

  const count = pred => findings.filter(pred).length;
  const stats = {
    total: findings.length,
    toDev: count(f => f.owner === 'dev' && f.status === 'confirmed'),
    heldDesign: count(f => f.owner === 'design' && ['draft', 'confirmed'].includes(f.status)),
    heldProduct: count(f => f.owner === 'product' && ['draft', 'confirmed'].includes(f.status)),
    draftDev: count(f => f.owner === 'dev' && f.status === 'draft'),
    withChecks: count(f => Array.isArray(f.checks) && f.checks.length > 0),
    fixed: count(f => f.status === 'fixed'), verified: count(f => f.status === 'verified'), rejected: count(f => f.status === 'rejected')
  };
  return { errors, warnings, stats };
}

/** 校验走查检查点，并统计覆盖。 */
export function validateCheckpoints(checkpoints, findings) {
  const errors = []; const warnings = []; const seen = new Set();
  const refs = {}; for (const f of findings) if (f.checkpoint) (refs[f.checkpoint] ??= []).push(f.id);
  for (const c of checkpoints) {
    if (!c.id) { errors.push('检查点缺少 id'); continue; }
    if (seen.has(c.id)) errors.push(`${c.id}: 编号重复`); seen.add(c.id);
    if (!CHECKPOINT_RESULTS.includes(c.result)) errors.push(`${c.id}: result 无效：${c.result}`);
    if (c.result === 'issue' && !(refs[c.id] ?? []).length) errors.push(`${c.id}: 标记为发现问题，但没有任何问题引用它（findings 里用 checkpoint 字段关联）`);
    if (c.result === 'ok' && (refs[c.id] ?? []).length) errors.push(`${c.id}: 标记为没有问题，但 ${refs[c.id].join('、')} 引用了它`);
    if (c.result === 'skipped' && !filled(c.note)) errors.push(`${c.id}: 跳过需要在 note 里写原因`);
    if (c.result === 'pending' && (refs[c.id] ?? []).length) warnings.push(`${c.id}: 已有问题引用，但 result 还是 pending，应改为 issue`);
  }
  const count = (list, r) => list.filter(c => c.result === r).length;
  const summarize = list => ({ total: list.length, ok: count(list, 'ok'), issue: count(list, 'issue'), skipped: count(list, 'skipped'), pending: count(list, 'pending') });
  const stages = []; const byStage = new Map();
  for (const c of checkpoints) { const key = c.stage ?? 'global'; if (!byStage.has(key)) { byStage.set(key, []); stages.push({ id: key, name: c.stageName ?? '全局' }); } byStage.get(key).push(c); }
  const coverage = { ...summarize(checkpoints), stages: stages.map(s => ({ ...s, ...summarize(byStage.get(s.id)) })) };
  coverage.walked = coverage.ok + coverage.issue;
  coverage.gaps = checkpoints.filter(c => c.result === 'pending' || c.result === 'skipped').map(c => ({ id: c.id, stage: c.stageName ?? '全局', page: c.page ?? '', prompt: c.prompt, result: c.result, note: c.note ?? '' }));
  return { errors, warnings, coverage };
}
