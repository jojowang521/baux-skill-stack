# 开发分发包 · 订单收货 2026-11 第1迭代

1. 看 `待修复清单.md`，每项都有复现步骤、期望和验收标准。
2. 修完后自测：进 `regression/`，按里面的 README 填页面地址（选择器已按 data-testid 预填，名字和设计稿 data-ref 一致），运行 `node run.mjs`。
   报告在 `regression/reports/regression-report.json`，带自动检查的项必须全部通过才能提测。
3. 每项截一张修复后的图，放到 `shots/`，文件名与 receipt.json 里的 after 一致。
4. 填 `receipt.json`：每项写一句改了什么（note），从 causeOptions 里选一个问题原因填进 cause（只填冒号后面的部分），有提交号就填 commit。没修的项从文件里删掉，不要留空。
   截图换成录屏也可以（mp4 / mov / webm），after 写对应的文件名。
   对某一项有异议（不该你改、方案行不通），不要硬改，把理由交给产品或设计登记为异议。
5. 把 receipt.json、shots/ 和自测报告一起交回给产品或设计导入。
