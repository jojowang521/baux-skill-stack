#!/usr/bin/env node
// 订单收货迭代：从建单到准出的完整闭环演示。全部是模拟数据。
// 用法：node run-demo.mjs        （需要 Playwright；输出在 work/，过程记录在 work/演示记录.md）
// 每一步都调用 技能的真实脚本；标“应被拒绝”的步骤用来演示守卫，拒绝才算对。
import { execFileSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';

const here = import.meta.dirname; const skill = resolve(here, '../..'); const W = join(here, 'work');
const S = name => join(skill, 'scripts', name);
rmSync(W, { recursive: true, force: true }); mkdirSync(W, { recursive: true });
const log = ['# 订单收货迭代 · 闭环演示记录', '', '模拟数据。每一步是一条真实命令和它的输出；“应被拒绝”的步骤演示守卫。', ''];
let stepNo = 0; let failures = 0;
function run(title, who, file, args, { expectFail = false, cwd = here } = {}) {
  stepNo++;
  let out = ''; let failed = false;
  try { out = execFileSync('node', [file, ...args], { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); }
  catch (e) { failed = true; out = (e.stdout ?? '') + (e.stderr ?? ''); }
  const okay = failed === expectFail; if (!okay) failures++;
  const shown = [file.replace(skill + '/', ''), ...args.map(x => x.includes(' ') ? `"${x}"` : x)].join(' ').replaceAll(here + '/', '');
  log.push(`## ${stepNo}. ${title}`, '', `${who}${expectFail ? ' · **应被拒绝**' : ''}${okay ? '' : ' · ⚠️ 与预期不符'}`, '', '```', `$ node ${shown}`, out.trim(), '```', '');
  console.log(`${okay ? '✓' : '✗'} ${stepNo}. ${title}${expectFail ? '（拒绝）' : ''}`);
  if (!okay) console.log(out);
  return out;
}
const act = (title, who, args, opt) => run(title, who, S('act.mjs'), [args[0], '--ledger', 'work/iteration.json', ...args.slice(1)], opt);
const shoot = (scene, variant, out, extra) => execFileSync('node', ['tools/shoot.mjs', scene, variant, out, ...(extra ? [extra] : [])], { cwd: here });
const writeJson = (p, v) => { mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, JSON.stringify(v, null, 2) + '\n'); };

/* ── 一、建单与对照设计稿 ── */
run('建单：带入走查记录里属于本模块的问题', '产品 周敏', S('init-iteration.mjs'), ['--product', '采购管理平台', '--module', '订单收货', '--iteration', '2026-11 第1迭代', '--pages', '订单列表,订单详情,收货单', '--tokens', '../../assets/tokens/builtin-b2b-default.json', '--design', 'design/order-list.html', '--from', 'walkthrough.json', '--people', '产品=周敏,设计=王娇,测试=刘洋,开发=陈哲', '--env', 'https://test.example.com/procurement', '--design-url', '订单列表=https://design.example.com/procurement/order-list,订单详情=https://design.example.com/procurement/order-detail,收货单=https://design.example.com/procurement/receipt', '--out', 'work/iteration.json']);
run('采集设计稿基线（v1.0，已冻结）', '设计 王娇', S('capture-baseline.mjs'), ['--design', 'design/order-list.html', '--out', 'work/baseline/v1.0.json', '--shots', 'work/baseline/shots', '--ledger', 'work/iteration.json']);
run('对照开发页，自动生成还原度问题', '设计 王娇', S('compare-fidelity.mjs'), ['--ledger', 'work/iteration.json', '--baseline', 'work/baseline/v1.0.json', '--targets', 'targets.json', '--shots', 'work/shots']);

/* ── 二、补截图、拍板、下发 ── */
mkdirSync(join(W, 'inbox'), { recursive: true });
shoot('cancel', 'defective', 'work/inbox/F-007.png'); shoot('tabs', 'defective', 'work/inbox/F-013.webm'); shoot('receive', 'defective', 'work/inbox/F-018.png');
act('没有截图就想下发', '产品 周敏', ['decide', '--id', 'F-018', '--by', '周敏', '--role', '产品'], { expectFail: true });
act('补现状截图：F-007', '产品 周敏', ['attach', '--id', 'F-007', '--before', 'work/inbox/F-007.png', '--by', '周敏', '--role', '产品']);
act('补现状录屏：F-013（页签挤出可视区，截图说明不清）', '设计 王娇', ['attach', '--id', 'F-013', '--before', 'work/inbox/F-013.webm', '--by', '王娇', '--role', '设计']);
act('补现状截图：F-018', '测试 刘洋', ['attach', '--id', 'F-018', '--before', 'work/inbox/F-018.png', '--by', '刘洋', '--role', '测试']);
act('测试想拍板方案', '测试 刘洋', ['decide', '--id', 'F-018', '--by', '刘洋', '--role', '测试'], { expectFail: true });
act('产品拍板 F-007：定下取消规则，交开发', '产品 周敏', ['decide', '--id', 'F-007', '--owner', 'dev', '--expected', '点击取消订单先弹确认框，写明已收货部分保留、未收货部分取消；确认后才取消。', '--acceptance', '点击“取消订单”先弹出确认框，订单状态不变|确认框写明：已收货的部分不受影响，未收货的部分将取消|选择“再想想”关闭确认框，订单状态不变', '--by', '周敏', '--role', '产品']);
act('产品拍板 F-018，交开发', '产品 周敏', ['decide', '--id', 'F-018', '--by', '周敏', '--role', '产品']);
act('设计拍板 F-013、F-020、F-021，交开发', '设计 王娇', ['decide', '--id', 'F-013,F-020,F-021', '--by', '王娇', '--role', '设计']);
act('设计确认 F-022 是设计稿的问题，自己改稿', '设计 王娇', ['decide', '--id', 'F-022', '--owner', 'design', '--expected', '设计稿状态标签字号改为 12px（typography.font-size-caption），重新冻结为 v1.1。', '--by', '王娇', '--role', '设计']);
act('设计把 F-010 移到下一迭代', '设计 王娇', ['defer', '--id', 'F-010', '--note', '入口层级要等操作区规范（G2）统一定，本迭代不改', '--by', '王娇', '--role', '设计']);
act('设计想移出功能缺陷 F-019（签收人是测试）', '设计 王娇', ['defer', '--id', 'F-019', '--note', '下次再说', '--by', '王娇', '--role', '设计'], { expectFail: true });
act('产品把 F-019 移到下一迭代', '产品 周敏', ['defer', '--id', 'F-019', '--note', '导出改造和报表组一起排期，下个迭代处理', '--by', '周敏', '--role', '产品']);
run('生成开发分发包', '产品 周敏', S('dispatch.mjs'), ['--ledger', 'work/iteration.json', '--out', 'work/dispatch']);
writeJson(join(W, 'tickets.json'), ['F-007', 'F-013', 'F-018', 'F-020', 'F-021'].map((id, i) => ({ id, ticket: `TAPD-${1001 + i}`, system: 'TAPD', url: `https://tapd.example.com/story/${1001 + i}` })));
act('按建单表格在 TAPD 建好单，把单号挂回台账', '产品 周敏', ['link', '--file', 'work/tickets.json', '--by', '周敏', '--role', '产品']);
act('开发对 F-013 提异议', '开发 陈哲', ['dispute', '--id', 'F-013', '--note', '页签数量由框架统一控制，本模块改不了', '--by', '陈哲', '--role', '开发']);
act('不回复异议就重新下发', '设计 王娇', ['decide', '--id', 'F-013', '--by', '王娇', '--role', '设计'], { expectFail: true });
act('设计回复异议并重新下发 F-013', '设计 王娇', ['decide', '--id', 'F-013', '--note', '框架已提供 maxTabs 配置，本模块开启并设为 8 即可，不需要改框架', '--by', '王娇', '--role', '设计']);
act('设计给 F-013 挂上页签规范链接', '设计 王娇', ['link', '--id', 'F-013', '--url', 'https://design.example.com/spec/tabs', '--label', '页签规范', '--by', '王娇', '--role', '设计']);
run('重新生成分发包（带上异议回复）', '产品 周敏', S('dispatch.mjs'), ['--ledger', 'work/iteration.json', '--out', 'work/dispatch']);

/* ── 三、开发修复、自测、提交回执 ── */
const R = join(W, 'dispatch/regression');
const cfg = JSON.parse(readFileSync(join(R, 'regression.config.json'), 'utf8'));
cfg.target.root = '../../../dev-app'; Object.assign(cfg.pages, { 订单列表: '/app.html?variant={variant}#orders', 订单详情: '/app.html?variant={variant}#order-detail', 收货单: '/app.html?variant={variant}#receive' });
writeJson(join(R, 'regression.config.json'), cfg);
const pw = ['/usr/local/lib/node_modules', '/usr/lib/node_modules', process.env.NODE_PATH].filter(Boolean).find(p => existsSync(join(p, 'playwright')));
if (pw && !existsSync(join(R, 'node_modules'))) { mkdirSync(join(R, 'node_modules'), { recursive: true }); symlinkSync(join(pw, 'playwright'), join(R, 'node_modules/playwright')); symlinkSync(join(pw, 'playwright-core'), join(R, 'node_modules/playwright-core')); }
run('开发修复前先跑一遍回归包（应有失败）', '开发 陈哲', join(R, 'run.mjs'), ['--variant', 'defective', '--out', 'before-fix'], { expectFail: true, cwd: R });
const D = join(W, 'dispatch');
shoot('cancel', 'fixed', 'work/dispatch/shots/F-007-修复后.png', 'cancel=partial');
shoot('tabs', 'fixed', 'work/dispatch/shots/F-013-修复后.webm');
shoot('receive', 'fixed', 'work/dispatch/shots/F-018-修复后.png');
shoot('orders', 'fixed', 'work/dispatch/shots/F-020-修复后.png'); copyFileSync(join(D, 'shots/F-020-修复后.png'), join(D, 'shots/F-021-修复后.png'));
const receipt = JSON.parse(readFileSync(join(D, 'receipt.json'), 'utf8'));
const notes = { 'F-007': ['取消订单前增加确认框', 'a1c9e02', '业务逻辑缺陷'], 'F-013': ['开启框架 maxTabs=8，超出折叠到“更多”', 'b7d1f33', '组件属性配置错误'], 'F-018': ['收货数量输入即校验，超出时禁用保存', 'c03e9a1', '业务逻辑缺陷'], 'F-020': ['表格行高改用 size.table-row-height', 'd4410be', '自定义布局与规范不一致'], 'F-021': ['“已取消”标签改用 color.status-neutral；补 data-testid="status-running"', 'd4410be', '未按设计稿实现'] };
receipt.items.find(x => x.id === 'F-013') && (receipt.items.find(x => x.id === 'F-013').after = 'shots/F-013-修复后.webm');
receipt.items = receipt.items.filter(x => notes[x.id]).map(x => ({ ...x, note: notes[x.id][0], commit: notes[x.id][1], cause: notes[x.id][2] }));
writeJson(join(D, 'receipt.json'), receipt);
act('没跑自测就提交回执', '开发 陈哲', ['receipt', '--file', 'work/dispatch/receipt.json', '--by', '陈哲', '--role', '开发'], { expectFail: true });
run('开发自测：跑回归包（修复后）', '开发 陈哲', join(R, 'run.mjs'), ['--variant', 'fixed', '--out', 'self-test'], { cwd: R });
act('导入自测结果', '开发 陈哲', ['results', '--report', 'work/dispatch/regression/reports/self-test.json', '--source', '开发自测', '--by', '陈哲', '--role', '开发']);
act('提交修复回执，提测', '开发 陈哲', ['receipt', '--file', 'work/dispatch/receipt.json', '--by', '陈哲', '--role', '开发']);

/* ── 四、测试复验、各自签收 ── */
run('测试在测试环境跑回归包', '测试 刘洋', join(R, 'run.mjs'), ['--variant', 'fixed', '--out', 'test-env'], { cwd: R });
act('导入测试环境结果', '测试 刘洋', ['results', '--report', 'work/dispatch/regression/reports/test-env.json', '--source', '测试环境', '--by', '刘洋', '--role', '测试']);
act('测试想代设计签收 F-021', '测试 刘洋', ['sign', '--id', 'F-021', '--result', 'pass', '--by', '刘洋', '--role', '测试'], { expectFail: true });
act('测试签收功能缺陷 F-018', '测试 刘洋', ['sign', '--id', 'F-018', '--result', 'pass', '--by', '刘洋', '--role', '测试']);
act('设计批量签收自动检查全部通过的项', '设计 王娇', ['sign', '--auto-passed', '--result', 'pass', '--note', '回归全部通过，对照截图确认', '--by', '王娇', '--role', '设计']);
act('产品复验 F-007：确认框没写影响范围，退回', '产品 周敏', ['sign', '--id', 'F-007', '--result', 'fail', '--note', '确认框没写已收货部分怎么处理，不符合第 2 条验收标准', '--by', '周敏', '--role', '产品']);
shoot('cancel', 'fixed', 'work/dispatch/shots/F-007-修复后-第2轮.png');
writeJson(join(D, 'receipt-r2.json'), { items: [{ id: 'F-007', note: '确认框补充影响说明：已收货 2 件保留，未收货 3 件取消', commit: 'e58a7c4', cause: '需求不明确或有变化', after: 'shots/F-007-修复后-第2轮.png' }] });
act('开发第 2 轮修复 F-007，提交回执', '开发 陈哲', ['receipt', '--file', 'work/dispatch/receipt-r2.json', '--by', '陈哲', '--role', '开发']);
act('产品复验 F-007 通过', '产品 周敏', ['sign', '--id', 'F-007', '--result', 'pass', '--by', '周敏', '--role', '产品']);

/* ── 五、设计改稿，重新对照 ── */
mkdirSync(join(W, 'design-v1.1'), { recursive: true });
writeFileSync(join(W, 'design-v1.1/order-list.html'), readFileSync(join(here, 'design/order-list.html'), 'utf8').replace('content="1.0"', 'content="1.1"').replace('--font-size-tag: 13px', '--font-size-tag: 12px').replace('设计稿 v1.0', '设计稿 v1.1'));
run('设计改稿后重新冻结、采集基线 v1.1', '设计 王娇', S('capture-baseline.mjs'), ['--design', 'work/design-v1.1/order-list.html', '--out', 'work/baseline/v1.1.json', '--shots', 'work/baseline/shots-v1.1', '--ledger', 'work/iteration.json']);
writeJson(join(W, 'design-receipt.json'), { items: [{ id: 'F-022', note: '设计稿状态标签字号改为 12px（typography.font-size-caption），已冻结 v1.1', cause: '设计稿偏离规范', after: 'baseline/shots-v1.1/design-order-list-default-status-cancelled.png' }] });
act('设计提交改稿回执', '设计 王娇', ['receipt', '--file', 'work/design-receipt.json', '--by', '王娇', '--role', '设计']);
act('设计签收 F-022', '设计 王娇', ['sign', '--id', 'F-022', '--result', 'pass', '--by', '王娇', '--role', '设计']);
writeJson(join(W, 'targets-fixed.json'), { 'order-list': { url: '../dev-app/app.html?variant=fixed#orders', page: '订单列表' } });
run('用 v1.1 设计稿重新对照修复后的开发页', '设计 王娇', S('compare-fidelity.mjs'), ['--ledger', 'work/iteration.json', '--baseline', 'work/baseline/v1.1.json', '--targets', 'work/targets-fixed.json', '--shots', 'work/shots']);

/* ── 六、准出 ── */
run('看准出结论', '产品 周敏', S('status.mjs'), ['--ledger', 'work/iteration.json']);
run('生成迭代验收单页面', '产品 周敏', S('build-page.mjs'), ['--ledger', 'work/iteration.json', '--out', 'work/page', '--sample']);
writeFileSync(join(W, '演示记录.md'), log.join('\n') + '\n');
console.log(failures ? `\n有 ${failures} 步与预期不符，见 work/演示记录.md` : '\n全部步骤与预期一致。记录：work/演示记录.md；页面：work/page/index.html');
process.exit(failures ? 1 : 0);
