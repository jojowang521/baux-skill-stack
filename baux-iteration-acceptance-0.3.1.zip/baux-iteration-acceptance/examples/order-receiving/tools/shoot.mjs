// 演示用：模拟“人截图”。真实使用时，现状截图由提出人截，修复后截图由开发截。
// 用法：node tools/shoot.mjs <场景> <variant> <输出.png> [cancel=partial]
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { launchBrowser } from '../../../scripts/ledger.mjs';
const [scene, variant, out, extra] = process.argv.slice(2);
const app = pathToFileURL(resolve(import.meta.dirname, '../dev-app/app.html')).href + `?variant=${variant}${extra ? '&' + extra : ''}`;
const T = id => `[data-testid="${id}"]`;
const S = {
  cancel: { hash: '#order-detail', run: async p => { await p.click(T('cancel-order-btn')); await p.waitForTimeout(150); }, mark: [T('cancel-confirm') + ' .dialog', T('order-status')] },
  tabs: { hash: '#order-detail', run: async p => { for (let i = 0; i < 12; i++) await p.click(T('open-order-btn')); }, mark: [T('tab') + ':last-child'] },
  receive: { hash: '#receive', run: async p => { await p.fill(T('receive-qty'), '50'); await p.click(T('receive-submit'), { force: true, timeout: 500 }).catch(() => {}); await p.waitForTimeout(100); }, mark: [T('receive-qty'), T('receive-error')] },
  orders: { hash: '#orders', run: async () => {}, mark: ['[data-testid="order-row"]', '[data-testid="status-cancelled"]'] }
};
const s = S[scene]; if (!s) { console.error('未知场景'); process.exit(2); }
const b = await launchBrowser();
if (out.endsWith('.webm')) {
  // 录屏：慢一点操作，让问题在视频里看得清
  const { mkdtempSync, renameSync } = await import('node:fs'); const { tmpdir } = await import('node:os'); const { join } = await import('node:path');
  const tmp = mkdtempSync(join(tmpdir(), 'rec-'));
  const ctx = await b.newContext({ viewport: { width: 960, height: 420 }, recordVideo: { dir: tmp, size: { width: 960, height: 420 } } });
  const p = await ctx.newPage(); await p.goto(app + s.hash); await p.waitForTimeout(600);
  const slow = new Proxy(p, { get: (t, k) => k === 'click' ? async (...x) => { await t.click(...x); await t.waitForTimeout(250); } : (typeof t[k] === 'function' ? t[k].bind(t) : t[k]) });
  await s.run(slow); await p.waitForTimeout(800);
  const v = p.video(); await ctx.close(); renameSync(await v.path(), out);
} else {
  const p = await b.newPage({ viewport: { width: 960, height: 420 } });
  await p.goto(app + s.hash); await p.waitForTimeout(150); await s.run(p);
  await p.evaluate(sels => { for (const sel of sels) { const el = document.querySelector(sel); if (!el) continue; const r = el.getBoundingClientRect(); if (!r.width || getComputedStyle(el).display === 'none' || el.hidden) continue; const d = document.createElement('div'); Object.assign(d.style, { position: 'fixed', left: r.left - 4 + 'px', top: r.top - 4 + 'px', width: r.width + 8 + 'px', height: r.height + 8 + 'px', border: '2px solid #E5484D', borderRadius: '4px', pointerEvents: 'none', zIndex: 99999 }); document.body.appendChild(d); } }, s.mark);
  await p.screenshot({ path: out });
}
await b.close();
