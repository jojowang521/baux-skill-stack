---
name: page-quality-validator
description: 校验可运行的 B 端列表与管理页面，使用 6 条业务规则检查权限入口、批量选择、停用编辑与失败状态，并提供 4 条确定性视觉检查。适用于页面契约适配、证据报告和修复复检；不替代完整业务状态机、服务端授权或 UX 评审。
metadata:
  version: "1.0.0"
---

# 页面质量校验器

用于具备稳定元素定位方式和 query 场景的可浏览器运行的业务页面。本 Skill 不是视觉打分器、设计系统审计工具、像素对比工具或 AI 语义评价器。

## 工作流

1. 先阅读 `references/page-contract.md`，检查目标页面后再进行任何改动。
2. 用随附模板生成基线。生成基线时不得修改冻结规则语义、严重级别、fixture 期望或目标页面。
3. 按目标项目已有命令执行必要的构建与检查；本模板提供 npm test 语义单测，不含完整浏览器 fixture。适配后建立页面正反 fixture，再执行基线和三次重复运行。保留 JSON、HTML 与截图；目标文件哈希需由调用方另行记录，不宣称执行器已生成。
4. 严格区分 `failed` 与 `error`。`failed` 代表页面违反预期；`error` 代表执行失败。两者都不得被报告为通过。
5. 根据报告证据提出修复建议。只有用户明确授权、且 `fixMode` 为 `safe` 时，才能修改目标页面或其直接页面资源。
6. 完成授权修复后，用同一套冻结规则复检并生成前后对比。若基线没有可修复失败项，记录无补丁复检，不要修改页面。

版本 1.0.0 为本站统一整理版本，不代表跨项目或跨工具验证完成。需要 Node.js >=20.11、Playwright 与 Chromium；浏览器运行受当前环境能力与权限约束。

## 在新项目中使用

在 Skill 目录中运行脚手架。它会把轻量 Node/Playwright 校验器复制到目标项目，且不会覆盖已有文件。

```bash
node scripts/scaffold.mjs /absolute/path/to/project
cd /absolute/path/to/project/page-quality-validator
npm install
npx playwright install chromium
```

阅读 `references/page-contract.md` 后，修改 `page-quality.config.json`，填入页面场景、稳定定位器和视觉锚点。不得把框架自动生成的 CSS 类名作为主定位方式。

## 运行与验证

```bash
npm test
npm run validate
npm run validate:repeat
npm run visual:baseline
```

首次确认页面布局后，执行 `npm run visual:baseline` 冻结视觉锚点快照；随后 `npm run validate` 会同时检查业务规则和视觉规则。执行器会写入 `reports/baseline-report.json`、`reports/baseline-report.html`、证据截图、三次运行 JSON 报告和重复性对比。它使用随机 loopback 端口，并在结束时关闭服务器和浏览器。

退出码：0 = 全部通过；1 = 存在失败、执行错误或重复漂移；2 = 存在未执行项。稳定重复不等于通过。模板只提供静态文件服务；SPA、鉴权与真实 API 需要单独适配。

## 冻结规则

适配页面前先阅读 `references/frozen-rules.md`。只配置定位器和页面专属值，必须保留以下 6 条规则的含义：

- `PERMISSION-001`：无查看权限时不得展示数据
- `PERMISSION-002`：无导出权限时不得提供可操作导出
- `BUSINESS-001`：停用记录不可编辑
- `BUSINESS-002`：批量停用必须跟随选择状态
- `STATE-001`：请求失败不得渲染为普通空数据
- `BUSINESS-003`：删除失败必须保留原记录

## 视觉验收规则

视觉验收只使用 Playwright、DOM、计算样式和布局尺寸，不做主观审美、截图大模型或外部视觉识别。阅读 `references/visual-rules.md` 后配置 `visual`：

- `VISUAL-001`：主内容在桌面视口内存在、可见且具有非零尺寸。
- `VISUAL-002`：关键状态区域可见，且存在可识别的文本和有效计算样式。
- `VISUAL-003`：主内容在桌面与移动视口内不越界。
- `VISUAL-004`：指定视觉锚点的几何信息与计算样式与冻结快照一致。

视觉锚点快照是页面契约的一部分。任何有意布局变更都必须先完成业务复检，再经人工审核更新快照并重新生成基线。

## 修复边界

不得仅因存在报告就自动修改页面。遵循用户已有授权范围；已有明确修复授权时无需重复询问。补丁记录必须包含报告 ID、规则 ID、目标文件、修复理由和复检结果。不得自动修复 `reviewRequired` 或 `manual` 发现项。

## 资源

- `references/page-contract.md`：必需的配置契约和验收清单。
- `references/frozen-rules.md`：不可变的规则语义与证据要求。
- `references/visual-rules.md`：确定性视觉验收规则与快照更新边界。
- `assets/template/`：可运行的可移植校验器模板。
- `scripts/scaffold.mjs`：将模板复制到项目中。
