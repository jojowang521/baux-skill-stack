import { cpSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const destination = process.argv[2];
if (!destination) throw new Error('Usage: node scaffold.mjs <project-directory>');
const target = resolve(destination, 'page-quality-validator');
if (existsSync(target)) throw new Error(`Refusing to overwrite existing directory: ${target}`);
cpSync(resolve(import.meta.dirname, '..', 'assets', 'template'), target, { recursive: true });
console.log(`Created ${target}`);
