import test from 'node:test';
import assert from 'node:assert/strict';
import { actionable, reportExitCode } from './semantics.mjs';
test('edit entry is actionable only when both visible and enabled',()=>{for(const [visible,enabled,want] of [[true,true,true],[true,false,false],[false,true,false],[false,false,false]]) assert.equal(actionable({visible,enabled}),want); assert.equal([].some(actionable),false)});
test('failed, execution error and incomplete reports never exit successfully',()=>{for(const [summary,want] of [[{failed:0,error:0,notRun:0},0],[{failed:1,error:0,notRun:0},1],[{failed:0,error:1,notRun:0},1],[{failed:0,error:0,notRun:1},2],[{failed:1,error:0,notRun:1},1]]) assert.equal(reportExitCode({summary}),want)});
