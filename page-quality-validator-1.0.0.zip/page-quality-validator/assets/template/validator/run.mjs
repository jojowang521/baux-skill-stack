import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, extname, join, normalize, relative, resolve, sep } from 'node:path';
import { chromium } from 'playwright';
import { actionable, reportExitCode } from './semantics.mjs';

const root = resolve(import.meta.dirname, '..');
const config = JSON.parse(await readFile(resolve(root, 'page-quality.config.json'), 'utf8'));
const reportDirectory = resolve(root, 'reports');
const visualMode = process.argv.includes('--visual-baseline');
const contentTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css' };
const definition = (id, name, category, severity, scenario, expected, fixMode = 'safe') => ({ id, name, category, severity, scenario, expected, fixMode });
const rules = [
  definition('PERMISSION-001', 'No data without view permission', 'permission', 'P0', 'noView', 'Permission state is visible and no customer data is exposed.', 'reviewRequired'),
  definition('PERMISSION-002', 'No actionable export without export permission', 'permission', 'P0', 'noExport', 'Export is absent, hidden, or disabled.', 'reviewRequired'),
  definition('BUSINESS-001', 'Disabled records cannot be edited', 'business', 'P1', 'normal', 'A disabled record has no actionable edit entry.'),
  definition('BUSINESS-002', 'Batch disable follows selection', 'business', 'P1', 'normal', 'Batch disable is disabled with zero selection and enabled after selecting one active record.'),
  definition('STATE-001', 'Request failure is not empty data', 'state', 'P1', 'requestError', 'Error and retry are visible without empty states.'),
  definition('BUSINESS-003', 'Delete failure preserves record', 'business', 'P1', 'deleteError', 'Delete failure feedback appears and the record remains.'),
  definition('VISUAL-001', 'Primary content is visible', 'visual', 'P1', 'normal', 'Primary content is visible with non-zero dimensions.'),
  definition('VISUAL-002', 'Permission state is recognizable', 'visual', 'P1', 'noView', 'The configured permission state is visible and contains readable text.'),
  definition('VISUAL-003', 'Content fits configured viewports', 'visual', 'P1', 'normal', 'Primary content stays within configured desktop and mobile viewport boundaries.'),
  definition('VISUAL-004', 'Visual anchors match baseline', 'visual', 'P1', 'normal', 'Configured anchor geometry and computed styles match the approved visual baseline.')
];

function serverFor(directory) {
  const staticRoot = resolve(directory);
  const server = createServer(async (request, response) => {
    let pathname; try { pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://localhost').pathname); } catch { return void response.writeHead(400).end(); }
    const path = normalize(join(staticRoot, pathname));
    if (!path.startsWith(`${staticRoot}${sep}`)) return void response.writeHead(403).end();
    try { const body = await readFile(path); response.writeHead(200, { 'content-type': contentTypes[extname(path)] ?? 'application/octet-stream' }).end(body); }
    catch { response.writeHead(404).end(); }
  });
  return new Promise((resolveServer, rejectServer) => { server.once('error', rejectServer); server.listen(0, '127.0.0.1', () => resolveServer(server)); });
}
function visible(page, selector) { const item = page.locator(selector).first(); return item.count().then(async count => ({ count, visible: Boolean(count) && await item.isVisible(), enabled: Boolean(count) && await item.isEnabled() })); }
function selectedCount(text) { return Number(text.match(/(\d+)/)?.[1] ?? -1); }
async function anchorSnapshot(page, selectors) {
  return Promise.all(selectors.map(async selector => {
    const locator = page.locator(selector).first();
    await locator.waitFor({ state: 'visible', timeout: 15000 });
    return locator.evaluate((element, currentSelector) => {
      const rect = element.getBoundingClientRect(); const style = getComputedStyle(element);
      return { selector: currentSelector, rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }, style: { display: style.display, visibility: style.visibility, opacity: style.opacity, color: style.color, backgroundColor: style.backgroundColor, fontSize: style.fontSize, fontWeight: style.fontWeight, lineHeight: style.lineHeight } };
    }, selector);
  }));
}
function compareSnapshots(expected, actual, tolerance) {
  const differences = []; if (expected.length !== actual.length) return ['anchor count differs'];
  for (let index = 0; index < expected.length; index += 1) { const before = expected[index], after = actual[index]; if (before.selector !== after.selector) differences.push(`${before.selector}: selector differs`); for (const key of ['x', 'y', 'width', 'height']) if (Math.abs(before.rect[key] - after.rect[key]) > tolerance) differences.push(`${before.selector}: rect.${key} ${before.rect[key]} -> ${after.rect[key]}`); for (const key of Object.keys(before.style)) if (before.style[key] !== after.style[key]) differences.push(`${before.selector}: style.${key} differs`); }
  return differences;
}
function statusSummary(results) {
  const summary = { totalRules: results.length, passed: 0, failed: 0, notRun: 0, error: 0, passRate: 0 };
  for (const result of results) summary[result.status] += 1;
  summary.passRate = summary.totalRules ? summary.passed / summary.totalRules : 0;
  return summary;
}
function html(report) {
  const esc = value => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  const rows = report.results.map(result => `<details class="${result.status}"><summary><b>${esc(result.ruleId)}</b> ${esc(result.name)} <span>${esc(result.status)}</span></summary><p><b>Expected:</b> ${esc(result.expected)}</p><p><b>Actual:</b> ${esc(result.actual)}</p><p><b>URL:</b> ${esc(result.evidence.url)}</p><pre>${esc(result.evidence.domSummary)}</pre><pre>${esc(JSON.stringify(result.evidence.additional ?? {}, null, 2))}</pre>${result.evidence.screenshotPath ? `<img src="${esc(result.evidence.screenshotPath.replace(/^reports\//, ''))}">` : ''}</details>`).join('');
  return `<!doctype html><meta charset="utf-8"><title>Page Quality Report</title><style>body{font:14px system-ui;margin:32px;background:#f5f8fb;color:#17233a}header,details{max-width:1100px;margin:0 auto 12px;background:#fff;border:1px solid #dce4ed;padding:16px}.kpis{display:flex;gap:12px;flex-wrap:wrap}.kpis b{font-size:24px;display:block}.passed{border-left:4px solid #17834c}.failed{border-left:4px solid #b93030}.error{border-left:4px solid #743d9c}.notRun{border-left:4px solid #a96b08}summary{cursor:pointer}span{margin-left:8px}pre{white-space:pre-wrap;max-height:200px;overflow:auto;background:#f6f8fa;padding:10px}img{max-width:100%;border:1px solid #ddd}</style><header><h1>Page Quality Report</h1><p>${esc(report.meta.target)} · ${esc(report.meta.generatedAt)} · ${report.meta.durationMs}ms</p><div class="kpis"><div><small>Total</small><b>${report.summary.totalRules}</b></div><div><small>Passed</small><b>${report.summary.passed}</b></div><div><small>Failed</small><b>${report.summary.failed}</b></div><div><small>Not run</small><b>${report.summary.notRun}</b></div><div><small>Error</small><b>${report.summary.error}</b></div></div></header>${rows}`;
}

async function execute(page, rule, url, runId) {
  const s = config.selectors; const d = config.data; const a = config.actions; const v = config.visual ?? {}; const start = Date.now();
  const result = { ruleId: rule.id, name: rule.name, category: rule.category, severity: rule.severity, scenario: rule.scenario, status: 'error', expected: rule.expected, actual: '', fixMode: rule.fixMode, durationMs: 0, evidence: { url } };
  try {
    if (rule.id.startsWith('VISUAL-') && v.desktopViewport) await page.setViewportSize(v.desktopViewport);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.locator(s.pageRoot).waitFor({ state: 'visible', timeout: 20000 });
    if (rule.id === 'PERMISSION-001') {
      await page.locator(s.noPermission).waitFor({ state: 'visible', timeout: 10000 });
      const denied = await visible(page, s.noPermission), table = await visible(page, s.table), rows = await page.locator(s.row).count(), body = await page.locator('body').innerText();
      const leaked = (d.sensitiveTexts ?? []).filter(value => body.includes(value));
      result.status = denied.visible && !table.visible && rows === 0 && leaked.length === 0 ? 'passed' : 'failed'; result.actual = result.status === 'passed' ? 'Permission state is visible with no customer data.' : 'Permission state or data exposure check failed.'; result.evidence = { url, selector: s.noPermission, visible: denied.visible, additional: { tableVisible: table.visible, rowCount: rows, leaked } };
    } else if (rule.id === 'PERMISSION-002') {
      await page.locator(s.toolbar).waitFor({ state: 'visible', timeout: 15000 }); const button = await visible(page, s.exportButton); const allowed = button.visible && button.enabled;
      result.status = allowed ? 'failed' : 'passed'; result.actual = allowed ? 'Export is visible and enabled.' : button.count ? 'Export is not actionable.' : 'Export is absent.'; result.evidence = { url, selector: s.exportButton, visible: button.visible, enabled: button.enabled, disabled: button.count > 0 && !button.enabled };
    } else if (rule.id === 'BUSINESS-001') {
      await page.locator(s.table).waitFor({ state: 'visible', timeout: 15000 }); const row = page.locator(s.row).filter({ hasText: d.disabledText }).first();
      if (!await row.count()) { result.status = 'notRun'; result.actual = 'No disabled record is available.'; result.evidence = { url, selector: s.row }; }
      else { const edits = await row.locator(s.editButton).all(); const states = await Promise.all(edits.map(async edit => ({ visible: await edit.isVisible(), enabled: await edit.isEnabled() }))); const allowed = states.some(actionable); result.status = allowed ? 'failed' : 'passed'; result.actual = allowed ? 'Disabled record edit is actionable.' : 'Disabled record edit is absent, hidden, or disabled.'; result.evidence = { url, selector: s.editButton, additional: { states }, domSummary: await row.innerText() }; }
    } else if (rule.id === 'BUSINESS-002') {
      await page.locator(s.table).waitFor({ state: 'visible', timeout: 15000 }); const batch = page.locator(s.batchButton), before = selectedCount(await page.locator(s.selectedCount).innerText()), beforeDisabled = await batch.isDisabled(); const row = page.locator(s.row).filter({ hasText: d.activeText }).first();
      if (!await row.count() || !await row.locator(a.rowCheckbox).count()) { result.status = 'notRun'; result.actual = 'No selectable active record is available.'; result.evidence = { url, selector: s.row }; }
      else { await row.locator(a.rowCheckbox).check(); await page.waitForTimeout(100); const after = selectedCount(await page.locator(s.selectedCount).innerText()), afterDisabled = await batch.isDisabled(); result.status = before === 0 && beforeDisabled && after === 1 && !afterDisabled ? 'passed' : 'failed'; result.actual = `Selection ${before}/${beforeDisabled} -> ${after}/${afterDisabled}.`; result.evidence = { url, selector: s.batchButton, additional: { before, beforeDisabled, after, afterDisabled } }; }
    } else if (rule.id === 'STATE-001') {
      try { await page.locator(s.requestError).waitFor({ state: 'visible', timeout: 3000 }); } catch { /* Missing error state is a rule failure. */ }
      const error = await visible(page, s.requestError), retry = await visible(page, s.retryButton), empty = await visible(page, s.empty), search = await visible(page, s.searchEmpty);
      result.status = error.visible && retry.visible && !empty.visible && !search.visible ? 'passed' : 'failed'; result.actual = result.status === 'passed' ? 'Request error is distinct from empty data.' : 'Request error state conflicts with empty state.'; result.evidence = { url, selector: s.requestError, visible: error.visible, additional: { retry: retry.visible, empty: empty.visible, searchEmpty: search.visible } };
    } else if (rule.id === 'BUSINESS-003') {
      await page.locator(s.table).waitFor({ state: 'visible', timeout: 15000 }); const button = page.locator(s.deleteButton).first(); if (!await button.count()) { result.status = 'notRun'; result.actual = 'No delete action is available.'; result.evidence = { url, selector: s.deleteButton }; }
      else { const row = button.locator('xpath=ancestor::tr'); const rowId = await row.getAttribute('data-testid'); if (!rowId) throw new Error('Delete rule requires stable data-testid on the target row'); const before = await page.locator(s.row).count(); await button.click(); await page.getByRole(a.deleteConfirmRole, { name: a.deleteConfirmName }).click(); const failure = page.locator(s.deleteError).last(); await failure.waitFor({ state: 'visible', timeout: 8000 }); const failureText = await failure.innerText(), after = await page.locator(s.row).count(), remains = await page.getByTestId(rowId).count() === 1; const success = await visible(page, s.deleteSuccess); result.status = failureText.includes(a.deleteErrorText) && remains && before === after && !success.visible ? 'passed' : 'failed'; result.actual = result.status === 'passed' ? 'Delete failure preserved the record.' : 'Delete failure did not preserve the record.'; result.evidence = { url, selector: s.deleteButton, additional: { rowId, before, after, remains, failureText, successVisible: success.visible } }; }
    } else if (rule.id === 'VISUAL-001') {
      const locator = page.locator(s.pageRoot).first(); const state = await locator.evaluate(element => { const rect = element.getBoundingClientRect(); const style = getComputedStyle(element); return { rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, display: style.display, visibility: style.visibility, opacity: Number(style.opacity) }; });
      const passed = state.rect.width > 0 && state.rect.height > 0 && state.display !== 'none' && state.visibility !== 'hidden' && state.opacity > 0; result.status = passed ? 'passed' : 'failed'; result.actual = passed ? 'Primary content is visible.' : 'Primary content is hidden or has zero dimensions.'; result.evidence = { url, selector: s.pageRoot, visible: passed, additional: state };
    } else if (rule.id === 'VISUAL-002') {
      const selector = v.stateSelector ?? s.noPermission; const locator = page.locator(selector).first(); const state = await locator.evaluate(element => { const rect = element.getBoundingClientRect(); const style = getComputedStyle(element); return { text: element.textContent?.trim() ?? '', rect: { width: rect.width, height: rect.height }, display: style.display, visibility: style.visibility, opacity: Number(style.opacity) }; });
      const passed = state.text.length > 0 && state.rect.width > 0 && state.rect.height > 0 && state.display !== 'none' && state.visibility !== 'hidden' && state.opacity > 0; result.status = passed ? 'passed' : 'failed'; result.actual = passed ? 'Permission state is visible with readable text.' : 'Permission state is hidden, empty, or has zero dimensions.'; result.evidence = { url, selector, visible: passed, elementText: state.text, additional: state };
    } else if (rule.id === 'VISUAL-003') {
      const checkViewport = async viewport => { await page.setViewportSize(viewport); const rect = await page.locator(s.pageRoot).first().evaluate(element => { const box = element.getBoundingClientRect(); return { left: Math.round(box.left), right: Math.round(box.right), width: Math.round(box.width), viewportWidth: window.innerWidth }; }); return { viewport, rect, fits: rect.left >= 0 && rect.right <= rect.viewportWidth + 1 }; };
      const desktop = await checkViewport(v.desktopViewport ?? { width: 1440, height: 900 }); const mobile = await checkViewport(v.mobileViewport ?? { width: 390, height: 844 }); const passed = desktop.fits && mobile.fits; result.status = passed ? 'passed' : 'failed'; result.actual = passed ? 'Primary content fits both configured viewports.' : 'Primary content exceeds a configured viewport boundary.'; result.evidence = { url, selector: s.pageRoot, additional: { desktop, mobile } };
    } else if (rule.id === 'VISUAL-004') {
      const snapshot = await anchorSnapshot(page, v.anchorSelectors ?? [s.pageRoot]); const baselinePath = resolve(root, v.baselineFile ?? 'reports/visual-baseline.json');
      if (visualMode) { await mkdir(dirname(baselinePath), { recursive: true }); await writeFile(baselinePath, JSON.stringify({ generatedAt: new Date().toISOString(), anchors: snapshot }, null, 2)); result.status = 'passed'; result.actual = 'Visual anchor baseline captured.'; result.evidence = { url, selector: s.pageRoot, additional: { baselinePath: relative(root, baselinePath), anchors: snapshot } }; }
      else { try { const expected = JSON.parse(await readFile(baselinePath, 'utf8')).anchors; const differences = compareSnapshots(expected, snapshot, v.geometryTolerancePx ?? 2); result.status = differences.length ? 'failed' : 'passed'; result.actual = differences.length ? 'Visual anchors differ from baseline.' : 'Visual anchors match baseline.'; result.evidence = { url, selector: s.pageRoot, additional: { baselinePath: relative(root, baselinePath), differences, actual: snapshot } }; } catch (error) { result.status = error.code === 'ENOENT' ? 'notRun' : 'error'; result.actual = error.code === 'ENOENT' ? 'Visual baseline is not available.' : 'Visual baseline cannot be parsed or read.'; result.evidence = { url, selector: s.pageRoot, additional: { baselinePath: relative(root, baselinePath), reason: error instanceof Error ? error.message : String(error) } }; } }
    }
  } catch (error) { result.status = 'error'; result.actual = 'Rule execution did not complete.'; result.errorMessage = error instanceof Error ? error.message : String(error); }
  result.durationMs = Date.now() - start; await mkdir(join(reportDirectory, 'screenshots'), { recursive: true }); const screenshot = join(reportDirectory, 'screenshots', `${runId}-${rule.id}-${result.status}.png`); try { await page.screenshot({ path: screenshot, fullPage: true }); result.evidence.screenshotPath = relative(root, screenshot); } catch (error) { result.errorMessage = `${result.errorMessage ?? ''} Screenshot: ${error}`; }
  return result;
}

async function run(runId, output) {
  const targetRoot = resolve(root, config.target.root), targetFile = resolve(targetRoot, config.target.file), server = await serverFor(targetRoot), address = server.address(), baseUrl = `http://127.0.0.1:${address.port}`, executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE, launchOptions = { headless: true, ...(executablePath ? { executablePath } : {}) }; let browser; const started = Date.now();
  try { browser = await chromium.launch(launchOptions); const results = []; for (const rule of rules) { const page = await browser.newPage(); const query = new URLSearchParams(config.scenarios[rule.scenario]); const url = `${baseUrl}/${relative(targetRoot, targetFile).split(sep).map(encodeURIComponent).join('/')}?${query}`; results.push(await execute(page, rule, url, runId)); await page.close(); } const report = { meta: { generatedAt: new Date().toISOString(), target: relative(root, targetFile), baseUrl, durationMs: Date.now() - started, validatorVersion: '1.0.0' }, summary: statusSummary(results), results }; await mkdir(reportDirectory, { recursive: true }); await writeFile(join(reportDirectory, output + '.json'), JSON.stringify(report, null, 2)); await writeFile(join(reportDirectory, output + '.html'), html(report)); return report; }
  finally { try { if (browser) await browser.close(); } finally { await new Promise(resolveClose => server.close(resolveClose)); } }
}

if (process.argv.includes('--repeat')) { const reports = []; for (let index = 1; index <= 3; index += 1) reports.push(await run(`run-${index}`, `run-${index}`)); const reference = reports[0].results.map(r => `${r.ruleId}|${r.status}|${r.expected}|${r.actual}`).join('\n'); const stable = reports.every(report => report.results.map(r => `${r.ruleId}|${r.status}|${r.expected}|${r.actual}`).join('\n') === reference); await writeFile(join(reportDirectory, 'repeatability.json'), JSON.stringify({ stable, runs: reports.map(r => r.meta.generatedAt) }, null, 2)); console.log(`Repeatability: ${stable ? 'stable' : 'drift detected'}`); process.exitCode = stable ? Math.max(...reports.map(reportExitCode)) : 1; }
else { const report = await run('baseline', 'baseline-report'); console.log(JSON.stringify(report.summary)); process.exitCode = reportExitCode(report); }
