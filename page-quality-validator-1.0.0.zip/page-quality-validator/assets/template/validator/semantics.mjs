export const actionable = state => Boolean(state.visible && state.enabled);
export function reportExitCode(report) { const s = report.summary; return s.error || s.failed ? 1 : s.notRun ? 2 : 0; }
