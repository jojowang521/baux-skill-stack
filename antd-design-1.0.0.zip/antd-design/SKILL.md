---
name: antd-design
description: 为明确使用 Ant Design 的项目提供组件选型、Design Token、主题配置及页面审查；可输出按需的 React 组件示例。适用于 Ant Design 相关问题或已有 antd 项目，不因一般 B 端需求覆盖其他设计系统。
metadata:
  version: "1.0.0"
---

# Ant Design 设计与组件顾问

根据项目已有 Ant Design 版本和主题，把页面需求转成组件选择、Token 配置或可定位的问题清单。

## 输入与交付

- 输入：组件或页面需求、已有代码/截图、设计系统约束；实现代码时需要项目的 antd 与 React 版本。
- 优先从 package.json、锁文件和现有 ConfigProvider 判断版本及约定。没有项目时，明确声明示例版本；包内示例固定 antd 5.27.6，不代表最新版本，也不自动升级现有项目。
- 输出按请求选择：组件映射及理由、主题配置、局部 React 示例，或含位置、影响、建议和规则来源的问题清单。单纯咨询不强制生成页面。
- 信息不足但不影响局部判断时先给可验证建议；影响接口或业务含义的缺口明确指出，不自行编造业务规则。

## 执行原则

1. 先确认所选设计系统。通用 B 端布局由当前页面任务承接；本 Skill 负责 Ant Design 的组件和主题约束，不接管完整需求分析或 PRD 流程。
2. 查 Token、主题时读 [版本与主题](references/theme-and-version.md)；选表格、表单、反馈组件时读 [组件要点](references/components.md)；评审或组织页面时读 [模式与审查](references/patterns.md)。
3. 区分官方 API/版本默认值、项目约定、设计建议。间距、字段数、分页数量等没有依据时只作建议，不写成平台强制规则。
4. 主题通过 ConfigProvider 传递，定制容器用 theme.useToken() 读取当前值；需要继承主题的消息反馈使用上下文实例。具体接口以目标版本文档为准。
5. 数据状态以实际输入为准：零值保留，未知信息不补零；空态、失败态、提交校验和状态文字随相关组件说明。权限边界由业务与服务端实现，隐藏按钮不能替代鉴权。
6. 交付说明实际运行版本、验证内容和未覆盖项。样式相似的静态 HTML 不等同于使用了 Ant Design 组件；需要可运行预览时可参考包内真实组件示例。

## 演示与复用

[演示输入](assets/demo/brief.txt) → [虚拟数据](assets/demo/demo-data.json) → [真实组件预览](assets/demo/index.html)。示例演示搜索、状态筛选、表格排序分页、详情、新增表单和主题切换；所有写入仅在页面内存中，刷新恢复。

[README](README.md) 说明打开方式、依赖和原包来源；[更新记录](CHANGELOG.md) 说明本轮修改；[验证记录](references/validation-report.md) 只记录已完成的检查。
