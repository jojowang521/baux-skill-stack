# 版本与主题

本包代码样例固定 antd 5.27.6。先看项目锁定版本，再查相应版本官方资料；不要把 5.x 与 6.x API 或默认值混用。

## 有依据的默认值

5.27.6 seed：colorPrimary #1677ff，colorSuccess #52c41a，colorWarning #faad14，colorError #ff4d4f；fontSize 14、borderRadius 6、controlHeight 32、sizeUnit 4。这是该版本的种子值，实际运行值还会受算法和项目配置影响。文本、背景等派生 Token 从 theme.useToken() 读取，不硬编码一张跨版本颜色表。

来源：[5.27.6 seed 源码](https://github.com/ant-design/ant-design/blob/5.27.6/components/theme/themes/seed.ts)，核对日期 2026-10-09。

## 最小配置

```jsx
import { App as AntApp, ConfigProvider, theme } from 'antd';

<ConfigProvider theme={{
  algorithm: dark ? theme.darkAlgorithm : theme.defaultAlgorithm,
  token: { colorPrimary: '#1677ff' },
}}>
  <AntApp><YourPage /></AntApp>
</ConfigProvider>
```

YourPage 内调用 theme.useToken() 读取主题，App.useApp() 获取随上下文生效的 message/modal/notification。组件级差异放入 theme.components，并先确认对应 Token 在目标版本存在。

来源：[5.27.6 主题文档](https://github.com/ant-design/ant-design/blob/5.27.6/docs/react/customize-theme.en-US.md)。当前在线文档可能已变化，不能直接据此声称旧版本兼容。

## 设计建议

优先复用项目已选主题与密度。4/8/16/24 等可作为间距起点，但边框、光学对齐和组件内部细节不受“所有数值必须是 4 的倍数”限制。表格密度、圆角与主色改动需结合真实内容查看。
