# 组件要点

以下 API 依据 antd 5.27.6；其他版本先复核，避免照抄。

## 表格

- Table 设置稳定 rowKey；金额列可右对齐，状态用文字加 Tag/Badge，必要时设置明确列宽。
- ellipsis 接受布尔值或 { showTitle }；自定义浮层用 render 包装 Tooltip，不使用不存在的 ellipsis.tooltip。
- virtual 可用不等于某一行数必须启用；是否启用取决于性能。虚拟滚动需按版本文档配置数值 scroll.x 和 scroll.y。
- 筛选、排序、分页区分本地与服务端模式；筛选改变时处理页码，显示的总数必须匹配过滤后的记录。

来源：[5.27.6 Table](https://github.com/ant-design/ant-design/blob/5.27.6/components/table/index.en-US.md)。

## 表单

- Form.Item 用 name 绑定值，用 label 提供可访问名称；required 视觉标记不能代替 rules 校验。
- validateTrigger 按任务选择；5.27.6 默认 onChange，onBlur 是可选策略，不应写成所有表单必须遵守的规则。
- 错误提示需有空间并与字段对应；提交失败保留输入，成功后明确反馈。不要依赖 help “完全不占空间”。
- labelAlign、layout、字段宽度和分组依据文本与容器决定；固定字段数阈值只是设计建议。

来源：[5.27.6 Form](https://github.com/ant-design/ant-design/blob/5.27.6/components/form/index.en-US.md)。

## 选型建议

Layout/Menu 表达页面导航；Descriptions 展示详情；Modal 适合短任务，Drawer 可在保留列表上下文时展示详情。加载、空态、错误应就近表达。状态颜色同时配文字；主操作保持清楚，按钮名称说明动作。以上为情境建议，不是官方强制布局。
