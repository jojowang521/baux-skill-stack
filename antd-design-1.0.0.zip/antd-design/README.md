# Ant Design 设计与组件顾问 1.0.0

适用于已选择 Ant Design 的组件、Token 和审查任务。入口为 SKILL.md；完整目录名保持 antd-design，按目标宿主的 Skill 安装方法接入。本次未安装或发布。

## 演示

直接打开 assets/demo/index.html，或在此目录启动本地静态服务后访问它。需要联网加载 React 18.3.1、ReactDOM 18.3.1、dayjs 1.11.13、antd 5.27.6 的 CDN 资源。HTML 已嵌入与 demo-data.json 相同的虚拟数据，使用真实组件；无构建步骤、无接口服务，新增记录仅保存在当前页面内存。

演示输入、数据、页面、站点截图和元数据放在 assets/demo。修改 JSON 不会自动更新 HTML 的内嵌数据，两者应同步；复制到项目时替换为项目的数据入口。

本例固定 5.27.6 以便复现，不表示最新版本或完整版本兼容。生产项目应按已有构建系统导入依赖并实现鉴权和持久化。

## 来源与验证

原包 antd-design.skill 的字节基线和 SHA-256 已保留在第一批交付包。作者、Skill 许可证与仓库原包未声明；本版不推断或新增授权。第三方库许可不等于 Skill 许可。

本次关键规则的来源链接在 references 中。实际验证及范围限制见 references/validation-report.md。
